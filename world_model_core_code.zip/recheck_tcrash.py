"""
T4b「+10% 闭合」结论的独立复算与验证。

背景：此前报告「multistep 臂 T_crash(b) 斜率 13.88 → 反推有效扩张率 0.0499 vs 真值
0.0453，偏差 +10%」为**拟合伪影**。本脚本用四项独立复核取代该结论：

A. floor 判据（解析预测 vs 实测对照）
   量化误差每维均匀分布于 [-delta/2, delta/2]，3 维范数 rms = sqrt(3)*delta/sqrt(12) = delta/2。
   → 判据：delta/2 > δ* 时第一步必然崩溃（T_crash 恒为 1）。
   该判据对 3 臂 × 6 档 × 2 阈值 = 36 格逐格对照实测。

A2. 用原 JSON 数据做分档重拟合，复现「伪影」并给出正确值：
   (i) 全档（原做法，含触底档）(ii) 剔触底档 (iii) 外推检验。

B. 无删失重测：原窗口 300 步使 b=16 档 32 个初值只剩 10 个越阈（69% 右删失），
   而删失会低估大 b 档 T_crash。重训两臂（保存 ckpt）、窗口 4000 步、bits 6..18，
   给出无删失完整 T(b) 与 bootstrap 斜率 95%CI。

C. 完整递推的理论曲线（取代直线拟合）
   误差递推 δ_{t+1} = e^λ δ_t + η（方向随机 → 平方和混合），η(b) = η0·delta(b)。
   闭式解给出整条 T(b)（非直线），网格搜 (λ, η0) 与直线模型比 RSS。
   直线 T ∝ b 只是「λT ≫ 1」极限；低 b（λT ≪ 1）区退化为 T ∝ 2^b。实测凸性即该过渡。

D. 真值 λ₁ 严格重算：qr_spectrum_flow（状态与变分同用 RK4），
   dt 收敛 + 3 初值 + 和检验 Σλ = −(σ+1+β)。取代单步雅可比近似的 +0.0547。

产物 logs/recheck_tcrash.json
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from lyap import qr_spectrum_flow, lorenz_rhs, lorenz_jac  # noqa: E402
from t4b_arms import (Net, gen_traj, quantize, qr_lam1, fit_line,  # noqa: E402
                      LAM_TRUE, N_TRAJ, N_STEPS, DEV)

OUT = os.path.join(ROOT, "logs", "recheck_tcrash.json")
CKPT = os.path.join(ROOT, "ckpt")
BITS_OLD = [2, 3, 4, 6, 8, 12, 16, 32]
BITS_NEW = [6, 7, 8, 10, 12, 14, 16, 18]
D_STAR = (1.0, 5.0)
STEPS_LONG = 4000


def slope_of(pts):
    b = np.array([p[0] for p in pts], float)
    y = np.array([p[1] for p in pts], float)
    A = np.vstack([b, np.ones_like(b)]).T
    (sl, ic), *_ = np.linalg.lstsq(A, y, rcond=None)
    pred = A @ np.array([sl, ic])
    r2 = 1 - ((y - pred) ** 2).sum() / ((y - y.mean()) ** 2).sum()
    eff = math.log(2) / sl if sl > 0 else float("inf")
    return dict(slope=float(sl), intercept=float(ic), r2=float(r2), n=len(pts),
                eff_lam=float(eff) if math.isfinite(eff) else None,
                dev=(float(eff) - LAM_TRUE) / LAM_TRUE if math.isfinite(eff) else None,
                bits=[p[0] for p in pts], T=[p[1] for p in pts])


# ------------------------------------------------------------------ A
def part_a_floor():
    print("\n" + "=" * 88)
    print("  A. floor 判据：量化误差 rms 范数 = delta/2 是否已越过阈值（解析预测 vs 实测）")
    print("=" * 88)
    src = json.load(open(os.path.join(ROOT, "logs", "t4b_arms.json"), encoding="utf-8"))
    print(f"  {'b':>3} {'delta':>9} {'delta/2':>9} | "
          f"{'单步臂 d1':>10} {'多步臂 d1':>10} {'回归臂 d1':>10} | "
          f"{'单步 d5':>8} {'多步 d5':>8} {'回归 d5':>8} | 判据")
    n_ok = n_tot = 0
    table = []
    for b in BITS_OLD:
        if b >= 32:
            continue
        d = src["arms"][0]["rows"][BITS_OLD.index(b)]["delta"]
        rms = d / 2.0
        pred = {ds: bool(rms > ds) for ds in D_STAR}
        row = {"bits": b, "delta": d, "rms_quant_err": rms,
               "pred_floor_d1": pred[1.0], "pred_floor_d5": pred[5.0]}
        observed = {}
        for arm in src["arms"]:
            r = next(x for x in arm["rows"] if x["bits"] == b)
            observed[arm["arm"]] = {
                "d1": bool(r["med_d1"] == 1.0), "d5": bool(r["med_d5"] == 1.0)}
        ok = True
        for arm in observed:
            for ds, k in ((1.0, "d1"), (5.0, "d5")):
                n_tot += 1
                good = (observed[arm][k] == pred[ds])
                n_ok += int(good)
                ok &= good
        row["observed"] = observed
        row["pred_within_arm"] = bool(ok)
        table.append(row)
        print(f"  {b:>3} {d:>9.3f} {rms:>9.3f} | "
              f"{str(observed['single']['d1']):>10} {str(observed['multistep']['d1']):>10} "
              f"{str(observed['reg']['d1']):>10} | "
              f"{str(observed['single']['d5']):>8} {str(observed['multistep']['d5']):>8} "
              f"{str(observed['reg']['d5']):>8} | " + ("OK" if ok else "<<< 不一致"))
    print(f"\n  判据与实测一致：{n_ok}/{n_tot} 格（{n_ok/n_tot*100:.0f}%）")
    print("  → b=2,3,4 的 T_crash=1 不是「模型崩得快」，是**量化步长本身已超过阈值**（结构性 floor）。")
    return {"table": table, "agree": f"{n_ok}/{n_tot}", "agree_rate": n_ok / n_tot}


# ------------------------------------------------------------------ A2
def part_a2_refit():
    """用原 JSON 数据分档重拟合，复现伪影并给出正确值。"""
    print("\n" + "=" * 88)
    print("  A2. 用原数据分档重拟合：伪影从哪来")
    print("=" * 88)
    src = json.load(open(os.path.join(ROOT, "logs", "t4b_arms.json"), encoding="utf-8"))
    res = {}
    print(f"  {'臂':<10} {'子集':<26} {'斜率':>8} {'R²':>7} {'反推λ':>8} {'偏差':>7}  n")
    for arm in src["arms"]:
        rows = arm["rows"]
        subsets = {
            "全档（原做法，含触底）": [(r["bits"], r["med_d1"]) for r in rows if r["med_d1"] is not None],
            "剔触底档（T>1）": [(r["bits"], r["med_d1"]) for r in rows
                                if r["med_d1"] is not None and r["med_d1"] > 1.0],
            "仅无删失档（n=32）": [(r["bits"], r["med_d1"]) for r in rows
                                   if r["med_d1"] is not None and r["n_1"] == 32 and r["med_d1"] > 1.0],
            "仅 b≥8": [(r["bits"], r["med_d1"]) for r in rows
                       if r["med_d1"] is not None and r["bits"] >= 8],
        }
        res[arm["arm"]] = {}
        for name, pts in subsets.items():
            if len(pts) < 3:
                print(f"  {arm['arm']:<10} {name:<26} 点数不足（{len(pts)}）")
                continue
            s = slope_of(pts)
            res[arm["arm"]][name] = s
            print(f"  {arm['arm']:<10} {name:<26} {s['slope']:>8.2f} {s['r2']:>7.3f} "
                  f"{s['eff_lam']:>8.4f} {s['dev']*100:>+6.0f}%  {s['n']}")
        print()

    # 外推检验：以高 b 档拟合，预测低 b 档
    ms = next(a for a in src["arms"] if a["arm"] == "multistep")
    pts = [(r["bits"], r["med_d1"]) for r in ms["rows"]
           if r["med_d1"] is not None and r["bits"] >= 12]
    if len(pts) >= 2:
        s = slope_of(pts + [(0, 0)]) if len(pts) >= 3 else None
        hi = [(r["bits"], r["med_d1"]) for r in ms["rows"]
              if r["med_d1"] is not None and r["bits"] >= 12]
        if len(hi) >= 2:
            b = np.array([p[0] for p in hi], float)
            y = np.array([p[1] for p in hi], float)
            A = np.vstack([b, np.ones_like(b)]).T
            (sl, ic), *_ = np.linalg.lstsq(A, y, rcond=None)
            print("  外推检验（用 b≥12 拟合，预测 b=6,8）：")
            for r in ms["rows"]:
                if r["bits"] in (6, 8) and r["med_d1"] is not None:
                    predv = sl * r["bits"] + ic
                    print(f"    b={r['bits']}: 预测 {predv:.1f}  实测 {r['med_d1']:.1f}  "
                          f"比 {predv/r['med_d1']:.2f}×")
            res["_extrapolation"] = {"slope": float(sl), "intercept": float(ic)}
    return res


# ------------------------------------------------------------------ B
def tcrash_batch(m, ics, bits_list, lo, hi, steps=STEPS_LONG, dstar=D_STAR):
    """批量 T_crash：一次 rollout 同时记录所有阈值首穿步（避免提前 break 的旧 bug）。"""
    out = []
    n = ics.shape[0]
    for bits in bits_list:
        delta = (hi - lo) / (2 ** bits - 1)
        rec = {"bits": bits, "delta": delta}
        with torch.no_grad():
            s_ref = ics.clone()
            s_q = ics.clone()
            hit = {ds: torch.full((n,), -1, dtype=torch.long, device=DEV) for ds in dstar}
            for t in range(steps):
                if t > 0:
                    s_ref = m(s_ref)
                    s_q = quantize(m(s_q), bits, lo, hi)
                d = (s_q - s_ref).norm(dim=1)
                for ds in dstar:
                    newly = (hit[ds] < 0) & (d > ds)
                    hit[ds][newly] = t
                if all(bool((h >= 0).all()) for h in hit.values()):
                    break
            for ds in dstar:
                h = hit[ds]
                obs = h[h >= 0].cpu().numpy().astype(float)
                rec[f"n_d{int(ds)}"] = int(obs.size)
                rec[f"censored_d{int(ds)}"] = int((h < 0).sum())
                rec[f"med_d{int(ds)}"] = float(np.median(obs)) if obs.size else None
                rec[f"mean_d{int(ds)}"] = float(obs.mean()) if obs.size else None
                rec[f"list_d{int(ds)}"] = sorted(obs.tolist())
        out.append(rec)
    return out


def bootstrap_slope(rows, ds, n_boot=4000, seed=0):
    """档内 bootstrap（重采样每个初值的 T_crash）→ 斜率 95%CI。只用于无删失集合。"""
    usable = [r for r in rows if r.get(f"med_d{int(ds)}") is not None
              and r.get(f"censored_d{int(ds)}", 0) == 0]
    if len(usable) < 3:
        return None
    rng = np.random.default_rng(seed)
    bs = np.array([r["bits"] for r in usable], float)
    lists = [np.array(r[f"list_d{int(ds)}"]) for r in usable]
    slopes = np.empty(n_boot)
    for i in range(n_boot):
        ys = np.array([np.median(rng.choice(L, size=L.size, replace=True)) for L in lists])
        A = np.vstack([bs, np.ones_like(bs)]).T
        (sl, _), *_ = np.linalg.lstsq(A, ys, rcond=None)
        slopes[i] = sl
    s = slope_of([(r["bits"], r[f"med_d{int(ds)}"]) for r in usable])
    s["slope_ci95"] = [float(np.percentile(slopes, 2.5)), float(np.percentile(slopes, 97.5))]
    s["eff_lam_ci95"] = [float(math.log(2) / s["slope_ci95"][1]),
                         float(math.log(2) / s["slope_ci95"][0])]
    s["n_boot"] = n_boot
    return s


def quad_test(rows, ds):
    pts = [(r["bits"], r[f"med_d{int(ds)}"]) for r in rows if r.get(f"med_d{int(ds)}") is not None]
    if len(pts) < 4:
        return None
    b = np.array([p[0] for p in pts], float)
    y = np.array([p[1] for p in pts], float)
    X = np.vstack([b ** 2, b, np.ones_like(b)]).T
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ coef
    dof = len(y) - 3
    s2 = (resid ** 2).sum() / dof
    cov = s2 * np.linalg.pinv(X.T @ X)
    se = math.sqrt(max(float(cov[0, 0]), 1e-30))
    r2q = 1 - (resid ** 2).sum() / ((y - y.mean()) ** 2).sum()
    lin = slope_of(pts)
    segs = [(pts[i + 1][0] - pts[i][0],
             (pts[i + 1][1] - pts[i][1]) / (pts[i + 1][0] - pts[i][0]))
            for i in range(len(pts) - 1)]
    return {"quad_coef": float(coef[0]), "quad_se": se, "t_stat": float(coef[0] / se),
            "r2_quad": float(r2q), "r2_linear": lin["r2"],
            "seg_slopes": [{"db": int(d), "slope": float(s)} for d, s in segs]}


def theory_curve(bits, delta, lam, eta0, dstar, mode="rss"):
    """误差递推闭式解预测 T_crash(b)。eta(b) = eta0·delta(b)。

    mode='rss'：δ_{t+1}² = (e^λ δ_t)² + η² → δ_t² = η²(e^{2λt}−1)/(e^{2λ}−1)
    mode='lin'：δ_{t+1}   = e^λ δ_t + η   → δ_t   = η(e^{λt}−1)/(e^λ−1)
    """
    out = []
    for d in delta:
        eta = eta0 * d
        if lam > 1e-9:
            if mode == "rss":
                v = 1.0 + (dstar ** 2) * (math.exp(2 * lam) - 1.0) / (eta ** 2)
                t = math.log(v) / (2 * lam)
            else:
                v = 1.0 + dstar * (math.exp(lam) - 1.0) / eta
                t = math.log(v) / lam
        else:
            t = float("inf")
        out.append(t)
    return np.array(out)


def part_c_fit(rows, ds=1.0):
    usable = [r for r in rows if r.get(f"med_d{int(ds)}") is not None
              and r.get(f"censored_d{int(ds)}", 0) == 0]
    if len(usable) < 3:
        usable = [r for r in rows if r.get(f"med_d{int(ds)}") is not None]
    bits = np.array([r["bits"] for r in usable], float)
    delta = np.array([r["delta"] for r in usable], float)
    y = np.array([r[f"med_d{int(ds)}"] for r in usable], float)
    best = {}
    for mode in ("rss", "lin"):
        bb = None
        for lam in np.linspace(0.004, 0.09, 216):
            for eta0 in np.logspace(-1.2, 1.2, 121):
                pred = theory_curve(bits, delta, lam, eta0, ds, mode)
                rss = float(((pred - y) ** 2).sum())
                if bb is None or rss < bb["rss"]:
                    bb = {"mode": mode, "lam": float(lam), "eta0": float(eta0), "rss": rss}
        if bb:
            pred = theory_curve(bits, delta, bb["lam"], bb["eta0"], ds, mode)
            bb["pred"] = pred.tolist()
            bb["r2"] = float(1 - bb["rss"] / ((y - y.mean()) ** 2).sum())
            bb["lam_dev"] = (bb["lam"] - LAM_TRUE) / LAM_TRUE
            best[mode] = bb
    lin = slope_of(list(zip(bits.tolist(), y.tolist())))
    lin["rss"] = float(((lin["slope"] * bits + lin["intercept"] - y) ** 2).sum())
    return {"data": dict(bits=bits.tolist(), delta=delta.tolist(), T=y.tolist(),
                         n=len(y), dstar=ds),
            "models": best, "linear": lin}


def part_b_train_and_measure():
    print("\n" + "=" * 88)
    print("  B. 无删失重测（窗口 4000 步，bits 6..18）")
    print("=" * 88)
    torch.manual_seed(0)
    rng = np.random.default_rng(0)
    D = np.stack([gen_traj(rng.uniform(-15, 15, 3), N_STEPS) for _ in range(N_TRAJ)])
    lo, hi = float(D.min()) - 1.0, float(D.max()) + 1.0
    Dt = torch.tensor(D, dtype=torch.float32, device=DEV)
    ics = Dt[:32, 0].contiguous()
    print(f"  数据 {D.shape}  量化范围 [{lo:.2f},{hi:.2f}]（三坐标共用一组 lo/hi；"
          f"x,y 物理范围仅 ±20，z 为 0..48）")

    ii, tt = torch.meshgrid(torch.arange(N_TRAJ), torch.arange(N_STEPS - 5), indexing="ij")
    ii, tt = ii.reshape(-1).to(DEV), tt.reshape(-1).to(DEV)
    arms = {}
    for arm in ("single", "multistep"):
        ck = os.path.join(CKPT, f"lorenz_{arm}.pt")
        torch.manual_seed(0)
        m = Net().to(DEV)
        if os.path.exists(ck):
            m.load_state_dict(torch.load(ck, map_location=DEV, weights_only=True)["state"])
            print(f"\n  [{arm}] 载入 ckpt {os.path.basename(ck)}")
        else:
            t0 = time.time()
            opt = torch.optim.AdamW(m.parameters(), lr=2e-3, weight_decay=1e-5)
            sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=600)
            n_idx = ii.shape[0]
            for ep in range(600):
                perm = torch.randperm(n_idx, device=DEV)
                for i0 in range(0, n_idx, 4096):
                    sel = perm[i0:i0 + 4096]
                    bi, bt = ii[sel], tt[sel]
                    opt.zero_grad(set_to_none=True)
                    z0 = Dt[bi, bt]
                    loss = F.mse_loss(m(z0), Dt[bi, bt + 1])
                    if arm == "multistep":
                        zk = z0
                        for k in range(2, 6):
                            zk = m(zk)
                            loss = loss + F.mse_loss(zk, Dt[bi, bt + k])
                    loss.backward()
                    opt.step()
                sch.step()
            torch.save(dict(state=m.state_dict(), arm=arm), ck)
            print(f"\n  [{arm}] 训练完成 {time.time()-t0:.0f}s → {os.path.basename(ck)}")

        with torch.no_grad():
            val_mse = float(((m(Dt[:, :-1].reshape(-1, 3)) - Dt[:, 1:].reshape(-1, 3)) ** 2).mean())
        lam1, spec = qr_lam1(m)
        rows = tcrash_batch(m, ics, BITS_NEW, lo, hi)
        arms[arm] = dict(lam1=lam1, spectrum=spec, val_mse=val_mse, rows=rows,
                         fit_all=slope_of([(r["bits"], r["med_d1"]) for r in rows
                                           if r["med_d1"] is not None]),
                         fit_nocens=bootstrap_slope(rows, 1.0),
                         quad=quad_test(rows, 1.0),
                         theory=part_c_fit(rows, 1.0))
        print(f"\n  [{arm}] QR λ₁ = {lam1:+.5f}/步   单步 val MSE = {val_mse:.4f}")
        print(f"    {'b':>3} {'delta':>9} {'n':>4} {'删失':>5} {'中位':>8} {'均值':>9}")
        for r in rows:
            med = "—" if r["med_d1"] is None else f"{r['med_d1']:.1f}"
            mean = "—" if r["mean_d1"] is None else f"{r['mean_d1']:.1f}"
            print(f"    {r['bits']:>3} {r['delta']:>9.5f} {r['n_d1']:>4} "
                  f"{r['censored_d1']:>5} {med:>8} {mean:>9}")
        fa, fn = arms[arm]["fit_all"], arms[arm]["fit_nocens"]
        if fa:
            print(f"    直线（全档，含未越阈档被丢弃者）斜率 {fa['slope']:.2f} R² {fa['r2']:.3f} n={fa['n']}")
        if fn:
            ci = fn["slope_ci95"]
            print(f"    直线（无删失档）斜率 {fn['slope']:.2f}  95%CI [{ci[0]:.2f},{ci[1]:.2f}]  "
                  f"R² {fn['r2']:.3f}  n={fn['n']}")
            print(f"      → 反推有效 λ = {fn['eff_lam']:.4f} "
                  f"(95%CI [{fn['eff_lam_ci95'][1]:.4f},{fn['eff_lam_ci95'][0]:.4f}])  "
                  f"真值 {LAM_TRUE:.4f}  偏差 {fn['dev']*100:+.0f}%")
        q = arms[arm]["quad"]
        if q:
            print(f"    线性性：二次项 {q['quad_coef']:+.5f} ± {q['quad_se']:.5f} "
                  f"(t={q['t_stat']:+.1f})  R² 线性 {q['r2_linear']:.3f} → 二次 {q['r2_quad']:.3f}")
            print("    分段斜率：" + "  ".join(
                f"b{s['db']-1}→{s['db']} {s['slope']:.1f}" for s in q["seg_slopes"]))
        th = arms[arm]["theory"]
        for mode in ("rss", "lin"):
            if mode in th["models"]:
                b2 = th["models"][mode]
                print(f"    理论曲线[{mode}] λ={b2['lam']:.4f} η0={b2['eta0']:.3f} "
                      f"RSS={b2['rss']:.2f} R²={b2['r2']:.4f}  "
                      f"（直线 RSS={th['linear']['rss']:.2f}）→ λ_fit 偏差 {b2['lam_dev']*100:+.0f}%")
    return arms, dict(lo=lo, hi=hi)


# ------------------------------------------------------------------ D
def part_d_truth():
    print("\n" + "=" * 88)
    print("  D. 真值洛伦兹映射的 λ₁（精确变分方程 RK4）")
    print("=" * 88)
    x0s = [np.array([1.0, 1.0, 20.0]), np.array([-8.0, 7.0, 27.0]),
           np.array([13.0, 12.0, 35.0])]
    rows = []
    print(f"  {'初值':<22} {'dt':>7} {'λ₁':>9} {'λ₂':>9} {'λ₃':>9} {'Σλ':>10} {'Σλ+13.667':>11}")
    for x0 in x0s:
        for dt in (0.01, 0.005, 0.0025):
            lam, used_t = qr_spectrum_flow(lorenz_rhs, lorenz_jac, x0=x0, t_total=400.0,
                                           dt=dt, reorth=10, discard_t=30.0)
            s = float(lam.sum())
            rows.append(dict(x0=x0.tolist(), dt=dt, lam=lam.tolist(), sum=s, used_t=float(used_t)))
            print(f"  {str(x0.tolist()):<22} {dt:>7.4f} {lam[0]:>+9.4f} {lam[1]:>+9.4f} "
                  f"{lam[2]:>+9.4f} {s:>+10.4f} {s + (10 + 1 + 8/3):>+11.2e}")
    lam1 = float(np.mean([r["lam"][0] for r in rows]))
    lams = np.array([r["lam"][0] for r in rows])
    res = {"rows": rows, "lam1_cont_mean": lam1, "lam1_cont_std": float(lams.std()),
           "lam1_step": lam1 * 0.05,
           "sum_check_max_err": max(abs(r["sum"] + (10 + 1 + 8/3)) for r in rows),
           "dt_convergence": {str(dt): [r["lam"][0] for r in rows if r["dt"] == dt]
                              for dt in (0.01, 0.005, 0.0025)}}
    print(f"\n  文献值（σ=10, ρ=28, β=8/3）：λ₁ ≈ 0.906")
    print(f"  本次 9 组（3 初值 × 3 dt）均值：λ₁ = {lam1:.4f} ± {lams.std():.4f}  "
          f"偏差 {(lam1-0.906)/0.906*100:+.2f}%")
    print(f"  折算模型步长 Δt=0.05：λ₁ = {res['lam1_step']:.5f}/步")
    print(f"  和检验 Σλ vs −(σ+1+β)：最大偏差 {res['sum_check_max_err']:.2e}")
    print(f"  （此前单步雅可比近似给 +0.0547，偏差 21%，已弃用）")
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--a-only", action="store_true")
    ap.add_argument("--d-only", action="store_true")
    a = ap.parse_args()
    out = {"_note": "T4b「+10% 闭合」的重新计算证明；取代原直线拟合结论",
           "lam_true_ref": LAM_TRUE, "bits_new": BITS_NEW, "steps_long": STEPS_LONG}
    if a.d_only:
        out["D_truth"] = part_d_truth()
    elif a.a_only:
        out["A_floor"] = part_a_floor()
        out["A2_refit"] = part_a2_refit()
        out["D_truth"] = part_d_truth()
    else:
        out["A_floor"] = part_a_floor()
        out["A2_refit"] = part_a2_refit()
        arms, rng = part_b_train_and_measure()
        out["B_arms"] = arms
        out["B_quant_range"] = rng
        out["D_truth"] = part_d_truth()
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"\n-> {os.path.relpath(OUT, ROOT)}")


if __name__ == "__main__":
    main()
