"""
T5 · 编码器与预测器位宽分配律

实验设计：
  分别单独量化编码器和预测器到不同位宽，比较二者的敏感性（谁需要更多位），
  并测量编码器量化后潜空间与原始潜空间的几何失配如何随 rollout 传播。
  外部参照（arXiv 2602.02110）的实证方向与朴素读法相反：只量化编码器 W4A8 时
  Wall 0.94→0.64、PushT 0.94→0.02，只量化预测器 W4A8 时 Wall 保持 0.94。

四个须避免的实现缺陷（对应「量化必须进入被测路径」原则）：
  - open 口径把全精度 z_ref 当初值：编码器量化对 open 零影响（量化未进入路径）
  - 用 T_crash 作观测口径指标：单步误差不累积，各位宽给出同一 T_crash（无分辨率）
  - 解码器臂没有指标经过解码器：各位宽结果完全相同
  - QR 的 f 未做与 rollout 一致的 clamp：迭代溢出

指标（三条，各自对应不同路径）：
  obs_cos   每步用真实帧经 vae_q 编码 → dyn_q 单步预测 → 与全精度 z_ref 比 cos（中位）
            —— 编码器误差**每步注入**，对应 DINO-WM 式闭环；不累积，故用 cos 而非 T_crash
  open_cos  从 **经 vae_q 编码的** 前两帧出发，dyn_q 自回归 18 步 → cos 曲线（均值与末步）
            —— 编码器只影响初值 + 预测器误差累积
  px_bce    用 vae_q 解码 open rollout → BCE / 地板（连续量，是唯一经过解码器的指标）

守卫：
  G-q1 量化必须改变权重（b<32 时不得逐位相同）
  G-q2 权重扰动随 b 减小单调不减
  G-q3 b=32 必须逐位恒等
  G-q4 重编码潜向量必须与磁盘缓存一致（否则生成器配置对不上）
  G-q5 **量化必须进入被测路径**：每个臂在 b=4 与 b=32 之间，至少一个指标差 > 容差；
       否则判定「该量化对象未接入任何被测路径」并报错
  G-q6 三个臂的「全精度基线」（各臂 b=32）必须互相一致

产物 logs/t5_alloc.json
"""
import argparse
import copy
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from vae import LATENT, CKPT, load_vae              # noqa: E402
from dyn import LatentDynamics                     # noqa: E402
from guards import G                               # noqa: E402

DEV = "cuda" if torch.cuda.is_available() else "cpu"
H = W = 64
CTX = 2
BITS = [3, 4, 5, 6, 8, 10, 12, 16, 32]
GRID = [4, 6, 8, 12, 16]
N_VAL = 64          # 默认值；实际用 --n-val
SPEEDS, GAMMA = (1, 2, 3), 0.0
PREFIX = {"enc": ["enc", "fc_mu"], "dec": ["fc_dec", "dec"], "dyn": ["net"]}
TOL = 1e-4          # 指标差异容差（守卫 G-q5）


# ----------------------------------------------------------------- 量化
def qsym(w, bits, per_channel=True):
    if bits >= 32:
        return w
    qmax = 2 ** (bits - 1) - 1
    if per_channel and w.dim() >= 2:
        amax = w.detach().abs().amax(dim=tuple(range(1, w.dim())), keepdim=True)
    else:
        amax = w.detach().abs().amax()
    scale = (amax / qmax).clamp_min(1e-12)
    return torch.clamp(torch.round(w / scale), -qmax, qmax) * scale


def quantize_modules(model, bits, prefixes, per_channel=True):
    m = copy.deepcopy(model)
    hit = 0
    for name, mod in m.named_modules():
        if not isinstance(mod, (nn.Conv2d, nn.Linear)):
            continue
        if prefixes is not None and not any(
                name == p or name.startswith(p + ".") or name.startswith(p) for p in prefixes):
            continue
        mod.weight.data = qsym(mod.weight.data, bits, per_channel)
        hit += 1
    assert hit > 0, f"量化了 0 个模块（prefixes={prefixes}）—— 白名单写错"
    return m, hit


def wdelta(orig, quant, prefixes):
    num = den = 0.0
    for (n1, m1), (n2, m2) in zip(orig.named_modules(), quant.named_modules()):
        if isinstance(m1, (nn.Conv2d, nn.Linear)) and any(n1.startswith(p) for p in prefixes):
            num += float(((m1.weight.detach() - m2.weight.detach()) ** 2).sum())
            den += float((m1.weight.detach() ** 2).sum())
    return math.sqrt(num / max(den, 1e-30))


# ----------------------------------------------------------------- 数据与指标
def load_everything():
    vae = load_vae()
    vae.load_state_dict(torch.load(os.path.join(CKPT, "vae_gray_s3.pt"),
                                   map_location=DEV, weights_only=True)["state"])
    vae.eval()
    sd = torch.load(os.path.join(CKPT, "dyn_gray_s3_ctx2.pt"),
                    map_location=DEV, weights_only=True)
    dyn = LatentDynamics(latent=sd["latent"], ctx=sd["ctx"]).to(DEV)
    dyn.load_state_dict(sd["state"])
    dyn.eval()
    return vae, dyn, sd["mean"].to(DEV), sd["std"].clamp_min(1e-6).to(DEV)


def encode_mu(vae, x_uint8):
    out = []
    with torch.no_grad():
        for i in range(0, x_uint8.shape[0], 256):
            xb = (x_uint8[i:i + 256].float() / 255.0).unsqueeze(1).to(DEV)
            out.append(vae.encode_det(xb).cpu())
    return torch.cat(out)


def decode(vae, z):
    with torch.no_grad():
        return torch.sigmoid(vae.decode(z.to(DEV))).cpu()


def rollout_obs(vae_q, dyn_q, imgs, mean, std):
    """观测步进：每步上下文来自真实帧经 vae_q 的编码 → dyn_q 单步预测。(N,T-CTX,L)"""
    n, T = imgs.shape[0], imgs.shape[1]
    ze = encode_mu(vae_q, imgs.reshape(-1, H, W)).view(n, T, LATENT).to(DEV)
    outs = []
    with torch.no_grad():
        for t in range(CTX, T):
            ca = ((ze[:, t - 2] - mean) / std).unsqueeze(1)
            cb = ((ze[:, t - 1] - mean) / std).unsqueeze(1)
            outs.append((dyn_q(torch.cat([ca, cb], 1)) * std + mean).cpu())
    return torch.stack(outs, dim=1)


def rollout_open(vae_q, dyn_q, imgs, mean, std):
    """纯推演：初值来自 **vae_q** 的编码（不是全精度 z_ref）→ dyn_q 自回归。"""
    n = imgs.shape[0]
    z = encode_mu(vae_q, imgs.reshape(-1, H, W)).view(n, imgs.shape[1], LATENT)
    ca, cb = z[:, 0].to(DEV), z[:, 1].to(DEV)
    outs = []
    with torch.no_grad():
        can, cbn = (ca - mean) / std, (cb - mean) / std
        for _ in range(imgs.shape[1] - CTX):
            pn = dyn_q(torch.stack([can, cbn], dim=1))
            raw = pn * std + mean
            outs.append(raw.cpu())
            can, cbn = cbn, pn
    return torch.stack(outs, dim=1)


def metrics(vae_q, dyn_q, imgs, z_ref, mean, std, floor):
    n = imgs.shape[0]
    P_obs = rollout_obs(vae_q, dyn_q, imgs, mean, std)
    cos_obs = F.cosine_similarity(P_obs, z_ref[:, CTX:], dim=-1)      # (N,18)
    P_open = rollout_open(vae_q, dyn_q, imgs, mean, std)
    cos_open = F.cosine_similarity(P_open, z_ref[:, CTX:], dim=-1)
    px = decode(vae_q, P_open.reshape(-1, LATENT)).view(n, 18, H, W)
    bce = F.binary_cross_entropy(px.clamp(1e-6, 1 - 1e-6),
                                 imgs[:, CTX:].float() / 255.0,
                                 reduction="none").flatten(2).mean(-1).mean()
    crash = [next((t + 1 for t in range(18) if cos_open[i, t] < 0.9), None)
             for i in range(n)]
    obs = [t for t in crash if t is not None]
    return dict(
        obs_cos=float(cos_obs.median()),
        obs_cos_p10=float(np.percentile(cos_obs.flatten().numpy(), 10)),
        open_cos=float(cos_open.median()),
        open_cos_last=float(cos_open[:, -1].median()),
        open_crash_med=float(np.median(obs)) if obs else None,
        open_crash_n=len(obs),
        px_bce=float(bce), px_ratio=float(bce / floor),
    )


# ----------------------------------------------------------------- 主流程
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phases", default="id,2d,geom")
    ap.add_argument("--per-tensor", action="store_true")
    ap.add_argument("--n-val", type=int, default=64,
                    help="验证序列数（潜向量缓存共 128 条）")
    ap.add_argument("--tag", default="", help="输出文件名后缀")
                    
    a = ap.parse_args()
    pc = not a.per_tensor
    nv = a.n_val
    out_path = os.path.join(ROOT, "logs",
                            "t5_alloc%s.json" % (("_" + a.tag) if a.tag else ""))
    phases = a.phases.split(",")
    t0 = time.time()
    torch.manual_seed(0)

    vae, dyn, mean, std = load_everything()
    imgs = torch.from_numpy(np.stack([
        __import__("variant2").VariantMNIST(nv, 999, False,
                                            speeds=SPEEDS, gamma=GAMMA)[i].numpy()
        for i in range(nv)]))
    G.input_stats(imgs.float(), "灰度验证帧")
    z_ref = encode_mu(vae, imgs.reshape(-1, H, W)).view(nv, 20, LATENT)
    zva = torch.load(os.path.join(CKPT, "latents_gray_s3__n_seq128_seed999.pt"),
                     map_location="cpu", weights_only=True)["z"][:nv]
    dmax = float((z_ref - zva).abs().max())
    print(f"\n  数据 {tuple(imgs.shape)}  非零像素 {float((imgs>0).float().mean())*100:.2f}%")
    print(f"  [G-q4] 重编码 vs 磁盘缓存最大差 {dmax:.2e}")
    assert dmax < 1e-3, "重编码与缓存不一致 —— 生成器/VAE 配置对不上"

    floor = float(F.binary_cross_entropy(
        decode(vae, z_ref[:, CTX:].reshape(-1, LATENT)).view(nv, 18, H, W).clamp(1e-6, 1 - 1e-6),
        imgs[:, CTX:].float() / 255.0, reduction="none").flatten(2).mean())
    base = metrics(vae, dyn, imgs, z_ref, mean, std, floor)
    print(f"  全精度基线：obs_cos {base['obs_cos']:.5f}  open_cos {base['open_cos']:.5f}  "
          f"末步 {base['open_cos_last']:.5f}  像素 {base['px_ratio']:.2f}× 地板")
    OUTD = {"config": dict(bits=BITS, grid=GRID, ctx=CTX, n_val=nv, speeds=SPEEDS,
                           gamma=GAMMA, per_channel=pc, phases=phases),
            "floor_bce": floor, "baseline": base,
            "_note": "T5 v2：三指标分离（obs_cos 编码器每步注入 / open_cos 累积 / px_bce 经解码器）"}

    # ---------------- 守卫
    print("\n" + "=" * 92)
    print("  守卫 G-q1/q2/q3：量化生效、扰动单调、b=32 恒等")
    print("=" * 92)
    deltas = {}
    for tag in ("enc", "dec", "dyn"):
        mod = vae if tag in ("enc", "dec") else dyn
        deltas[tag] = {}
        cells = []
        for b in BITS:
            q, _ = quantize_modules(mod, b, PREFIX[tag], pc)
            d = wdelta(mod, q, PREFIX[tag])
            deltas[tag][b] = d
            cells.append(f"b{b}:{d:.4f}")
            assert d > 0 if b < 32 else d == 0.0, f"{tag} b={b} 量化效果异常（{d}）"
        for i in range(len(BITS) - 1):
            assert deltas[tag][BITS[i]] >= deltas[tag][BITS[i + 1]] - 1e-9, \
                f"{tag} 扰动未随位宽单调（{BITS[i]}→{BITS[i+1]}）"
        print(f"  {tag:<4} " + "  ".join(cells))
    OUTD["weight_delta"] = deltas
    G.spaces("raw_latent", "raw_latent")

    # ---------------- Phase id：单独量化，谁更敏感
    if "id" in phases:
        print("\n" + "=" * 92)
        print("  Phase id：单独量化 enc / dec / dyn（全精度基线见上）")
        print("=" * 92)
        arms = {}
        for tag in ("enc", "dec", "dyn"):
            arms[tag] = []
            print(f"\n  [{tag}]   {'b':>3} {'obs_cos':>9} {'Δobs':>8} {'open_cos':>9} "
                  f"{'open末步':>9} {'T_crash':>8} {'像素/地板':>9}")
            for b in BITS:
                vq = quantize_modules(vae, b if tag in ("enc", "dec") else 32,
                                      PREFIX[tag] if tag in ("enc", "dec") else PREFIX["enc"], pc)[0]
                dq = quantize_modules(dyn, b if tag == "dyn" else 32, PREFIX["dyn"], pc)[0]
                m = metrics(vq, dq, imgs, z_ref, mean, std, floor)
                arms[tag].append(dict(bits=b, **m))
                print(f"        {b:>3} {m['obs_cos']:>9.5f} "
                      f"{m['obs_cos']-base['obs_cos']:>+8.5f} {m['open_cos']:>9.5f} "
                      f"{m['open_cos_last']:>9.5f} {str(m['open_crash_med']):>8} "
                      f"{m['px_ratio']:>8.3f}×")
            # G-q5：量化必须进入被测路径
            lo_b, hi_b = arms[tag][0], arms[tag][-1]      # b=3 与 b=32
            gaps = {k: abs(lo_b[k] - hi_b[k]) for k in
                    ("obs_cos", "open_cos", "open_cos_last", "px_ratio")}
            best = max(gaps.items(), key=lambda kv: kv[1])
            assert best[1] > TOL, \
                f"G-q5 失败：{tag} 在 b=3 与 b=32 的所有指标差都 < {TOL} —— 量化未进入被测路径"
            arms[tag + "_max_gap"] = best
            print(f"      [G-q5] 最大指标差 {best[0]} = {best[1]:.5f} > {TOL} ✓")
        OUTD["phase_id"] = {k: v for k, v in arms.items() if isinstance(v, list)}
        OUTD["phase_id_maxgap"] = {k.replace("_max_gap", ""): list(v)
                                   for k, v in arms.items() if k.endswith("_max_gap")}

    # ---------------- Phase 2d：热力图（用连续的 obs_cos / open_cos）
    if "2d" in phases:
        print("\n" + "=" * 92)
        print("  Phase 2d：不对称性热力图（数值 = 相对全精度基线的 obs_cos 损失 (%)）")
        print("=" * 92)
        heat = []
        print(f"    obs   {'':<6}" + "".join(f"{f'dyn={b}':>11}" for b in GRID))
        for be in GRID:
            vq = quantize_modules(vae, be, PREFIX["enc"], pc)[0]
            cells = []
            for bd in GRID:
                dq = quantize_modules(dyn, bd, PREFIX["dyn"], pc)[0]
                m = metrics(vq, dq, imgs, z_ref, mean, std, floor)
                loss = (base["obs_cos"] - m["obs_cos"]) / base["obs_cos"] * 100
                cells.append(dict(bits_enc=be, bits_dyn=bd, loss_pct=loss, **m))
            heat.append(dict(bits_enc=be, cells=cells))
            print(f"    enc={be:<3}" + "".join(f"{c['loss_pct']:>10.2f}%" for c in cells))
        print(f"    open  {'':<6}" + "".join(f"{f'dyn={b}':>11}" for b in GRID))
        for row in heat:
            print(f"    enc={row['bits_enc']:<3}" + "".join(
                f"{(base['open_cos']-c['open_cos'])/base['open_cos']*100:>10.2f}%"
                for c in row["cells"]))
        OUTD["phase_2d"] = {"grid": GRID, "rows": heat}

        print("\n    固定预算 B=16")
        budget = []
        for be in (4, 6, 8, 10, 12):
            bd = 16 - be
            vq = quantize_modules(vae, be, PREFIX["enc"], pc)[0]
            dq = quantize_modules(dyn, bd, PREFIX["dyn"], pc)[0]
            m = metrics(vq, dq, imgs, z_ref, mean, std, floor)
            loss = (base["obs_cos"] - m["obs_cos"]) / base["obs_cos"] * 100
            budget.append(dict(bits_enc=be, bits_dyn=bd, loss_pct=loss, **m))
            print(f"      (enc {be:>2}, dyn {bd:>2})  obs 损失 {loss:>6.2f}%  "
                  f"open_cos {m['open_cos']:.5f}  像素 {m['px_ratio']:.2f}×")
        OUTD["phase_budget"] = budget

    # ---------------- Phase geom：几何失配与传播
    if "geom" in phases:
        print("\n" + "=" * 92)
        print("  Phase geom：编码器量化的几何失配 + 随 rollout 的传播")
        print("=" * 92)
        print(f"    {'b':>3} {'‖Δμ‖/‖μ‖':>12} {'cos(μ_q,μ)':>11} {'mis²/个自由度':>14} "
              f"{'下游 obs_cos':>13} {'下游 open_cos':>13}")
        geom = []
        for b in BITS:
            vq = quantize_modules(vae, b, PREFIX["enc"], pc)[0]
            zq = encode_mu(vq, imgs.reshape(-1, H, W)).view(nv, 20, LATENT)
            rel = (zq - z_ref).norm(dim=-1).mean() / z_ref.norm(dim=-1).mean()
            cosq = float(F.cosine_similarity(zq.reshape(-1, LATENT),
                                             z_ref.reshape(-1, LATENT), dim=-1).median())
            mis2 = float(((zq - z_ref) ** 2).sum(-1).mean() /
                         (z_ref ** 2).sum(-1).mean())
            m = metrics(vq, dyn, imgs, z_ref, mean, std, floor)
            geom.append(dict(bits=b, rel=float(rel), cos_med=cosq, mis2=mis2, **m))
            print(f"    {b:>3} {float(rel):>12.5f} {cosq:>11.5f} {mis2:>14.6f} "
                  f"{m['obs_cos']:>13.5f} {m['open_cos']:>13.5f}")
        OUTD["phase_geom"] = geom

    # ---------------- Phase lam：QR λ₁ 敏感性（慢：128 维 QR × 14 次 ≈ 15 分钟，默认不跑）
    if "lam" in phases:
        print("\n" + "=" * 92)
        print("  Phase lam：QR λ₁ 对谁的量化敏感（预测：只随预测器量化变化）")
        print("=" * 92)
        lam_dyn = [dict(bits=b, lam1=qr_lam1_of(dyn, b, pc)) for b in (3, 4, 6, 8, 12, 16, 32)]
        print("    预测器量化 λ₁：" + "  ".join(f"b{r['bits']}:{r['lam1']:+.5f}" for r in lam_dyn))
        lam_enc = [dict(bits=b, lam1=qr_lam1_of(dyn, 32, pc)) for b in (3, 4, 6, 8, 12, 16, 32)]
        print("    编码器量化 λ₁：" + "  ".join(f"b{r['bits']}:{r['lam1']:+.5f}" for r in lam_enc)
              + "   （dyn 未变 → 恒等）")
        spread = max(r["lam1"] for r in lam_dyn) - min(r["lam1"] for r in lam_dyn)
        print(f"    预测器量化使 λ₁ 变化 {spread:.5f}；编码器量化使 λ₁ 变化 0（构造恒等）")
        OUTD["phase_lam"] = {"dyn": lam_dyn, "enc": lam_enc, "spread_dyn": spread}

    OUTD["elapsed_s"] = round(time.time() - t0, 1)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(OUTD, f, ensure_ascii=False, indent=2)
    print(f"\n-> {os.path.relpath(out_path, ROOT)}  （{OUTD['elapsed_s']}s）")


def qr_lam1_of(dyn_model, bits, per_channel=True):
    """对（可能量化的）dyn 用 QR 估 λ₁；轨迹用与 rollout 一致的 clamp。"""
    from lyap import qr_spectrum_map
    dq = quantize_modules(dyn_model, bits, PREFIX["dyn"], per_channel)[0]
    W = [dq.net[i].weight.detach().cpu().numpy().astype(np.float64) for i in (0, 2, 4)]
    b = [dq.net[i].bias.detach().cpu().numpy().astype(np.float64) for i in (0, 2)]
    b3 = dq.net[4].bias.detach().cpu().numpy().astype(np.float64)
    W1, W2, W3 = W
    b1, b2 = b

    def sig(h):
        return 1.0 / (1.0 + np.exp(-np.clip(h, -60, 60)))

    def silu(h):
        return h * sig(h)

    def dsilu(h):
        s = sig(h)
        return s + h * s * (1 - s)

    def f(u):
        a, bb = u[:LATENT], u[LATENT:]
        g2 = silu(W2 @ silu(W1 @ np.concatenate([a, bb]) + b1) + b2)
        out = np.concatenate([bb, bb + (bb - a) + W3 @ g2 + b3])
        return np.clip(out, -8.0, 8.0)          # 与 rollout 的 clamp(-8,8) 一致

    def jac(u):
        a, bb = u[:LATENT], u[LATENT:]
        h1 = W1 @ np.concatenate([a, bb]) + b1
        h2 = W2 @ silu(h1) + b2
        dd = W3 @ (dsilu(h2)[:, None] * (W2 @ (dsilu(h1)[:, None] * W1)))
        L, I = 2 * LATENT, np.eye(LATENT)
        J = np.zeros((L, L))
        J[:LATENT, LATENT:] = I
        J[LATENT:, :LATENT] = -I + dd[:, :LATENT]
        J[LATENT:, LATENT:] = 2 * I + dd[:, LATENT:]
        return J

    lam = qr_spectrum_map(f, jac, x0=np.zeros(2 * LATENT), n_steps=6000, discard=1500)
    return float(lam[0])


if __name__ == "__main__":
    main()
