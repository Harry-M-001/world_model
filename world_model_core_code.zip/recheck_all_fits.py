"""
统一复核所有 T_crash(b) 斜率拟合。

被复核的对象：
  T4  首轮实验 (logs/t4_lorenz.json)    slope d1 2.88 / d5 3.27
  T4b 三臂 (logs/t4b_arms.json)          single 6.10 / multistep 13.88 / reg 3.74
  T6  四臂 (logs/t6_reg.json)            base 4.37 / t0.0453 10.89 / t0.10 15.63 / t0.20 8.08

共同缺陷：**全部把 floor 档（Δ/2 > δ*，T_crash 恒为 1）纳入线性拟合**。
  Δ/2 = 2.475（b=4）> 1 = δ*  →  b=4 是 floor 档
  Δ/2 = 12.375（b=2）、5.303（b=3）同理
此外多数高 b 档存在严重右删失（窗口仅 300 步），而删失会低估 T_crash。

判据（缺一不可）：
  F  Δ/2 ≤ δ*（非 floor）
  C  删失率 ≤ 10%
输出：原值 vs 复核值的对照表 → logs/all_fits_recheck.json
"""
import json
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
LOG = os.path.join(ROOT, "logs")
OUT = os.path.join(LOG, "all_fits_recheck.json")


def fit(pts):
    x = np.array([p[0] for p in pts], float)
    y = np.array([p[1] for p in pts], float)
    A = np.vstack([x, np.ones_like(x)]).T
    (sl, ic), *_ = np.linalg.lstsq(A, y, rcond=None)
    pred = A @ np.array([sl, ic])
    r2 = 1 - ((y - pred) ** 2).sum() / ((y - y.mean()) ** 2).sum()
    return float(sl), float(ic), float(r2)


def load(n):
    with open(os.path.join(LOG, n), encoding="utf-8") as f:
        return json.load(f)


def delta_of(bits, lo_hi):
    return lo_hi / (2 ** bits - 1)


def main():
    t4 = load("t4_lorenz.json")
    t4b = load("t4b_arms.json")
    t6 = load("t6_reg.json")
    lam_true = t4b.get("lam_true", 0.0453)

    # delta 表：同一数据生成（gen_traj on uniform(-15,15,3)，N_STEPS=400）→ 各实验共用
    lo_hi = t4["rows"][0]["delta"] * (2 ** 2 - 1)
    print(f"统一量化范围 hi−lo = {lo_hi:.4f}（由 T4 的 b=2 档反推，与 T4b 一致："
          f"{abs(t4b['arms'][0]['rows'][0]['delta'] - t4['rows'][0]['delta']) < 1e-9}）")
    print(f"δ* = 1 的 floor 阈值：Δ/2 > 1 ⇔ Δ > 2 ⇔ b < "
          f"{math.log2(lo_hi / 2.0 + 1):.2f}  → b ≤ 4 是 floor 档\n")

    sets = []
    for r in t4["rows"]:
        sets.append(("T4 首轮实验", "d1", r["bits"], r["tcrash_med_d1"],
                     32 - r["n_censored_d1"], r["n_censored_d1"], t4["fit"]["d1"]["slope"]))
    for arm in t4b["arms"]:
        for r in arm["rows"]:
            if r["med_d1"] is None:
                continue
            sets.append((f"T4b {arm['arm']}", "d1", r["bits"], r["med_d1"],
                         r["n_1"], 32 - r["n_1"], arm["fit_d1"]["slope"]))
    for arm in t6["arms"]:
        for r in arm["tcrash"]:
            if r["med"] is None:
                continue
            sets.append((f"T6 {arm['arm']}", "d1", r["bits"], r["med"],
                         r["n"], 32 - r["n"], arm["fit"]["slope"]))

    groups = {}
    for name, ds, bits, med, n, cens, orig in sets:
        groups.setdefault((name, ds), {"pts": [], "orig": orig})
        groups[(name, ds)]["pts"].append(dict(bits=bits, delta=delta_of(bits, lo_hi),
                                              med=med, n=n, censored=cens,
                                              total=n + cens))

    print("=" * 108)
    print("  复核对照：斜率随筛选判据的变化（单位：步/位；反推 λ = log2/斜率）")
    print("=" * 108)
    print(f"  {'实验':<16} {'原报告':>8} {'含floor':>8} {'剔floor':>9} {'F+C可用':>9} "
          f"{'可用档位':<22} {'原→复核 变化':>12}")
    res = {}
    for (name, ds), g in groups.items():
        pts = g["pts"]
        variants = {}
        # 原报告口径：与源脚本一致 —— 全部非 None 档
        allp = [(p["bits"], p["med"]) for p in pts]
        variants["all"] = fit(allp) if len(allp) >= 3 else None
        nf = [p for p in pts if p["delta"] / 2 <= 1.0]
        variants["no_floor"] = fit([(p["bits"], p["med"]) for p in nf]) if len(nf) >= 3 else None
        fc = [p for p in nf if p["censored"] / max(p["total"], 1) <= 0.10]
        variants["F_C"] = fit([(p["bits"], p["med"]) for p in fc]) if len(fc) >= 3 else None
        bits_fc = [p["bits"] for p in fc]

        def gv(k):
            v = variants[k]
            return f"{v[0]:.2f}" if v else "—"

        o = variants["all"]
        f = variants["F_C"]
        chg = (f"{(f[0]-o[0])/o[0]*100:+.0f}%" if (o and f and o[0] > 0) else "—")
        print(f"  {name:<16} {g['orig']:>8.2f} {gv('all'):>8} {gv('no_floor'):>9} "
              f"{gv('F_C'):>9} {str(bits_fc):<22} {chg:>12}")
        res[name] = {"orig_reported": g["orig"], "points": pts,
                     "all": variants["all"], "no_floor": variants["no_floor"],
                     "F_C": variants["F_C"], "usable_bits": bits_fc}
        for k in ("all", "no_floor", "F_C"):
            v = variants[k]
            if v and v[0] > 0:
                eff = math.log(2) / v[0]
                res[name][k] = {"slope": v[0], "intercept": v[1], "r2": v[2],
                                "eff_lam": eff, "dev": (eff - lam_true) / lam_true}

    print()
    print("=" * 108)
    print("  各档的删失情况（说明为何不能用全部档）")
    print("=" * 108)
    print(f"  {'实验':<16} " + " ".join(f"{'b'+str(b):>12}" for b in (2, 3, 4, 6, 8, 12, 16)))
    for (name, ds), g in groups.items():
        cells = []
        for b in (2, 3, 4, 6, 8, 12, 16):
            p = next((x for x in g["pts"] if x["bits"] == b), None)
            if p is None:
                cells.append(f"{'—':>12}")
            else:
                rate = p["censored"] / max(p["total"], 1)
                mark = "F" if p["delta"] / 2 > 1.0 else ("!" if rate > 0.10 else " ")
                cells.append(f"{p['med']:>7.1f}{mark}({p['n']:>2})")
        print(f"  {name:<16} " + " ".join(cells))
    print("\n  标记：F = floor 档（Δ/2>1，必崩）；! = 删失率 >10%；() 内为有效样本数/32")

    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"lo_hi": lo_hi, "lam_true": lam_true, "results": res},
                  f, ensure_ascii=False, indent=2)
    print(f"\n-> {os.path.relpath(OUT, ROOT)}")


if __name__ == "__main__":
    sys.exit(main())
