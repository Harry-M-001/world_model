"""T15 判据③的加强版：反事实效应改用**像素空间质心位移**（潜空间距离区分度只有 0.11，太弱）。

用同一个初始状态，分别执行「全程 +1」「全程 −1」「全程 0」的动作序列，
解码到像素后测量墨迹质心位移 —— 这样才有物理可解释的判据。
"""
import json
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from vae import LATENT, CKPT, load_vae                       # noqa: E402
from t15_action import ActDynamics, CTX, DEV, H, W          # noqa: E402

OUT = os.path.join(ROOT, "logs", "t15_cf.json")


def main():
    d = torch.load(os.path.join(CKPT, "t15_act_data.pt"), map_location="cpu",
                   weights_only=False)
    zva = d["zva"]
    mean = zva.mean(dim=(0, 1)).to(DEV)
    std = zva.std(dim=(0, 1)).clamp_min(1e-6).to(DEV)
    m = ActDynamics().to(DEV)
    m.load_state_dict(torch.load(os.path.join(CKPT, "t15_act_dyn.pt"),
                                map_location=DEV, weights_only=False)["state"])
    m.eval()
    vae = load_vae()
    vae.load_state_dict(torch.load(os.path.join(CKPT, "vae_gray_s3.pt"),
                                  map_location=DEV, weights_only=True)["state"])
    vae.eval()

    n, steps = 64, 12
    yy, xx = torch.meshgrid(torch.arange(H), torch.arange(W), indexing="ij")
    yy, xx = yy.float(), xx.float()

    def centroid(img):
        s = img.sum(dim=(-1, -2)).clamp_min(1e-6)
        cy = (img * yy).sum(dim=(-1, -2)) / s
        cx = (img * xx).sum(dim=(-1, -2)) / s
        return torch.stack([cx, cy], dim=-1)

    res = {}
    print("=" * 88)
    print("  判据③（加强）：反事实的动作效应 —— 像素空间质心位移")
    print("=" * 88)
    print(f"  {'动作序列':<16} {'末帧质心位移 ‖Δc‖':>18} {'相对 零动作 的增量':>20}")
    base_c = None
    for name, (ax, ay) in (("全程 (+1,+1)", (1, 1)), ("全程 (−1,−1)", (-1, -1)),
                           ("全程 (0,0)", (0, 0))):
        with torch.no_grad():
            ca = ((zva[:n, 0].to(DEV) - mean) / std).unsqueeze(1)
            cb = ((zva[:n, 1].to(DEV) - mean) / std).unsqueeze(1)
            zc = torch.cat([ca, cb], dim=1)
            a = torch.tensor([ax, ay], dtype=torch.float32, device=DEV).expand(n, 2)
            traj = []
            for _ in range(steps):
                p = m(zc, a)
                traj.append(p * std + mean)
                zc = torch.cat([zc[:, 1:], p.unsqueeze(1)], dim=1)
            P = torch.stack(traj)                          # (steps, n, L)
            img = torch.sigmoid(vae.decode(P.reshape(-1, LATENT).to(DEV)))
            img = img.view(steps, n, H, W).cpu()
        c0 = centroid(img[0])
        c1 = centroid(img[-1])
        dc = (c1 - c0).norm(dim=-1)
        res[name] = float(dc.mean())
        if name.endswith("(0,0)"):
            base_c = c1.mean(dim=0)
        print(f"  {name:<16} {dc.mean():>18.4f}", end="")
        if base_c is not None:
            pass
        print()
    # 相对零动作的增量（在像素空间里比）
    dp = abs(res["全程 (+1,+1)"] - res["全程 (0,0)"])
    dm = abs(res["全程 (−1,−1)"] - res["全程 (0,0)"])
    print(f"\n  对照：|plus − zero| = {dp:.4f}   |minus − zero| = {dm:.4f}")
    print("  说明：plus/minus 的动作方向相反 → 两组位移的模长接近是**正常**的；")
    print("        真正该看的是「位移向量是否反向」。下面测方向：")
    # 方向判据：末帧质心的平均位移向量
    dirs = {}
    for name, (ax, ay) in (("plus", (1, 1)), ("minus", (-1, -1))):
        with torch.no_grad():
            ca = ((zva[:n, 0].to(DEV) - mean) / std).unsqueeze(1)
            cb = ((zva[:n, 1].to(DEV) - mean) / std).unsqueeze(1)
            zc = torch.cat([ca, cb], dim=1)
            a = torch.tensor([ax, ay], dtype=torch.float32, device=DEV).expand(n, 2)
            traj = []
            for _ in range(steps):
                p = m(zc, a)
                traj.append(p * std + mean)
                zc = torch.cat([zc[:, 1:], p.unsqueeze(1)], dim=1)
            P = torch.stack(traj)
            img = torch.sigmoid(vae.decode(P.reshape(-1, LATENT).to(DEV))).view(steps, n, H, W).cpu()
        dirs[name] = (centroid(img[-1]) - centroid(img[0])).mean(dim=0)
    cos = F.cosine_similarity(dirs["plus"][None], dirs["minus"][None]).item()
    print(f"  plus 的位移向量 {np.round(dirs['plus'].numpy(), 3).tolist()}")
    print(f"  minus 的位移向量 {np.round(dirs['minus'].numpy(), 3).tolist()}")
    print(f"  两者余弦 = {cos:+.4f}  → " +
          ("**方向相反（正确）**" if cos < -0.3 else "方向不明确"))
    res["cos_plus_minus"] = cos
    res["dir_plus"] = dirs["plus"].numpy().tolist()
    res["dir_minus"] = dirs["minus"].numpy().tolist()
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print(f"\n-> logs/t15_cf.json")


if __name__ == "__main__":
    main()
