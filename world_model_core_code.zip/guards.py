"""
guards.py —— 针对七类已知静默失效的确定性守卫
=====================================================================
这类失效的共同特征是不报错、指标表面正常，无法靠人工留意避免，
必须实现为机器可判的断言。

各守卫分别对应一类已知失效：

  G1 input_stats        数据表示与下游约定不一致（0/1 的图又除 255）
  G2 loss_reduction     归约维度写错（ELBO 重建项只求通道维 → KL 独占 → 后验塌缩）
  G3 loss_parts         分项量级失衡（打印，供人判断；量级差百倍必须解释）
  G4 cache_meta         缓存键缺少影响结果的参数（加数据静默失效）
  G5 shape              诊断量形状错误（64 维说成 256 维）
  G6 spaces + counterfactual + criteria_separation
                        优化目标与验收指标不在同一空间；判据无法被失败；阈值耦合

**自检**：`python guards.py` 对每类失效构造触发样例，要求对应守卫报错；
未被触发验证过的守卫不视为有效。

用法：
    from guards import G
    G.input_stats(x, "VAE 输入", kind="binary")
    G.loss_reduction(rec_impl, rec_ref, "重建项")
    G.loss_parts({"rec": rec, "kl": kl})
    G.cache_meta(path, n_seq=12000, seed=0)
    G.shape(kd, (64,), "逐维 KL")
    G.spaces(metric="原始潜空间余弦", loss="原始潜空间 MSE")
    G.counterfactual("单步潜余弦", threshold=0.9, degenerate=0.31, direction="min")
    G.criteria_separation(("单步判据", 0.9), ("T_crash", 5.0, "relative"))
    G.summary()      # 打印通过项，若有失败则在此之前已抛异常
"""
import math
import os
import sys

import numpy as np


class GuardError(AssertionError):
    """守卫失败。消息必须包含：哪条守卫、实测值、期望、以及该怎么修。"""


class _Guards:
    def __init__(self):
        self.passed = []

    # ---------------------------------------------------------------- G1
    def input_stats(self, x, name, kind="any", expect_shape=None):
        """G1 数据表示守卫。

        失效情形：mvmnist 生成 0/1 二值图，若 to_img 中再除以 255.0，
        喂入 VAE 的是几乎全黑的图，BCE≈0、KL 塌缩，但 loss 曲线表面正常。
        """
        a = x.detach().cpu().numpy() if hasattr(x, "detach") else np.asarray(x)
        if expect_shape is not None:
            # register=False：形状是 G1 的前置条件，不单独计入通过项，免得重复计数
            self.shape(a, expect_shape, f"{name}.shape", register=False)
        stats = dict(shape=a.shape, min=float(a.min()), max=float(a.max()),
                     mean=float(a.mean()))
        print(f"  [G1] {name}: shape {stats['shape']}  min {stats['min']:.4f}  "
              f"max {stats['max']:.4f}  mean {stats['mean']:.4f}")
        if not np.isfinite(a).all():
            raise GuardError(f"[G1] {name} 含 NaN/Inf")
        if kind == "binary":
            uniq = np.unique(a)
            if stats["max"] <= 0.5:
                raise GuardError(
                    f"[G1] {name} max={stats['max']:.4f} <= 0.5 —— 声明为二值图却几乎是全黑。"
                    f" 最常见原因：数据本身是 0/1，下游又除了一次 255。")
            bad = [float(v) for v in uniq if not (abs(v) < 1e-6 or abs(v - 1) < 1e-6)]
            if bad:
                raise GuardError(
                    f"[G1] {name} 声明为二值图，但出现了非 0/1 取值 {bad[:5]}"
                    f"（共 {len(bad)} 种）—— 检查是不是把 0/1 当 0/255 用了。")
        if kind == "any" and stats["max"] - stats["min"] < 1e-8:
            raise GuardError(f"[G1] {name} 是常数张量（max==min={stats['max']:.6g}）")
        self.passed.append(f"G1 {name}")
        return stats

    # ---------------------------------------------------------------- G2
    def loss_reduction(self, value, reference, name, tol=1e-6):
        """G2 归约口径守卫。

        失效情形：BCE(...).sum(1).mean() 中 sum(1) 只对通道维（size=1）求和，
        得到逐像素平均而非全像素求和，与 KL 差两个数量级，导致 KL 独占、后验塌缩。
        本守卫用独立重算的参考值对拍，口径写错必然对不上。
        """
        v, r = float(value), float(reference)
        rel = abs(v - r) / max(abs(r), 1e-12)
        print(f"  [G2] {name}: 实现 {v:.6f}  独立重算 {r:.6f}  相对误差 {rel:.2e}")
        if rel > tol:
            raise GuardError(
                f"[G2] {name} 归约口径对不上：实现 {v:.6f} vs 独立重算 {r:.6f}"
                f"（相对误差 {rel:.2e} > {tol:.0e}）。"
                f" 检查 sum(axis=?) 到底归约了哪些维 —— 只归约通道维是最常见的写法。")
        self.passed.append(f"G2 {name}")

    # ---------------------------------------------------------------- G3
    def loss_parts(self, parts, name="loss", warn_ratio=50.0):
        """G3 分项量级（信息项，不做硬失败）。

        能力边界：本守卫不拦截量级差约 17.8 倍的失衡（重建项逐像素平均 0.18 对
        KL 3.2，即使阈值降到 20 也不触发）；该类问题由 G2（独立重算对拍）检出。
        G3 的作用是展示各分项量级，并对超过 50 倍的明显失衡给出警告。
        """
        vals = {k: float(v) for k, v in parts.items()}
        pos = {k: v for k, v in vals.items() if v > 0}
        print(f"  [G3] {name} 分项: " + "  ".join(f"{k}={v:.4f}" for k, v in vals.items()))
        if len(pos) >= 2:
            hi = max(pos.values())
            lo = min(pos.values())
            if hi / max(lo, 1e-12) > warn_ratio:
                kmax = max(pos, key=pos.get)
                kmin = min(pos, key=pos.get)
                print(f"  [G3] ⚠ 量级差 {hi/lo:.0f}×（{kmax} vs {kmin}）——"
                      f" 若这不是有意加权，检查归约口径")
        self.passed.append(f"G3 {name}")

    # ---------------------------------------------------------------- G4
    def cache_key(self, tag, params):
        """生成缓存文件名：所有影响结果的参数都进名字。"""
        body = "_".join(f"{k}{params[k]}" for k in sorted(params))
        return f"{tag}__{body}"

    def cache_meta(self, path, **params):
        """G4 缓存键守卫（两半）。

        失效情形：潜向量缓存若只按固定名称命名，N_TRAIN_SEQ 改变后会命中旧缓存，
        数据量变化不生效且日志无异常。
        两半检查：
          ① 文件名里必须出现每个参数的取值；
          ② 若缓存文件存在，里面存的元数据必须与当前参数一致。
        """
        base = os.path.basename(path)
        for k, v in params.items():
            tok = f"{k}{v}"
            if tok not in base:
                raise GuardError(
                    f"[G4] 缓存文件名 '{base}' 里找不到参数 {k}={v}（期望片段 '{tok}'）。"
                    f" 只用 split 名做缓存键，会在改了数据规模/种子后静默命中过期数据。")
        if os.path.exists(path):
            import torch
            meta = torch.load(path, map_location="cpu", weights_only=False)
            for k, v in params.items():
                if isinstance(meta, dict) and k in meta and meta[k] != v:
                    raise GuardError(
                        f"[G4] 缓存 {base} 里记录的 {k}={meta[k]}，与当前的 {v} 不一致 ——"
                        f" 缓存键少了这个参数，会拿到过期数据。")
        print(f"  [G4] 缓存键 '{base}' 覆盖参数 {sorted(params)}"
              + (f"，且缓存已存在且元数据一致" if os.path.exists(path) else "（尚无缓存）"))
        self.passed.append(f"G4 {base}")

    # ---------------------------------------------------------------- G5
    def shape(self, arr, expected, name, register=True):
        """G5 诊断量形状守卫。expected 里的 None 表示该维不校验（如 batch 维）。

        失效情形：逐维 KL 在 4 个 batch 上各得 (64,)，若直接 torch.cat 成 (256,)，
        会报出错误的「活跃潜维 256/256」。诊断数字容易被直接引用，须断言校验。
        """
        got = tuple(arr.shape) if hasattr(arr, "shape") else tuple(np.shape(arr))
        exp = tuple(expected)
        print(f"  [G5] {name}.shape = {got}（期望 {exp}，None = 任意）")
        if len(got) != len(exp) or any(e is not None and g != e for g, e in zip(got, exp)):
            raise GuardError(f"[G5] {name} 形状 {got} != 期望 {exp}。"
                             f" 多 batch 的量请先按 batch 平均再拼接，不要直接 cat。")
        if register:
            self.passed.append(f"G5 {name}")

    # ---------------------------------------------------------------- G6a
    def spaces(self, metric_space, loss_space, metric_desc="", loss_desc=""):
        """G6a 判据与目标必须同空间。

        失效情形：判据用原始潜空间余弦，损失却在逐维归一化空间算 MSE。
        二者不等价：给定 |b| 时最小化 |a−b|² 等价于最大化余弦，
        归一化会把权重移向低方差维度；统一到原始空间后单步余弦由 0.874 升至 0.906。

        空间一致性须用规范化标签比对，而非中文字符串匹配：后者会因措辞不同
        误报，也容易被重复表述绕过。标签供机器判定，散文描述仅供阅读。
        标签建议：raw_latent / per_dim_normalized / normalized_unit / pixel / logit。
        """
        print(f"  [G6a] 判据空间 [{metric_space}] {metric_desc}")
        print(f"  [G6a] 损失空间 [{loss_space}] {loss_desc}")
        if metric_space != loss_space:
            raise GuardError(
                f"[G6a] 判据的空间标签是 '{metric_space}'，损失的空间标签是 '{loss_space}'"
                f" —— 两者不一致。优化目标和验收指标不在同一空间时，指标不动不是模型的问题。"
                f" 若确为有意设计（如指标在原始尺度、损失在归一化尺度以利优化），"
                f" 请显式改写这里，并在报告里说明这个不一致带来的影响。")
        self.passed.append(f"G6a spaces [{metric_space}]")

    # ---------------------------------------------------------------- G6b
    def counterfactual(self, name, threshold, degenerate, direction="min"):
        """G6b 反事实基线：假设模型什么都没学到，这个判据会通过吗？

        `degenerate` 是退化预测（常数 / 拷贝上一帧 / 随机）在该指标上的取值。
        direction="min"：指标须 ≥ threshold 才算过；"max"：须 ≤ threshold。
        若退化基线自己就能过阈，这个判据不具判别力。
        """
        t, d = float(threshold), float(degenerate)
        print(f"  [G6b] {name}: 阈值 {t:g}（{direction}）  退化基线 {d:.4f}")
        ok = (d >= t) if direction == "min" else (d <= t)
        if ok:
            raise GuardError(
                f"[G6b] {name} 的退化基线 {d:.4f} 自己就满足阈值 {t:g}"
                f"（方向 {direction}）—— 判据无法被失败，等于没有判据。"
                f" 请把门槛提到判别力区间，或改用尺度无关的相对判据。")
        self.passed.append(f"G6b {name}")

    # ---------------------------------------------------------------- G6c
    def criteria_separation(self, gate, crash):
        """G6c 绝对门槛与崩溃阈值不得共用同一个常数。

        失效情形：单步判据与崩溃判据共用 0.9 时，
        只要单步未达 0.9，T_crash 必然为 1，这是定义导致的必然，而非实验发现。
        gate  = (名称, 数值)
        crash = (名称, 数值, "absolute"|"relative")
        """
        gname, gval = gate
        cname, cval, ckind = crash
        print(f"  [G6c] 门槛 {gname}={gval:g}   崩溃判据 {cname}={cval:g}（{ckind}）")
        if ckind == "absolute" and abs(gval - cval) < 1e-12:
            raise GuardError(
                f"[G6c] 崩溃判据 {cname} 与单步门槛 {gname} 共用同一个常数 {gval:g}。"
                f" 于是单步不达标时 T_crash 必然 = 1 —— 这是定义上的必然，不是发现。"
                f" 崩溃必须用尺度无关的**相对增长**判据（如 > k×自身误差地板）。")
        if ckind not in ("absolute", "relative"):
            raise GuardError(f"[G6c] 崩溃判据 {cname} 的类型必须是 absolute/relative")
        self.passed.append(f"G6c {cname}")

    # ---------------------------------------------------------------- G7
    def metric_margin(self, name, value, trivial, min_margin):
        """G7 指标余量守卫：准确率类指标必须与「平凡基线」拉开足够余量。

        失效情形：重建逐像素一致率可达 98.47%，但 64×64 画布上墨迹仅占约 4.9%，
        全黑预测的一致率就有 95.1%，真实余量仅约 3.4 个百分点；
        不报告平凡基线的准确率具有误导性。

        同类指标一律要跑这条：像素一致率（对全黑/全白）、分类准确率（对多数类）、
        IoU（对空预测）、cos（对退化预测，见 G6b）。
        """
        v, t, m = float(value), float(trivial), float(min_margin)
        print(f"  [G7] {name}: 实测 {v:.4f}  平凡基线 {t:.4f}  余量 {v-t:+.4f}"
              f"（要求 ≥ {m:g}）")
        if v < t:
            raise GuardError(f"[G7] {name} 实测 {v:.4f} **低于**平凡基线 {t:.4f}"
                             f" —— 模型比什么都不做还差。")
        if v - t < m:
            raise GuardError(
                f"[G7] {name} 与平凡基线只差 {v-t:.4f} < {m:g}。"
                f" 这个指标几乎全靠「背景红利」拿到，必须在报告里同时给出平凡基线与"
                f"前景/正类上的指标（IoU / 召回），否则会严重高估模型。")
        self.passed.append(f"G7 {name}")

    # ----------------------------------------------------------------
    def summary(self):
        print("\n" + "=" * 70)
        print(f"  守卫层通过 {len(self.passed)} 项：")
        for p in self.passed:
            print(f"    ✓ {p}")
        print("=" * 70)
        return 0


G = _Guards()


# ==================================================================== 自检
def _selftest():
    """故意制造每一个 bug，对应守卫必须报错。没报错 = 这条守卫是假的。"""
    import torch
    import torch.nn.functional as F

    print("=" * 70)
    print("  守卫层自检：故意制造 8 类真实 bug，每一条守卫都必须亮红")
    print("=" * 70)
    results = []

    def expect_fail(tag, fn):
        try:
            fn()
        except GuardError as e:
            print(f"  ✓ {tag} 守卫正确报错：{str(e)[:88]}...")
            results.append((tag, True))
            return
        except Exception as e:  # noqa: BLE001
            print(f"  ✗ {tag} 报错类型不对: {type(e).__name__}: {e}")
            results.append((tag, False))
            return
        print(f"  ✗ {tag} **守卫没响** —— 这条守卫是假的")
        results.append((tag, False))

    # G1：0/1 的二值图又除 255
    img = torch.zeros(4, 1, 8, 8)
    img[:, :, 2:5, 2:5] = 1.0
    expect_fail("G1 数据又除 255", lambda: G.input_stats(img / 255.0, "图", kind="binary"))
    # G1 正常路径
    G.input_stats(img, "图（正常）", kind="binary")

    # G2：重建项只归约通道维
    x = (torch.rand(8, 1, 16, 16) > 0.9).float()
    logits = torch.randn(8, 1, 16, 16)
    el = F.binary_cross_entropy_with_logits(logits, x, reduction="none")
    wrong = float(el.sum(1).mean())
    right = float(el.flatten(1).sum(1).mean())
    expect_fail("G2 sum(1) 只求通道维",
                lambda: G.loss_reduction(wrong, right, "重建项"))
    G.loss_reduction(right, right, "重建项（正常）")

    # G3：量级失衡只警告不失败
    G.loss_parts({"rec": 0.18, "kl": 3.2}, "塌缩时的分项")

    # G4：缓存键缺参数
    expect_fail("G4 缓存键缺参数",
                lambda: G.cache_meta("/tmp/latents_train.pt", n_seq=12000, seed=0))
    G.cache_meta("/tmp/" + G.cache_key("latents_train", dict(n_seq=12000, seed=0)),
                 n_seq=12000, seed=0)

    # G5：诊断量形状错
    kd = torch.zeros(256)          # 4 个 batch 的 (64,) 被直接 cat
    expect_fail("G5 64 维说成 256 维", lambda: G.shape(kd, (64,), "逐维 KL"))
    G.shape(torch.zeros(64), (64,), "逐维 KL（正常）")

    # G6a：判据与损失不同空间
    expect_fail("G6a 判据/损失不同空间",
                lambda: G.spaces("raw_latent", "per_dim_normalized"))
    G.spaces("raw_latent", "raw_latent",
             "原始潜空间余弦 cos(z_pred, z_true)", "原始潜空间 MSE")

    # G6b：退化基线自己就能过阈
    expect_fail("G6b 退化基线也能过阈",
                lambda: G.counterfactual("单步余弦", threshold=0.9,
                                         degenerate=0.95, direction="min"))
    G.counterfactual("单步余弦", threshold=0.9, degenerate=0.31, direction="min")

    # G6c：崩溃阈值与门槛共用常数
    expect_fail("G6c 阈值耦合",
                lambda: G.criteria_separation(("单步判据", 0.9), ("T_crash", 0.9, "absolute")))
    G.criteria_separation(("单步判据", 0.9), ("T_crash 像素", 5.0, "relative"))

    # G7：指标余量不足（全靠背景红利）
    expect_fail("G7 指标余量不足",
                lambda: G.metric_margin("重建一致率", value=0.9854,
                                        trivial=0.9510, min_margin=0.04))
    G.metric_margin("重建一致率（正常）", value=0.9854, trivial=0.9510, min_margin=0.02)

    G.summary()
    bad = [t for t, ok in results if not ok]
    print(f"\n  自检结论：{len(results)-len(bad)}/{len(results)} 条守卫可被证伪")
    if bad:
        print("  失效的守卫：" + ", ".join(bad))
        return 1
    print("  全部守卫都能在自己的 bug 上亮红 —— 它们不是摆设。")
    return 0


if __name__ == "__main__":
    sys.exit(_selftest())
