"""
T4b 三臂对照：单步 MSE 学不到洛伦兹的扩张性（λ₁≈0 vs 真值 +0.045/步）。
检验哪种训练机制能使 λ₁(模型) ≈ λ₁(真值)，并在该臂上完成 T4 对数律检验。

三臂（同一数据、同一网络、同一轮数）：
  single    单步 MSE（基线，λ₁≈0）
  multistep Σ_{k=1..K} MSE(f^k(z_t), z_{t+k})，K=5（在展开误差上训练）
  reg       单步 MSE + μ·relu(λ_target − λ̂₁)，λ̂₁ 幂迭代（可微，解析雅可比）
            —— 正则变体：将 λ₁ 向真值方向提高（基线模型过于收缩）。

每臂评估：
  ① QR λ₁（解析雅可比）—— 主指标：与真值 +0.0453 的相对偏差
  ② 单步 val MSE（精度不能崩）
  ③ 量化扫描 → T_crash(b) 拟合，斜率 vs log2/λ₁(自身)
     —— 对数律在「λ₁ 正确」的臂上应当闭合

产物 logs/t4b_arms.json
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from lyap import qr_spectrum_map  # noqa: E402
from guards import G  # noqa: E402

DEV = "cuda" if torch.cuda.is_available() else "cpu"
SIG, RHO, BETA = 10.0, 28.0, 8.0 / 3.0
DT_FINE, SKIP = 0.005, 10
N_TRAJ, N_STEPS, TRANSIENT = 64, 400, 500
LAM_TRUE = 0.906 * SKIP * DT_FINE          # +0.0453 /步


def rhs(s):
    x, y, z = s
    return np.array([SIG * (y - x), x * (RHO - z) - y, x * y - BETA * z])


def rk4(s, dt):
    k1 = rhs(s)
    k2 = rhs(s + 0.5 * dt * k1)
    k3 = rhs(s + 0.5 * dt * k2)
    k4 = rhs(s + dt * k3)
    return s + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)


def gen_traj(s0, n):
    s = np.asarray(s0, dtype=np.float64).copy()
    for _ in range(TRANSIENT):
        s = rk4(s, DT_FINE)
    out = [s.copy()]
    for _ in range(n):
        for _ in range(SKIP):
            s = rk4(s, DT_FINE)
        out.append(s.copy())
    return np.array(out)


def quantize(z, bits, lo, hi):
    if bits >= 32:
        return z
    delta = (hi - lo) / (2 ** bits - 1)
    return torch.clamp(torch.round(z / delta), lo / delta, hi / delta) * delta


class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(3, 64), nn.Tanh(),
                                 nn.Linear(64, 64), nn.Tanh(), nn.Linear(64, 3))

    def forward(self, x):
        return self.net(x)

    def jac(self, x):
        """3×3 解析雅可比（torch，可微）。x: (P,3) 或 (3,)"""
        L = self.net
        W1, b1 = L[0].weight, L[0].bias
        W2, b2 = L[2].weight, L[2].bias
        W3 = L[4].weight
        single = x.dim() == 1
        if single:
            x = x[None]
        h1 = x @ W1.T + b1
        a1 = torch.tanh(h1)
        a2 = torch.tanh(a1 @ W2.T + b2)
        D1 = 1 - a1 ** 2
        D2 = 1 - a2 ** 2
        J = torch.einsum("oi,pi,ij,pj,jk->pko", W3, D2, W2, D1, W1)
        return J[0] if single else J


def lam1_power(m, pts, iters=8):
    """可微 λ̂₁ 代理：幂迭代估 log‖J‖₂，对采样点取均值。"""
    est = []
    for x in pts:
        v = torch.randn(3, device=x.device)
        J = m.jac(x)
        for _ in range(iters):
            w = J @ v
            v = w / (w.norm() + 1e-12)
        est.append(torch.log((J @ v).norm() + 1e-12))
    return torch.stack(est).mean()


def qr_lam1(m):
    W1 = m.net[0].weight.detach().cpu().numpy().astype(np.float64)
    b1 = m.net[0].bias.detach().cpu().numpy().astype(np.float64)
    W2 = m.net[2].weight.detach().cpu().numpy().astype(np.float64)
    b2 = m.net[2].bias.detach().cpu().numpy().astype(np.float64)
    W3 = m.net[4].weight.detach().cpu().numpy().astype(np.float64)
    b3 = m.net[4].bias.detach().cpu().numpy().astype(np.float64)

    def f(s):
        s = np.asarray(s, dtype=np.float64)
        a1 = np.tanh(W1 @ s + b1)
        a2 = np.tanh(W2 @ a1 + b2)
        return W3 @ a2 + b3

    def jac(s):
        s = np.asarray(s, dtype=np.float64)
        a1 = np.tanh(W1 @ s + b1)
        a2 = np.tanh(W2 @ a1 + b2)
        return W3 @ np.diag(1 - a2 ** 2) @ W2 @ np.diag(1 - a1 ** 2) @ W1

    lam = qr_spectrum_map(f, jac, x0=np.array([1.0, 1.0, 20.0]),
                          n_steps=20000, discard=5000)
    return float(lam[0]), lam.tolist()


def tcrash_curve(m, ics, bits_list, lo, hi, steps=300, dstar=(1.0, 5.0)):
    out = []
    for bits in bits_list:
        rec = dict(bits=bits, delta=(hi - lo) / (2 ** bits - 1))
        for ds in dstar:
            ts = []
            for z0 in ics:
                with torch.no_grad():
                    s_ref = torch.tensor(z0, dtype=torch.float32, device=DEV)
                    s_q = s_ref.clone()
                    hit = None
                    for t in range(steps):
                        if t > 0:
                            s_ref = m(s_ref)
                            s_q = quantize(m(s_q), bits, lo, hi)
                        if float((s_q - s_ref).norm()) > ds:
                            hit = t
                            break
                    if hit is not None:
                        ts.append(hit)
            rec[f"med_d{int(ds)}"] = float(np.median(ts)) if ts else None
            rec[f"n_{int(ds)}"] = len(ts)
        out.append(rec)
    return out


def fit_line(rows, key):
    pts = [(r["bits"], r[key]) for r in rows if r.get(key) is not None]
    if len(pts) < 3:
        return None
    bb = np.array([p[0] for p in pts], float)
    tt = np.array([p[1] for p in pts], float)
    A = np.vstack([bb, np.ones_like(bb)]).T
    (sl, ic), *_ = np.linalg.lstsq(A, tt, rcond=None)
    pred = A @ np.array([sl, ic])
    r2 = 1 - ((tt - pred) ** 2).sum() / ((tt - tt.mean()) ** 2).sum()
    return dict(slope=float(sl), intercept=float(ic), r2=float(r2), n=len(pts))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=600)
    ap.add_argument("--K", type=int, default=5)
    ap.add_argument("--mu", type=float, default=5.0)
    ap.add_argument("--n-ic", type=int, default=32)
    a = ap.parse_args()
    torch.manual_seed(0)
    rng = np.random.default_rng(0)

    D = np.stack([gen_traj(rng.uniform(-15, 15, 3), N_STEPS)
                  for _ in range(N_TRAJ)])
    lo, hi = float(D.min()) - 1.0, float(D.max()) + 1.0
    Dt = torch.tensor(D, dtype=torch.float32, device=DEV)      # (N, 401, 3)
    ics = [D[i, 0] for i in range(a.n_ic)]
    # 正则臂的采样点
    samp = Dt[:, :200, :].reshape(-1, 3)
    samp = samp[torch.randperm(samp.shape[0], device=DEV)[:64]]
    print(f"数据 {D.shape}  λ_true = {LAM_TRUE:+.5f}/步  量化范围 [{lo:.1f},{hi:.1f}]")

    # 多步训练的 (i,t) 索引：t ≤ N_STEPS − K
    ii, tt = torch.meshgrid(torch.arange(N_TRAJ), torch.arange(N_STEPS - a.K),
                            indexing="ij")
    ii, tt = ii.reshape(-1).to(DEV), tt.reshape(-1).to(DEV)

    bits_list = [2, 3, 4, 6, 8, 12, 16, 32]
    OUT = {"lam_true": LAM_TRUE, "config": vars(a), "arms": []}
    for arm in ("single", "multistep", "reg"):
        torch.manual_seed(0)
        m = Net().to(DEV)
        opt = torch.optim.AdamW(m.parameters(), lr=2e-3, weight_decay=1e-5)
        sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=a.epochs)
        t0 = time.time()
        n_idx = ii.shape[0]
        for ep in range(a.epochs):
            perm = torch.randperm(n_idx, device=DEV)
            for i0 in range(0, n_idx, 4096):
                sel = perm[i0:i0 + 4096]
                bi, bt = ii[sel], tt[sel]
                opt.zero_grad(set_to_none=True)
                z0 = Dt[bi, bt]                                   # (B,3)
                loss = F.mse_loss(m(z0), Dt[bi, bt + 1])
                if arm == "multistep":
                    zk = z0
                    for k in range(2, a.K + 1):
                        zk = m(zk)
                        loss = loss + F.mse_loss(zk, Dt[bi, bt + k])
                elif arm == "reg":
                    lam_hat = lam1_power(m, samp)
                    loss = loss + a.mu * F.relu(LAM_TRUE - lam_hat)
                loss.backward()
                opt.step()
        sch.step()
        tr_s = time.time() - t0
        with torch.no_grad():
            val_mse = float(((m(Dt[:, :-1, :].reshape(-1, 3)) -
                              Dt[:, 1:, :].reshape(-1, 3)) ** 2).mean())
        lam1, spec = qr_lam1(m)
        dev_lam = (lam1 - LAM_TRUE) / LAM_TRUE
        rows = tcrash_curve(m, ics, bits_list, lo, hi)
        f1 = fit_line(rows, "med_d1")
        row = dict(arm=arm, lam1=lam1, lam_dev=dev_lam, val_mse=val_mse,
                   train_s=round(tr_s, 1), spectrum=spec, rows=rows, fit_d1=f1)
        if f1 and f1["r2"] > 0.9:
            pred_slope = math.log(2) / lam1 if lam1 > 1e-4 else None
            row["slope_pred"] = pred_slope
            if pred_slope:
                row["slope_err"] = abs(f1["slope"] - pred_slope) / abs(pred_slope)
        OUT["arms"].append(row)
        print(f"\n  [{arm}]  {tr_s:.0f}s")
        print(f"    QR λ₁ = {lam1:+.5f}/步   真值 {LAM_TRUE:+.5f}   "
              f"偏差 {dev_lam*100:+.0f}%")
        print(f"    单步 val MSE = {val_mse:.4f}")
        print(f"    T_crash(δ*=1)：b=4 {rows[2]['med_d1']}  b=8 {rows[4]['med_d1']}  "
              f"b=16 {rows[6]['med_d1']}")
        if f1:
            sp = row.get("slope_pred")
            print(f"    拟合：斜率 {f1['slope']:.3f} 步/位  R² {f1['r2']:.4f}"
                  + (f"   预测 {sp:.3f}（差 {row['slope_err']*100:.0f}%）"
                     if sp else "   （λ₁≈0，斜率预测无定义）"))

    print("\n" + "=" * 78)
    print("  三臂对照汇总：谁学到了正确的 λ₁")
    print("=" * 78)
    print(f"  {'臂':<10} {'λ₁':>9} {'偏差':>8} {'valMSE':>8} "
          f"{'T(b)斜率':>9} {'预测斜率':>9}")
    for r in OUT["arms"]:
        sl = f"{r['fit_d1']['slope']:.2f}" if r.get("fit_d1") else "—"
        sp = f"{r['slope_pred']:.2f}" if r.get("slope_pred") else "—"
        print(f"  {r['arm']:<10} {r['lam1']:>+9.5f} {r['lam_dev']*100:>7.0f}% "
              f"{r['val_mse']:>8.4f} {sl:>9} {sp:>9}")
    print(f"  真值 λ₁ = {LAM_TRUE:+.5f}（洛伦兹文献折算，QR 对照 +0.0547）")
    best = min(OUT["arms"], key=lambda r: abs(r["lam_dev"]))
    print(f"\n  最接近真值：{best['arm']}（偏差 {best['lam_dev']*100:+.0f}%）"
          f" —— T4 对数律应在此臂上做最终判定")

    with open(os.path.join(ROOT, "logs", "t4b_arms.json"), "w", encoding="utf-8") as f:
        json.dump(OUT, f, ensure_ascii=False, indent=2)
    print("\n-> logs/t4b_arms.json")


if __name__ == "__main__":
    sys.exit(main())
