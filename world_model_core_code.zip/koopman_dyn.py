"""
T3c · Koopman 谱块动力学（单步形式）：λ₁ 从「测量量」变成「设计参数」。

两个实现要点（均可被自检检出）：
  ① 「λ₁ = log ρ_max」只对**单步**映射 z_{t+1} = A_K z_t 成立。
    若用 ctx=2 增广 (z_{t-1},z_t)↦(z_t,ẑ)，其本征值是 λ²−w_b λ−w_a 的根，
    QR 实测 λ₁ 与 log ρ_max 差 0.34，即形式误用。
  ② 像素判据的 VAE 必须与编码潜向量的 VAE 为同一份（混用二值/灰度 VAE 会使余弦下限为 0.5）。

结构：A_K = blockdiag(2×2 旋转-缩放块) × 32 块（64 维）
  ρ_i ≤ ρ_max 由投影保证；A_K 正规 → ‖A_K‖₂ = max ρ_i → λ₁ = log ρ_max 解析
对照臂：1-step 稠密线性最小二乘（隔离「块对角 + 谱约束」的代价）。
注意：Koopman 臂只用 z_t（单步），与 ctx=2 的 MLP 基线（0.92156）**不是同信息量**，
     公平参照是 1-step 稠密线性。

产物 logs/t3c_koopman.json
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from vae import LATENT, CKPT, LOGS  # noqa: E402
from guards import G  # noqa: E402

DEV = "cuda" if torch.cuda.is_available() else "cpu"
H = W = 64
OUT = {"arms": []}


def load_gray_vae():
    p = os.path.join(CKPT, "vae_gray_s3.pt")
    sd = torch.load(p, map_location=DEV, weights_only=True)
    from vae import VAE  # noqa: E402
    v = VAE().to(DEV)
    v.load_state_dict(sd["state"])
    return v


def block_proj(M, rho_max):
    """把 2×2 矩阵投影到「旋转-缩放」流形，且 ρ ≤ ρ_max。返回 ρ, θ。"""
    m = M.detach().cpu().numpy()
    theta = math.atan2(m[1, 0] - m[0, 1], m[0, 0] + m[1, 1])
    rho = ((m[0, 0] + m[1, 1]) * math.cos(theta) +
           (m[1, 0] - m[0, 1]) * math.sin(theta)) / 2.0
    rho = max(min(rho, rho_max), 0.0)
    return rho, theta


def rollout_crash(A, z, img, mean, std, vae, steps=18, factor=5.0):
    """单步线性映射的自回归 rollout。A: (64,64) numpy（作用在归一化 z 上）。"""
    gt = torch.as_tensor(z).float()
    m_np = mean.cpu().numpy().astype(np.float64)
    s_np = std.cpu().numpy().astype(np.float64)
    Anp = np.asarray(A, dtype=np.float64)
    zn = (gt[0].numpy().astype(np.float64) - m_np) / s_np
    preds = []
    for _ in range(steps):
        zn = Anp @ zn
        preds.append(zn * s_np + m_np)
    P = np.stack(preds)
    P = torch.from_numpy(P.astype(np.float32))
    cos = F.cosine_similarity(P, gt[2:2 + steps], dim=-1)
    t_lat = next((i + 1 for i in range(steps) if cos[i] < 0.9), None)
    gti = torch.from_numpy(np.ascontiguousarray(img[2:2 + steps])).float() / 255.0
    with torch.no_grad():
        px = torch.sigmoid(vae.decode(P.to(DEV))).view(steps, H, W).cpu()
    bce = F.binary_cross_entropy(px.clamp(1e-6, 1 - 1e-6), gti,
                                 reduction="none").flatten(1).mean(-1)
    with torch.no_grad():
        base = torch.sigmoid(vae.decode(gt[2:2 + steps].to(DEV))).view(steps, H, W).cpu()
    floor = float(F.binary_cross_entropy(base.clamp(1e-6, 1 - 1e-6), gti,
                                         reduction="none").flatten(1).mean())
    t_pix = next((i + 1 for i in range(steps) if bce[i] > factor * floor), None)
    return dict(cos=list(map(float, cos)), t_latent=t_lat, t_pixel=t_pix,
                floor=floor, bce_max=float(bce.max()),
                pix_margin_last=float(bce[-1] - floor))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rho", default="0.5,0.7,0.9,0.99")
    ap.add_argument("--epochs", type=int, default=300)
    a = ap.parse_args()
    torch.manual_seed(0)

    ztr = torch.load(os.path.join(CKPT, "latents_gray_s3__n_seq12000_seed0.pt"),
                     map_location="cpu", weights_only=True)["z"]
    zva = torch.load(os.path.join(CKPT, "latents_gray_s3__n_seq128_seed999.pt"),
                     map_location="cpu", weights_only=True)["z"]
    mean = ztr.mean(dim=(0, 1)).to(DEV)
    std = ztr.std(dim=(0, 1)).clamp_min(1e-6).to(DEV)
    vae = load_gray_vae()
    print(f"灰度 VAE（gray_s3）已载入；数据 12000 条 × 19 步 = {12000*19} 对")

    zn_tr = ((ztr - mean.cpu()) / std.cpu()).to(DEV)      # (N,20,64)
    zn_va = ((zva - mean.cpu()) / std.cpu()).to(DEV)
    X = zn_tr[:, :-1].reshape(-1, LATENT)
    Y = zn_tr[:, 1:].reshape(-1, LATENT)
    Xv = zn_va[:, :-1].reshape(-1, LATENT)
    Yv = zn_va[:, 1:].reshape(-1, LATENT)
    print(f"  单步对：train {X.shape[0]}  val {Xv.shape[0]}")

    from variant2 import VariantMNIST  # noqa: E402
    val_ds = VariantMNIST(128, 999, False, speeds=(1, 2, 3), gamma=0.0)

    arms = [("linear_free", None)] + [(f"rho{r}", float(r)) for r in a.rho.split(",")]
    OUT["arms"] = []
    for tag, rmax in arms:
        t0 = time.time()
        if rmax is None:
            # 稠密无约束线性：最小二乘闭式解（在归一化空间）
            Wls = torch.linalg.lstsq(X.double(), Y.double()).solution.float().cpu()
            pred_fn = lambda z: z @ Wls.to(DEV)                      # noqa: E731
            rho_i = torch.full((LATENT // 2,), float("nan"))
            n_par, lam1 = LATENT * LATENT, None
            M_list = None
        else:
            # 每坐标对的 2×2 最小二乘 → 投影到旋转-缩放流形（ρ ≤ ρ_max）→ SGD 精修
            Xp = X.view(-1, LATENT // 2, 2).double()                 # (N,32,2)
            Yp = Y.view(-1, LATENT // 2, 2).double()
            Gm = torch.einsum("ncd,nce->cde", Xp, Xp)                 # (32,2,2)
            c = torch.einsum("ncd,nce->cde", Xp, Yp)                 # (32,2,2) 互协方差
            Gm = Gm + 1e-6 * torch.eye(2, device=DEV).double()
            M0 = torch.linalg.solve(Gm, c)                            # (32,2,2)
            M = nn.Parameter(M0.float())
            opt = torch.optim.AdamW([M], lr=1e-3)
            rhos = []
            for ep in range(a.epochs):
                opt.zero_grad(set_to_none=True)
                Mp = M.view(LATENT // 2, 2, 2)
                out = torch.einsum("cad,ncd->nca", Mp, Xp.float()).reshape(X.shape)
                F.mse_loss(out, Y).backward()
                opt.step()
                with torch.no_grad():                                # 投影
                    for i in range(LATENT // 2):
                        r, th = block_proj(M[i], rmax)
                        M[i] = torch.tensor(
                            [[r * math.cos(th), -r * math.sin(th)],
                             [r * math.sin(th), r * math.cos(th)]],
                            device=DEV)
                        rhos.append(r)
            Mp = M.detach().view(LATENT // 2, 2, 2)
            A = torch.zeros(LATENT, LATENT, device=DEV)
            for i in range(LATENT // 2):
                A[2 * i:2 * i + 2, 2 * i:2 * i + 2] = Mp[i]
            rho_i = torch.tensor([block_proj(Mp[i], 1.0)[0]
                                  for i in range(LATENT // 2)])
            pred_fn = lambda z: (A @ z.T).T                          # noqa: E731
            n_par = 64
            lam1 = math.log(rmax) if rho_i.max() >= rmax - 1e-9 else float(np.log(rho_i.max()))
        with torch.no_grad():
            pr = pred_fn(Xv)
        cos = float(F.cosine_similarity(pr, Yv, dim=-1).mean())
        mse = float(((pr - Yv) ** 2).mean())
        row = dict(tag=tag, rho_max=rmax, val_cos=cos, val_mse=mse,
                   epochs=a.epochs, train_s=round(time.time() - t0, 1), n_par=n_par)
        if rmax is not None:
            Anp = A.detach().cpu().numpy().astype(np.float64)
            dev_n = float(np.abs(Anp.T @ Anp - Anp @ Anp.T).max())
            nrm2 = float(np.linalg.norm(Anp, 2))
            from lyap import qr_spectrum_map  # noqa: E402
            lam_qr = qr_spectrum_map(lambda s: Anp @ s, lambda s: Anp,
                                     x0=np.full(LATENT, 1e-3), n_steps=4000,
                                     discard=1000)
            row.update(rho_max_i=float(rho_i.max()), rho_mean_i=float(rho_i.mean()),
                       lam1_log_rmax=lam1, lam1_qr=float(lam_qr[0]),
                       qr_vs_log=abs(float(lam_qr[0]) - lam1),
                       normality_dev=dev_n, spec_norm=nrm2)
            assert dev_n < 1e-8, f"A_K 非正规（{dev_n:.1e}）"
            G.spaces("normalized_latent", "normalized_latent",
                     metric_desc=f"λ₁ 应= log ρ_max = {lam1:+.4f}",
                     loss_desc="MSE（谱约束由构造与投影保证）")
        Anp_np = A.detach().cpu().numpy().astype(np.float64) if rmax is not None else None
        row["rollout"] = rollout_crash(
            (Wls if rmax is None else Anp_np), zva[0].numpy(),
            val_ds[0].numpy(), mean, std, vae)
        rl = row["rollout"]
        print(f"\n  [{tag}] ρ_max={rmax}  参数 {n_par}  {row['train_s']}s")
        print(f"    单步：val cos {cos:.5f}  潜 MSE {mse:.4f}")
        if rmax is not None:
            print(f"    ρ_i：max {row['rho_max_i']:.4f}  mean {row['rho_mean_i']:.4f}"
                  f"   正规性偏差 {dev_n:.1e}  ‖A‖₂={nrm2:.6f}")
            print(f"    λ₁：解析 {lam1:+.4f} / QR {row['lam1_qr']:+.4f}"
                  f"（差 {row['qr_vs_log']:.1e}）")
        print(f"    rollout：潜 T_crash {rl['t_latent']}  像素 T_crash {rl['t_pixel']}"
              f"（地板 {rl['floor']:.4f}）  最大像素余量 {rl['pix_margin_last']:+.4f}")
        OUT["arms"].append(row)

    print("\n" + "=" * 78)
    print("  汇总：ρ_max 扫描（单步 Koopman，λ₁ = log ρ_max 解析；γ=0 守恒数据）")
    print("=" * 78)
    print(f"  {'臂':<12} {'单步cos':>9} {'潜MSE':>8} {'λ₁':>9} {'潜T_crash':>9} {'像素T_crash':>11}")
    for r in OUT["arms"]:
        l = f"{r['lam1_log_rmax']:+.3f}" if r["rho_max"] is not None else "—"
        print(f"  {r['tag']:<12} {r['val_cos']:>9.5f} {r['val_mse']:>8.4f} {l:>9} "
              f"{str(r['rollout']['t_latent']):>9} {str(r['rollout']['t_pixel']):>11}")
    print("  参照：ctx=2 MLP 基线单步 cos = 0.92156（用两帧，信息量更多，不可直接比）")

    with open(os.path.join(LOGS, "t3c_koopman.json"), "w", encoding="utf-8") as f:
        json.dump(OUT, f, ensure_ascii=False, indent=2)
    print("\n-> logs/t3c_koopman.json")


if __name__ == "__main__":
    sys.exit(main())
