"""
T18 · 接触/碰撞环境（本项目唯一真正空白的数据缺口）

动机：Moving MNIST 的「碰壁」是**等距反射** —— 纯线性、连续，连接触的难点都没有。
      真实接触的特征是**不连续**：速度在碰撞瞬间跳变，局部放大率可以任意大。
      可用于检验「λ₁ 较大时 T_crash 对 b 不敏感」这一预测。

设计原则（单变量对照）：
      与 t15_action.make_seq_act **唯一差别** = 数字之间加入弹性碰撞。
      渲染方式、动作语义、帧数、数字个数、速度范围、边界处理全部保持原样。

物理设定
  · 数字视为半径 RADIUS=14 的圆盘（与 28×28 图块外接圆一致）
  · 等质量弹性碰撞（恢复系数 e 可调）：沿法向交换动量 + 位置分离
  · **内部状态是 float64**（连续相空间 → 可以真正混沌），渲染时才取整
    —— 这与「真值连续、观测量离散」的实际情形一致
  · 动作 a 与 T15 完全同义：给所有数字加一个共同速度增量

产物：本模块只提供模型与生成器；λ₁ 测量见 t18_truth.py
"""
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

H = W = 64
DIGIT = 28
RADIUS = DIGIT / 2.0          # 14.0
LIM = W - DIGIT               # 36：左上角坐标范围 [0, 36]
V_MAX, A_MAX = 3, 1
T_FRAMES, N_DIGIT = 20, 2
SPEEDS = (1, 2, 3)


def resolve_pair(st, i, j, e=1.0, vn_eps=1e-6):
    """等质量弹性碰撞：沿法向交换动量 + 把两盘推到刚好相切。返回是否发生**碰撞**。

    两个已知陷阱：
      ① **相切粘滞**：两球被推到刚好相切后，下一帧 d 在 28 ± 浮点误差之间摆动，
         若把 vn≈-0 也当成碰撞，就会每帧"碰撞"一次而冲量几乎为 0。
         实测：n=3 时碰撞率虚高到 1.011/步、dmin 长期锁在 28.00。
         → 用 vn_eps 下限过滤掉这种近零接近速度。
      ② **无条件去重叠是非物理的**：在 vn ≥ 0（正在分离）时硬推位置，等于施加
         一个**瞬时不连续的位置跳变**，对微小扰动极敏感 → 制造假的 λ₁。
         实测：随机动作下碰撞率 0.000，却仍测出 λ₁ = +0.307。
         → 分离中且已重叠时不做任何修改，让它们自然分开。
    """
    dx = st[i, 0] - st[j, 0]
    dy = st[i, 1] - st[j, 1]
    d2 = dx * dx + dy * dy
    dmin = 2.0 * RADIUS
    if d2 >= dmin * dmin:
        return False
    d = math.sqrt(max(d2, 1e-24))
    nx, ny = dx / d, dy / d
    vn = (st[i, 2] - st[j, 2]) * nx + (st[i, 3] - st[j, 3]) * ny
    if vn >= -vn_eps:                  # 分离中 / 滑动接触 / 数值噪声 → 不动作
        return False
    imp = (1.0 + e) / 2.0 * vn
    st[i, 2] -= imp * nx
    st[i, 3] -= imp * ny
    st[j, 2] += imp * nx
    st[j, 3] += imp * ny
    ov = (dmin - d) / 2.0 + 1e-12      # 去重叠只与真实碰撞一起发生
    st[i, 0] += ov * nx
    st[i, 1] += ov * ny
    st[j, 0] -= ov * nx
    st[j, 1] -= ov * ny
    return True


def step_state(st, a, e=1.0, v_max=V_MAX, boundary="reflect"):
    """推进一帧。st: (n,4) float64 [x,y,vx,vy]（左上角坐标）；a: (2,) 全局动作。

    返回 (新状态, 本帧碰撞次数)。顺序与 t15_action.make_seq_act 一致：
    先应用动作 → 再移动 → 边界处理 →（本模块新增）两两碰撞。

    boundary:
      "reflect"  —— 反射 + 夹回（与原版一致，用于**生成数据**）
      "periodic" —— 环绕（用于**测 λ₁**：反射边界本身是一个不连续源，
                    会让无碰撞系统也测出假的 λ₁ ≈ +0.005；环绕无此奇异）
    """
    st = np.array(st, dtype=np.float64, copy=True)
    st[:, 2] = np.clip(st[:, 2] + a[0], -v_max, v_max)
    st[:, 3] = np.clip(st[:, 3] + a[1], -v_max, v_max)
    st[:, 0] += st[:, 2]
    st[:, 1] += st[:, 3]
    if boundary == "periodic":
        st[:, 0] = np.mod(st[:, 0], float(LIM))
        st[:, 1] = np.mod(st[:, 1], float(LIM))
    else:
        for k in range(st.shape[0]):   # 边界：反射 + 夹回（与原版一致）
            if st[k, 0] < 0.0 or st[k, 0] > LIM:
                st[k, 2] = -st[k, 2]
                st[k, 0] = min(max(st[k, 0], 0.0), float(LIM))
            if st[k, 1] < 0.0 or st[k, 1] > LIM:
                st[k, 3] = -st[k, 3]
                st[k, 1] = min(max(st[k, 1], 0.0), float(LIM))
    ncol = 0
    for i in range(st.shape[0]):
        for j in range(i + 1, st.shape[0]):
            ncol += int(resolve_pair(st, i, j, e))
    return st, ncol


def rand_state(rng, n_digit=N_DIGIT, min_sep=None):
    """随机初值（左上角坐标 + 整数速度）。

    带**拒绝采样**保证数字初始互不重叠 —— 分离中不再做去重叠（见 resolve_pair），
    所以初始重叠会永久保留，必须在这里排除。
    """
    sep = 2.0 * RADIUS if min_sep is None else min_sep
    st = np.zeros((n_digit, 4), dtype=np.float64)
    for k in range(n_digit):
        x = y = 0.0
        for _ in range(500):
            x = float(rng.integers(0, LIM + 1))
            y = float(rng.integers(0, LIM + 1))
            if all((x - st[m, 0]) ** 2 + (y - st[m, 1]) ** 2 >= sep * sep
                   for m in range(k)):
                break
        st[k, 0], st[k, 1] = x, y
        st[k, 2] = float(int(rng.choice(SPEEDS)) * int(rng.choice((-1, 1))))
        st[k, 3] = float(int(rng.choice(SPEEDS)) * int(rng.choice((-1, 1))))
    return st


def make_seq_collide(digits, rng, n_frames=T_FRAMES, n_digit=N_DIGIT,
                     v_max=V_MAX, a_max=A_MAX, e=1.0, boundary="reflect"):
    """生成器（无动作版本用于 T18：动作版本已被诊断否掉 —— 共享动作 + clip
    会让所有数字速度趋同、碰撞消失，见 t18_diag.py）。

    返回 (frames (T,64,64) uint8, actions (T,2) int8, n_col)。

    boundary="reflect"  → 与 Moving MNIST 渲染惯例一致（λ₁_true ≈ +0.0445/帧）
    boundary="periodic" → 数字环绕出画（λ₁_true ≈ +0.374/帧，8.25×）
    """
    frames = np.zeros((n_frames, H, W), dtype=np.uint8)
    actions = np.zeros((n_frames, 2), dtype=np.int8)
    order = rng.permutation(len(digits))[:n_digit]
    digs = [digits[k] for k in order]
    st = rand_state(rng, n_digit)                 # 互不重叠的初值
    total_col = 0
    for t in range(n_frames):
        for i in range(n_digit):                    # 先渲染当前帧
            xi = int(min(max(round(st[i, 0]), 0), LIM))
            yi = int(min(max(round(st[i, 1]), 0), LIM))
            np.maximum(frames[t, yi:yi + DIGIT, xi:xi + DIGIT], digs[i],
                       out=frames[t, yi:yi + DIGIT, xi:xi + DIGIT])
        a = rng.integers(-a_max, a_max + 1, size=2)
        actions[t] = a
        st, ncol = step_state(st, a.astype(np.float64), e=e, v_max=v_max,
                              boundary=boundary)
        total_col += ncol
    return frames, actions, total_col


def build_dataset(n, seed, train, e=1.0, n_digit=N_DIGIT, boundary="reflect"):
    """返回 (frames, actions, 平均每序列碰撞次数)"""
    from variant2 import GRAY
    digits = GRAY[train]
    F_, A_, cols = [], [], []
    for i in range(n):
        rng = np.random.default_rng((seed * 1_000_003 + i) % (2 ** 32))
        f, a, c = make_seq_collide(digits, rng, n_digit=n_digit, e=e,
                                   boundary=boundary)
        F_.append(f)
        A_.append(a)
        cols.append(c)
    return np.stack(F_), np.stack(A_), float(np.mean(cols))


if __name__ == "__main__":
    # 自检：碰撞是否真的发生、渲染是否与无碰撞版同分布
    import torch  # noqa: F401  （仅用于确认环境可用）
    from variant2 import GRAY
    print("=" * 84)
    print("  T18 · 碰撞环境自检")
    print("=" * 84)
    for e in (1.0, 0.5):
        for nd in (1, 2, 3):
            cols, inkn = [], []
            for i in range(40):
                rng = np.random.default_rng(1000 + i)
                f, a, c = make_seq_collide(GRAY[True], rng, n_digit=nd, e=e)
                cols.append(c)
                inkn.append(float((f > 0).mean()))
            print(f"  e={e}  n_digit={nd}  每序列碰撞次数 均值 {np.mean(cols):.2f} "
                  f"(范围 {min(cols)}–{max(cols)})   墨迹占比 {np.mean(inkn)*100:.2f}%")
    print()
    print("  对照（T15 无碰撞版，n_digit=2）的墨迹占比应与此接近 → 视觉分布未被改变")
