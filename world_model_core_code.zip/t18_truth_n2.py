"""
T18 勘误 · 补测**与实际训练数据同配置**的真值 λ₁

发现的问题（2026-09-19 晚，做 multistep 对照时核对配置才暴露）：
  · `t18_collide.py` 用的是 `collide.N_DIGIT = 2`（JSON 的 config.n_digit = 2 可查）
  · 但它在屏幕输出与**已交付报告**里都写「3 个数字」（硬编码文案）
  · 而报告引用的真值 λ₁ = **+0.3502** 来自 `t18_truth.py` 的 ④「n=3 环绕」
  ⇒ **学习的模型（2 盘）与作为基准的真值（3 盘）不是同一个系统**，
    「保留 31%」这个比例建立在不匹配的比较上。

修法：补测 n=2 的两套边界（periodic 用于 periodic 臂；reflect 与 reflect 数据同边界），
     并对拍已存的 ⑥ n=2 环绕（不同 IC/步数下的可复现性）。

一致性旁证：数据的每步碰撞率（reflect 3.34/20 = 0.167、periodic 5.20/20 = 0.260）
应与同配置真值测量的碰撞率对得上 —— 对不上说明 n_digit 还猜错了。

用法：python t18_truth_n2.py [--ic 24] [--steps 20000]
产物：logs/t18_truth_n2.json
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from t18_truth import run_cfg          # noqa: E402

OUT = os.path.join(ROOT, "logs", "t18_truth_n2.json")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ic", type=int, default=24)
    ap.add_argument("--steps", type=int, default=20000)
    a = ap.parse_args()
    t0 = time.time()
    print("=" * 104)
    print("  T18 勘误 · 与实际数据同配置（n_digit=2）的真值 λ₁")
    print("=" * 104)
    print(f"  {a.ic} 初值 × {a.steps} 步；Benettin。"
          f"对照（旧，错配置）：n=3 环绕 +0.35020 / n=3 反射 +0.05149\n")

    cfgs = [
        ("⑥ n=2 环绕 a≡0（periodic 臂的正确基准；对拍已存 +0.24431）", 2, "periodic"),
        ("⑥b n=2 反射 a≡0（reflect 臂的正确基准，**此前缺失**）", 2, "reflect"),
        ("⑥c n=1 反射（边界伪影对照，复测）", 1, "reflect"),
        ("⑥d n=1 环绕（无碰撞零对照，复测）", 1, "periodic"),
    ]
    res = []
    print(f"  {'配置':<52}{'λ₁ 均值±SE':>18}{'中位':>10}{'范围':>22}{'碰撞/步':>9}")
    for name, nd, bd in cfgs:
        r = run_cfg(name, nd, n_ic=a.ic, n_steps=a.steps, boundary=bd)
        res.append(r)
        rng_s = "[{:+.4f},{:+.4f}]".format(r["lam_min"], r["lam_max"])
        print(f"  {name:<52}{r['lam_mean']:>+11.5f}±{r['lam_se']:<6.5f}"
              f"{r['lam_med']:>+10.5f}{rng_s:>22}{r['collisions_per_step']:>9.3f}")

    d = {r["name"]: r for r in res}
    n2p = d["⑥ n=2 环绕 a≡0（periodic 臂的正确基准；对拍已存 +0.24431）"]
    n2r = d["⑥b n=2 反射 a≡0（reflect 臂的正确基准，**此前缺失**）"]

    # 与已存值对拍
    old = json.load(open(os.path.join(ROOT, "logs", "t18_truth.json"), encoding="utf-8"))
    old6 = next(r for r in old["rows"] if r["n_digit"] == 2 and r["boundary"] == "periodic")
    gap = abs(n2p["lam_mean"] - old6["lam_mean"])
    se = math.hypot(n2p["lam_se"], old6["lam_se"])
    ok = gap < 3 * se
    print("\n" + "-" * 104)
    print(f"  对拍 ⑥：本次 {n2p['lam_mean']:+.5f}±{n2p['lam_se']:.5f}"
          f"（{a.ic}×{a.steps}） vs 已存 {old6['lam_mean']:+.5f}±{old6['lam_se']:.5f}"
          f"（{old6['n_ic']}×{old6['n_steps']}）差 {gap:.5f}（3SE={3*se:.5f}）"
          f"  {'✓ 可复现' if ok else '✗ 不可复现'}")

    # 与数据碰撞率对拍
    D = json.load(open(os.path.join(ROOT, "logs", "t18_collide.json"), encoding="utf-8"))
    print("\n  碰撞率一致性（数据 vs 真值测量）：")
    for kind, r in (("periodic", n2p), ("reflect", n2r)):
        rate_data = D[kind]["collisions_per_seq"] / 20.0
        print(f"    {kind:<9} 数据 {rate_data:.3f}/步   真值测量 {r['collisions_per_step']:.3f}/步"
              f"   比值 {rate_data/max(r['collisions_per_step'],1e-9):.2f}"
              + ("  ✓ 同配置" if 0.5 < rate_data / max(r['collisions_per_step'], 1e-9) < 2.0
                 else "  ✗ 相差过大 —— n_digit 可能还不一致"))

    print("\n" + "-" * 104)
    print("  结论（模型 λ₁ 见 t18_lambda_data.json；此处只给正确的真值基准）")
    print("-" * 104)
    for kind, r, old_v in (("periodic", n2p, 0.35020), ("reflect", n2r, 0.05149)):
        print(f"  {kind:<9} 正确真值 {r['lam_mean']:+.5f}±{r['lam_se']:.5f}"
              f"（报告此前引用的 n=3 值：{old_v:+.5f}）")

    Q = dict(config=dict(n_ic=a.ic, n_steps=a.steps), rows=res,
             cross_check=dict(n2_periodic_vs_stored_gap=gap, ok=bool(ok),
                              stored=dict(mean=old6["lam_mean"], se=old6["lam_se"],
                                          n_ic=old6["n_ic"], n_steps=old6["n_steps"])),
             elapsed_s=round(time.time() - t0, 1))
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(Q, f, ensure_ascii=False, indent=2)
    print(f"\n  → {OUT}（{Q['elapsed_s']}s）")


if __name__ == "__main__":
    main()
