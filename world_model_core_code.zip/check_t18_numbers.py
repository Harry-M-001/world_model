"""核验 T18_碰撞环境.md 的数字与 logs/t18_*.json 一致（含 ep600 对照与 λ₁ 重测）。"""
import json
import math
import os
import _paths  # noqa: E402
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)


def L(n):
    p = os.path.join(ROOT, "logs", n)
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else None


def main():
    D = L("t18_collide.json")
    D600 = L("t18_collide_ep600.json")
    T = L("t18_truth.json")
    LD = L("t18_lambda_data.json")
    doc = open(_paths.phase1("T18_碰撞环境.md"), encoding="utf-8").read()
    tr = {r["name"]: r for r in T["rows"]}
    ref, per = D["reflect"], D["periodic"]

    def med(P, b):
        return next(r["med"] for r in P["rows"] if r["bits"] == b)

    def dinf(P, b):
        return next(r["d_end_med"] for r in P["rows"] if r["bits"] == b)

    checks = [
        # ---- 真值
        ("真值 n=1 环绕 = 0（精确）",
         abs(tr["① n=1 环绕（无碰撞对照，解析 0）"]["lam_mean"]) < 1e-12),
        ("真值 n=3 环绕（均值）= +0.35020",
         abs(tr["④ n=3 环绕 a≡0（★ 主配置）"]["lam_mean"] - 0.35020) < 1e-4),
        ("真值 n=3 反射（均值）= +0.05149",
         abs(tr["③ n=3 反射 a≡0（与生成数据同边界）"]["lam_mean"] - 0.05149) < 1e-4),
        ("n=3 反射是混合分布（范围含 0）",
         tr["③ n=3 反射 a≡0（与生成数据同边界）"]["lam_min"] < 1e-9),
        ("边界伪影 +0.00129",
         abs(tr["② n=1 反射（对照：边界伪影）"]["lam_mean"] - 0.00129) < 1e-4),
        ("非弹性 e=0.5 → 0", abs(tr["⑦ n=3 环绕 e=0.5 a≡0（非弹性）"]["lam_mean"]) < 1e-9),
        ("δ₀ 无关性通过", T["checks"]["delta_invariance"] is True),
        ("无碰撞对照通过", T["checks"]["ctrl_zero"] is True),
        # ---- reflect（ep2000）
        ("reflect cos = 0.90453", abs(ref["cos_single"] - 0.90453) < 1e-5),
        ("reflect b* = 12", ref["b_star"] == 12),
        ("reflect δ_∞ @b=32 ≈ 0（<1e-4）", dinf(ref, 32) < 1e-4),
        ("reflect δ_∞ @b=12 = 0.1180", abs(dinf(ref, 12) - 0.1180) < 1e-3),
        ("reflect T_crash b=6/8 = 5/55.5",
         abs(med(ref, 6) - 5.0) < 0.01 and abs(med(ref, 8) - 55.5) < 0.01),
        # ---- periodic（ep2000）
        ("periodic cos = 0.70734", abs(per["cos_single"] - 0.70734) < 1e-5),
        ("periodic b* = None", per["b_star"] is None),
        ("periodic δ_∞ @b=32 = 1.1178", abs(dinf(per, 32) - 1.1178) < 1e-3),
        ("periodic T_crash b=32 = 84", abs(med(per, 32) - 84.0) < 0.01),
        ("periodic 斜率（剔 floor）= 3.047",
         abs(per["fit_nofloor"][0] - 3.047) < 0.01),
        # ---- λ₁ 重测（数据轨迹法）
        ("λ₁ 数据法 gray_s3 = −0.02805", abs(LD["gray_s3"]["lam1_data"] + 0.02805) < 1e-4),
        ("λ₁ 数据法 reflect = −0.02386（已修订；旧值 +0.02676 是用错 ckpt 版本）",
         abs(LD["reflect"]["lam1_data"] + 0.02386) < 1e-4),
        ("λ₁ 数据法 periodic = +0.10823", abs(LD["periodic"]["lam1_data"] - 0.10823) < 1e-4),
        ("λ₁ 结果记录模型 mtime（防静默用错版本）",
         all("model_mtime" in LD[k] for k in ("reflect", "periodic"))),
        ("periodic/gray_s3 未受版本错用影响（逐位一致）",
         abs(LD["periodic"]["lam1_data"] - 0.10823) < 1e-4
         and abs(LD["gray_s3"]["lam1_data"] + 0.02805) < 1e-4),
        ("λ₁ 数据法输入未跑飞（|u|max < 8）",
         LD["reflect"]["u_max"] < 8 and LD["periodic"]["u_max"] < 8),
        ("periodic 保留比例 31%（新真值 0.3502）",
         abs(LD["periodic"]["lam1_data"] / 0.35020 - 0.309) < 0.01),
        # ---- ep600 对照
        ("ep600 reflect cos = 0.90115",
         abs(D600["reflect"]["cos_single"] - 0.90115) < 1e-5),
        ("ep600 periodic δ_∞@32 = 1.0860",
         abs(dinf(D600["periodic"], 32) - 1.0860) < 1e-3),
        ("ep600 periodic 斜率 = 5.868",
         abs(D600["periodic"]["fit_nofloor"][0] - 5.868) < 0.01),
        # ---- 结构
        ("floor 判据按维度 2.309·Δ",
         abs(math.sqrt(64) / math.sqrt(12) - 2.3094) < 1e-3 and "2.309" in doc),
        ("文档含三个陷阱标题", all(k in doc for k in
                             ("相切粘滞", "无条件去重叠", "QR 迭代跑出训练分布"))),
        ("文档保留了作废标注", "作废" in doc and "99.98%" in doc),
    ]
    bad = [n for n, ok in checks if not ok]
    print("=" * 92)
    print(f"  T18 数字核对 {len(checks)} 项：",
          "全部通过 ✅" if not bad else f"失败 {bad}")
    print("=" * 92)
    print(f"\n  λ₁ 三方对照：")
    for k, nm in (("gray_s3", "gray_s3（无碰撞）"), ("reflect", "碰撞 reflect"),
                  ("periodic", "碰撞 periodic")):
        v = LD[k]
        print(f"    {nm:<20} 真值 {v['lam_true']:+.5f}   数据轨迹法 {v['lam1_data']:+.5f}")
    print(f"\n  δ_∞(b) 三方对照（reflect vs periodic，同为 2000 epochs）：")
    print(f"    {'b':>3} {'reflect':>10} {'periodic':>10}  {'比值':>8}")
    for b in (6, 8, 12, 16, 32):
        a, c = dinf(ref, b), dinf(per, b)
        print(f"    {b:>3} {a:>10.4f} {c:>10.4f}  {c/max(a,1e-9):>8.1f}×")


if __name__ == "__main__":
    main()
