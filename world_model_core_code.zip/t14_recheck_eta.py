# -*- coding: utf-8 -*-
"""T14 · A1 解析判据的 η 口径复核（用已存原始数据重算，不重训）

背景：
  `t14_warn.py` 用  eta(b) = mean(hi−lo)/(2^b−1)/2 = Δ/2  作为「每步量化注入范数」。
  在 3 维系统（论文 §4.1 的 Lorenz/Hénon）里 √3·Δ/√12 = Δ/2，**该口径是对的**。
  但 T14 的基础模型是 64 维潜空间，且量化施加在 **2 帧拼接输入 (2L=128 维)** 上，
  故正确的「范数」量纲应为 √(2L)·Δ/√12，再乘上模型对输入的敏感性。

本脚本做三件事：
  ① 用 T14 已落盘的 rows（δ 轨迹、crash 时刻）实测每步注入范数 δ₁
  ② 用四个 η 口径重算 T̂_crash(b)，并按 t14_warn.evaluate 的同一口径重算 A1 命中率
  ③ 报告「无偏 η 倍率」作为诊断（注明它含拟合成分，不作为论文的零参数口径）
输出：logs/t14_eta_recheck.json
"""
import os
import io
import json
import math
import statistics as st

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
LOGS = os.path.join(ROOT, "logs")
HIT_W, LEAD = 5, 10
L = 64


def T_crash(lam, eta, ds=1.0):
    if eta <= 0:
        return None
    v = 1.0 + ds * (math.exp(lam) - 1.0) / eta
    if v <= 0:
        return None
    return max(1, round(math.log(v) / lam))


def evaluate(rows, pred):
    """与 t14_warn.evaluate 同一口径（pred 是 b → 预测时刻 的映射或逐行函数）。"""
    used = hits = fa = late = 0
    errs = []
    for r in rows:
        if r["crash"] is None:
            continue
        used += 1
        ts = pred(r) if callable(pred) else pred.get(r["b"])
        if ts is None:
            continue
        errs.append(ts - r["crash"])
        if abs(ts - r["crash"]) <= HIT_W:
            hits += 1
        elif ts < r["crash"] - LEAD:
            fa += 1
        elif ts > r["crash"]:
            late += 1
    return dict(hit=hits, used=used, hit_rate=hits / max(used, 1),
                false_alarm=fa, late=late,
                mean_err=float(st.mean(errs)) if errs else None)


def main():
    src = os.path.join(LOGS, "t14_warn_dense_h480_act.json")
    d = json.load(io.open(src, encoding="utf-8"))
    rows, cfg = d["rows"], d["config"]
    eta_code = {int(k): v for k, v in cfg["eta"].items()}
    lam, ds, BS = cfg["lam"], cfg["delta_star"], cfg["bs"]
    print(f"底座 {cfg['tag']}  λ={lam:.5f}  δ*={ds}  b={BS}  rows={len(rows)}")
    print(f"真实崩溃 {sum(1 for r in rows if r['crash'])}{'/' + str(len(rows))}")

    # ---- ① 实测每步注入范数（首步，此时 δ0=0 ⇒ δ1 就是纯注入） ----
    print("\n① 实测每步注入范数 δ₁（首步，δ₀=0）")
    print(f"  {'b':>3} {'η_code':>10} {'δ₁中位':>10} {'δ₁/η_code':>10} "
          f"{'√(2L)Δ/√12':>12} {'δ₁/该值':>9}")
    eta_meas, ratios = {}, {}
    for b in BS:
        xs = [r["delta"][0] for r in rows if r["b"] == b]
        m = st.median(xs)
        delta_perdim = eta_code[b] * 2.0               # Δ（每维平均）
        eta_norm = math.sqrt(2 * L) * delta_perdim / math.sqrt(12.0)
        eta_meas[b] = m
        ratios[b] = m / eta_code[b]
        print(f"  {b:>3} {eta_code[b]:>10.5f} {m:>10.4f} {ratios[b]:>10.2f} "
              f"{eta_norm:>12.4f} {m/eta_norm:>9.2f}")
    r_med = st.median(ratios.values())
    print(f"  → 中位比 δ₁/η_code = {r_med:.2f}×（= √(2L) 范数因子 {math.sqrt(2*L)/math.sqrt(12)*2:.2f}"
          f"× 模型敏感性 {r_med/(math.sqrt(2*L)/math.sqrt(12)*2):.2f}）")

    # ---- ② 四个 η 口径下的 A1 臂 ----
    print("\n② 四个 η 口径下的 A1（解析判据）臂")
    variants = {}
    variants["原口径 η=Δ/2"] = {b: T_crash(lam, eta_code[b], ds) for b in BS}
    variants["范数口径 √(2L)Δ/√12"] = {
        b: T_crash(lam, math.sqrt(2 * L) * eta_code[b] * 2 / math.sqrt(12.0), ds) for b in BS}
    variants["实测注入 η=δ₁中位"] = {b: T_crash(lam, eta_meas[b], ds) for b in BS}
    variants["实测注入×敏感性（同实测）"] = variants["实测注入 η=δ₁中位"]

    out = {}
    print(f"  {'口径':<22}{'T̂(b)':<34}{'命中率':>9}{'误报':>6}{'迟到':>6}{'平均误差':>10}")
    for name, pred in variants.items():
        e = evaluate(rows, pred)
        out[name] = dict(pred={str(k): v for k, v in pred.items()}, **e)
        print(f"  {name:<22}{str(pred):<34}{e['hit_rate']*100:>8.1f}%{e['false_alarm']:>6}"
              f"{e['late']:>6}{(e['mean_err'] if e['mean_err'] is not None else float('nan')):>10.2f}")

    # ---- ③ 无偏倍率（诊断用；含拟合成分，不入论文零参数口径） ----
    print("\n③ 诊断：把 η 整体乘 c，看 A1 平均偏差何时归零")
    best = None
    for i in range(1, 41):
        c = i * 0.5
        pred = {b: T_crash(lam, eta_code[b] * c, ds) for b in BS}
        e = evaluate(rows, pred)
        if e["mean_err"] is None:
            continue
        if best is None or abs(e["mean_err"]) < abs(best[1]["mean_err"]):
            best = (c, e)
    print(f"  最优 c = {best[0]:.1f}×（η_code），平均偏差 {best[1]['mean_err']:+.2f} 步，"
          f"命中率 {best[1]['hit_rate']*100:.1f}%")
    print(f"  即真实有效注入 ≈ {best[0]:.1f} × η_code —— 与实测首步注入比 {r_med:.1f}× 量级一致")

    out["_meta"] = dict(
        src=os.path.basename(src), lam=lam, delta_star=ds, L=L,
        eta_code={str(k): v for k, v in eta_code.items()},
        eta_meas_inj={str(k): v for k, v in eta_meas.items()},
        ratio_inj_over_eta_code={str(k): v for k, v in ratios.items()},
        ratio_median=r_med,
        norm_factor=math.sqrt(2 * L) / math.sqrt(12.0) * 2,
        best_unbiased_c=best[0], best_unbiased=evaluate(
            rows, {b: T_crash(lam, eta_code[b] * best[0], ds) for b in BS}),
        note="η 口径复核：3 维系统 Δ/2 正确；64 维潜空间 + 2 帧输入需 √(2L)·Δ/√12 × 敏感性")
    with io.open(os.path.join(LOGS, "t14_eta_recheck.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print("\n  → logs/t14_eta_recheck.json")


if __name__ == "__main__":
    main()
