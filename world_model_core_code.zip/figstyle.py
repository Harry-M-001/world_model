"""绘图统一风格：暗色主题 + 中文字体。

注意：matplotlib 默认字体 DejaVu Sans 不含中日韩字形，
中文标签会静默显示为方框（不报错、不影响保存）。
Windows 下指定 msyh/simhei 即可。
"""
import os

CJK_CANDIDATES = [
    "C:/Windows/Fonts/msyh.ttc",       # 微软雅黑
    "C:/Windows/Fonts/msyhbd.ttc",
    "C:/Windows/Fonts/simhei.ttf",     # 黑体
    "C:/Windows/Fonts/simsun.ttc",     # 宋体
]

# 主题：默认暗色（屏幕报告用）；设环境变量 FIGLIGHT=1 切到「印刷浅色」（白底黑字，论文插图用）
_PRINT = os.environ.get("FIGLIGHT", "") == "1"

if _PRINT:
    BG, FG, MUTED = "#ffffff", "#111111", "#5a6270"
    LINE = "#b8bec9"
    ACC, ACC2, WARN, DANGER = "#1f4fd8", "#0a8f7a", "#b26a00", "#c62828"
else:
    BG, FG, MUTED = "#0f1115", "#e8eaed", "#9aa3b2"
    LINE = "#2b303c"
    ACC, ACC2, WARN, DANGER = "#5b8cff", "#00c2a8", "#ffb648", "#ff6b6b"


def setup_matplotlib():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    names = []
    for p in CJK_CANDIDATES:
        if os.path.exists(p):
            try:
                font_manager.fontManager.addfont(p)
                names.append(font_manager.FontProperties(fname=p).get_name())
            except Exception:
                pass
    plt.rcParams["font.sans-serif"] = (names or []) + ["DejaVu Sans"]
    plt.rcParams["font.family"] = "sans-serif"
    plt.rcParams["axes.unicode_minus"] = False
    return plt


def dark_axes(ax):
    ax.set_facecolor(BG)
    ax.tick_params(colors=MUTED)
    for s in ax.spines.values():
        s.set_color(LINE)
    ax.grid(alpha=(.32 if _PRINT else .18))
    return ax


def legend(ax, **kw):
    return ax.legend(facecolor=("#ffffff" if _PRINT else "#171a21"),
                     edgecolor=LINE, labelcolor=FG, fontsize=9, **kw)


def pil_font(size=14, bold=False):
    from PIL import ImageFont
    cands = CJK_CANDIDATES if not bold else [CJK_CANDIDATES[1]] + CJK_CANDIDATES
    for p in cands:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()
