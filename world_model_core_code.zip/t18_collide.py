"""
T18 · 接触/碰撞环境：不连续接触对「位宽—崩溃」曲线的影响

前置（已完成，logs/t18_truth.json）：
  · 碰撞环境能测出真实的正 λ₁：n=3 环绕边界 λ₁ = +0.374/帧（**洛伦兹的 8.25×**）
  · 反射边界（与 Moving MNIST 渲染惯例一致）λ₁ = +0.0445/帧
      —— 与洛伦兹的 +0.0453 **几乎相同**，这给了一个更干净的对照：
         「同样 λ₁、不同光滑性」（连续流 vs 不连续接触）⇒ 差异只能归因于不连续性
  · 无碰撞对照（n=1）精确 0 ⇒ 测量机器已标定；δ₀ 无关性通过
  · 两个建模陷阱被诊断拦住（都会制造假的 λ₁）：相切粘滞、无条件去重叠

设计（单变量）：
  · 与 gray_s3 基线的唯一差别 = 数字之间加入弹性碰撞（e=1）
  · 同一 VAE、同一网络（dyn.LatentDynamics ctx=2）、同超参、同数据量、同序列长度
  · **无动作** —— 动作版本已被 t18_diag.py 否掉：所有数字共享一个动作 +
    速度上限 clip，会让速度趋同 ⇒ 相对速度消失 ⇒ 碰撞消失（系统"冻结"）

两套环境给 λ₁ 两档：
  · reflect  → λ₁_true = +0.0445/帧（≈ 洛伦兹；检验「不连续性」的独立效应）
  · periodic → λ₁_true = +0.374/帧（8.25×；检验「λ₁ 大 ⇒ T_crash 对 b 不敏感」）

判据：
  ① VAE 跨域守卫：碰撞数据的重建质量不能显著劣于 gray_s3（否则编码误差混入结论）
  ② 单步潜余弦（与 gray_s3 同口径，0.92156 是基线）
  ③ QR λ₁(模型)（解析雅可比 + lyap 的和检验）
  ④ T_crash(b)（与 T4 完全一致的状态量化口径）+ 斜率反推有效 λ
     —— **必须剔除 floor 档**（Δ/2 > δ* 时第一步必崩）。

产物 logs/t18_collide.json、ckpt/t18_{kind}_dyn.pt
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from vae import LATENT, CKPT, load_vae          # noqa: E402
from dyn import LatentDynamics                  # noqa: E402
from collide import make_seq_collide, N_DIGIT   # noqa: E402
from lyap import qr_spectrum_map                # noqa: E402
from guards import G                            # noqa: E402

DEV = "cuda" if torch.cuda.is_available() else "cpu"
H = W = 64
CTX, EPOCHS, BATCH = 2, 600, 2048
BITS = [2, 3, 4, 6, 8, 12, 16, 32]
DELTA_STAR = (1.0,)
N_IC, ROLLOUT = 32, 300
OUT = os.path.join(ROOT, "logs", "t18_collide.json")

# 真值 λ₁ —— 来自 logs/t18_truth.json 的**均值**（12 初值 × 10000 步）。
# 注意：reflect 档是混合分布（一部分初值永不碰撞 → λ₁=0），中位数随样本量剧烈跳动
# （8/12/24 初值分别给 0.044/0.088/0.000），**只有均值可用**。见 T18_碰撞环境.md §2。
# 勘误：原先这两个值来自 n_digit=3 的测量，而本脚本的数据是
#   `collide.N_DIGIT = 2`（JSON 的 config.n_digit=2 可查）—— 模型与基准不是同一个系统。
#   现改用 logs/t18_truth_n2.json 的**同 n_digit=2** 测量（24 初值 × 20000 步）：
#     periodic +0.26367±0.02915（旧误用 n=3 的 +0.35020）
#     reflect  +0.05248±0.00705（n=3 值为 +0.05149，恰好基本相同）
LAM_TRUE = {"reflect": 0.05248, "periodic": 0.26367}


# ---------------------------------------------------------------- 数据
def make_data(kind, n, seed, split_train, n_digit=N_DIGIT, verbose=True):
    from variant2 import GRAY
    digits = GRAY[split_train]
    F_, cols = [], []
    t0 = time.time()
    for i in range(n):
        rng = np.random.default_rng((seed * 1_000_003 + i) % (2 ** 32))
        f, _, c = make_seq_collide(digits, rng, n_digit=n_digit, boundary=kind)
        F_.append(f)
        cols.append(c)
    if verbose:
        print(f"    生成 {n} 条：{time.time()-t0:.0f}s   每序列碰撞 "
              f"{np.mean(cols):.2f} 次（范围 {min(cols)}–{max(cols)}）")
    return np.stack(F_), float(np.mean(cols))


def encode_all(vae, frames):
    """frames (n,T,64,64) uint8 → z (n,T,LATENT) float32"""
    n, T = frames.shape[0], frames.shape[1]
    out = []
    with torch.no_grad():
        x = torch.from_numpy(frames).float().div_(255.0).reshape(-1, H, W)
        for i in range(0, x.shape[0], 512):
            out.append(vae.encode_det(x[i:i + 512].unsqueeze(1).to(DEV)).cpu())
    return torch.cat(out).view(n, T, LATENT)


def recon_quality(vae, frames):
    """VAE 跨域守卫：逐帧重建的像素余弦（与 gray_s3 基线同口径比较）。"""
    with torch.no_grad():
        x = torch.from_numpy(frames[:64]).float().div_(255.0).reshape(-1, H, W)
        z = vae.encode_det(x.unsqueeze(1).to(DEV))
        r = torch.sigmoid(vae.decode(z)).view(-1, H * W).cpu()
    xf = (x > 0.5).float().view(-1, H * W)
    return float(F.cosine_similarity(r, xf, dim=-1).mean())


# ---------------------------------------------------------------- 训练
def train_dyn(ztr, mean, std, epochs=EPOCHS, batch=BATCH, seed=0, verbose=True):
    torch.manual_seed(seed)
    n, T = ztr.shape[0], ztr.shape[1]
    ii, tt = torch.meshgrid(torch.arange(n), torch.arange(CTX, T - 1), indexing="ij")
    ii, tt = ii.reshape(-1), tt.reshape(-1)          # 索引留 CPU
    m = LatentDynamics(ctx=CTX).to(DEV)
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=1e-4)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    n_idx = ii.shape[0]
    t0 = time.time()
    for ep in range(epochs):
        perm = torch.randperm(n_idx)[:min(n_idx, 105 * batch)]
        for i0 in range(0, perm.numel(), batch):
            sel = perm[i0:i0 + batch]
            bi, bt = ii[sel], tt[sel]
            ca = ((ztr[bi, bt - 1].to(DEV) - mean) / std).unsqueeze(1)
            cb = ((ztr[bi, bt].to(DEV) - mean) / std).unsqueeze(1)
            zc = torch.cat([ca, cb], dim=1)
            tgt = ztr[bi, bt + 1].to(DEV)
            pred = m(zc) * std + mean
            loss = F.mse_loss(pred, tgt)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(m.parameters(), 5.0)
            opt.step()
        sch.step()
    if verbose:
        print(f"    训练完成 {time.time()-t0:.0f}s")
    return m


# ---------------------------------------------------------------- 评估
def single_step_cos(m, zva, mean, std, take=32):
    cos = []
    with torch.no_grad():
        for i in range(min(take, zva.shape[0])):
            z = zva[i]
            ca = (z[0].to(DEV) - mean) / std
            cb = (z[1].to(DEV) - mean) / std
            p = (m(torch.stack([ca, cb]).unsqueeze(0))[0] * std + mean).cpu()
            cos.append(float(F.cosine_similarity(p, z[2], dim=-1)))
    return float(np.mean(cos))


CLIP = 15.0       # QR 迭代的数值保护（模型在训练分布外可能发散）


def analytic_jac(m):
    """LatentDynamics 的增广解析雅可比（128×128）。

    f(z_t, z_{t-1}) = 2z_t − z_{t-1} + net([z_t, z_{t-1}])
    ⇒ ∂f/∂z_t = 2I + ∂net/∂(前半输入)，∂f/∂z_{t-1} = −I + ∂net/∂(后半输入)
    不用有限差分：float32 下舍入误差 ∝ 1/eps。

    若 QR 迭代初值不在数据分布上，轨迹会指数发散并在 float64 下溢出为 NaN；
    f 与 jac 须使用同一个 clip 以保证一致，并记录 clip 触发情况。
    """
    W1 = m.net[0].weight.detach().cpu().numpy().astype(np.float64)
    b1 = m.net[0].bias.detach().cpu().numpy().astype(np.float64)
    W2 = m.net[2].weight.detach().cpu().numpy().astype(np.float64)
    b2 = m.net[2].bias.detach().cpu().numpy().astype(np.float64)
    W3 = m.net[4].weight.detach().cpu().numpy().astype(np.float64)
    b3 = m.net[4].bias.detach().cpu().numpy().astype(np.float64)
    L = LATENT
    Eye = np.eye(L)

    def f_aug(u):
        u = np.clip(u, -CLIP, CLIP)
        a, b = u[:L], u[L:]
        zc = np.concatenate([a, b])
        h1 = np.clip(W1 @ zc + b1, -60, 60)
        g1 = h1 / (1.0 + np.exp(-h1))                     # SiLU
        h2 = np.clip(W2 @ g1 + b2, -60, 60)
        g2 = h2 / (1.0 + np.exp(-h2))
        out = np.concatenate([b, 2 * a - b + W3 @ g2 + b3])
        return np.clip(out, -CLIP, CLIP)

    def silu_d(h):
        s = 1.0 / (1.0 + np.exp(-np.clip(h, -60, 60)))
        return s + h * s * (1.0 - s)

    def jac(u):
        u = np.clip(u, -CLIP, CLIP)
        a, b = u[:L], u[L:]
        zc = np.concatenate([a, b])
        h1 = np.clip(W1 @ zc + b1, -60, 60)
        g1 = h1 / (1.0 + np.exp(-h1))
        h2 = np.clip(W2 @ g1 + b2, -60, 60)
        d1 = silu_d(h1)
        d2 = silu_d(h2)
        dn = W3 @ (d2[:, None] * (W2 @ (d1[:, None] * W1)))   # ∂net/∂zc (L, 2L)
        J = np.zeros((2 * L, 2 * L))
        J[:L, L:] = Eye
        J[L:, :L] = -Eye + dn[:, :L]
        J[L:, L:] = 2 * Eye + dn[:, L:]
        return J

    return f_aug, jac


def qr_lam1(m, z0, n_steps=8000, discard=2000):
    """QR λ₁。初值取**真实数据的一个归一化状态**（不在分布内会数值发散）。"""
    f, j = analytic_jac(m)
    x0 = np.asarray(z0, dtype=np.float64)
    return qr_spectrum_map(f, j, x0=x0, n_steps=n_steps, discard=discard)


def qstate(z, b, lo, hi):
    """均匀量化到 [lo, hi] 的 b 位（与 T4 完全同口径）。"""
    delta = (hi - lo) / (2 ** b - 1)
    return torch.clamp(torch.round((z - lo) / delta), 0, 2 ** b - 1) * delta + lo


def rollout_crash(m, z0, bits, lo, hi, ds_list=DELTA_STAR, steps=ROLLOUT,
                  n_ic=N_IC, zva=None):
    """同初值的「量化 vs 不量化」自回归 rollout，返回每档 δ* 的 T_crash 分布。

    与 T4 一致：**参考轨迹用的是模型自身**（不是真值），所以测的是
    「状态量化引入的额外偏离」的增长，而不是模型的预测误差。
    """
    out = {d: [] for d in ds_list}
    cens = {d: 0 for d in ds_list}
    end_delta = []
    for i in range(n_ic):
        z = zva[i % zva.shape[0]]
        with torch.no_grad():
            a0 = (z[0].to(DEV) - mean_g) / std_g
            b0 = (z[1].to(DEV) - mean_g) / std_g
            zr_a, zr_b = a0.clone(), b0.clone()
            zq_a, zq_b = a0.clone(), b0.clone()
            hit = {d: None for d in ds_list}
            d = 0.0
            for t in range(steps):
                zr = m(torch.stack([zr_a, zr_b]).unsqueeze(0))[0]
                zq = m(torch.stack([zq_a, zq_b]).unsqueeze(0))[0]
                zq = qstate(zq, bits, lo, hi)
                d = float((zq - zr).norm())
                for ds in ds_list:
                    if hit[ds] is None and d > ds:
                        hit[ds] = t + 1
                if all(v is not None for v in hit.values()):
                    break
                zr_a, zr_b = zr_b, zr
                zq_a, zq_b = zq_b, zq
            end_delta.append(d)
        for ds in ds_list:
            if hit[ds] is None:
                cens[ds] += 1
            else:
                out[ds].append(hit[ds])
    return out, cens, end_delta


mean_g = std_g = None      # 由 main 填充（模块级，供 rollout_crash 使用）


def fit_line(pts):
    if len(pts) < 2:
        return None
    b = np.array([p[0] for p in pts], float)
    t = np.array([p[1] for p in pts], float)
    A = np.vstack([b, np.ones_like(b)]).T
    (sl, ic), *_ = np.linalg.lstsq(A, t, rcond=None)
    pred = A @ np.array([sl, ic])
    r2 = 1 - ((t - pred) ** 2).sum() / max(((t - t.mean()) ** 2).sum(), 1e-12)
    return float(sl), float(ic), float(r2), len(pts)


def main():
    global mean_g, std_g
    ap = argparse.ArgumentParser()
    ap.add_argument("--kind", default="reflect", choices=["reflect", "periodic"])
    ap.add_argument("--n-train", type=int, default=12000)
    ap.add_argument("--n-val", type=int, default=128)
    ap.add_argument("--epochs", type=int, default=EPOCHS)
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--retrain", action="store_true", help="强制重跑生成与训练")
    ap.add_argument("--retrain-dyn", action="store_true", help="只重训模型（复用潜向量）")
    a = ap.parse_args()
    if a.quick:
        a.n_train, a.epochs = 2000, 60
    suf = "_quick" if a.quick else ""
    t0 = time.time()
    torch.manual_seed(0)

    vae = load_vae()
    vae.load_state_dict(torch.load(os.path.join(CKPT, "vae_gray_s3.pt"),
                                   map_location=DEV, weights_only=True)["state"])
    vae.eval()

    print("=" * 100)
    print(f"  T18 · 碰撞环境（{a.kind}）—— 不连续接触 vs 连续流，同 λ₁ 对照")
    print("=" * 100)
    print(f"  真值 λ₁（前置实测）：{LAM_TRUE[a.kind]:+.5f}/帧   "
          f"（对照：洛伦兹 +0.0453 连续光滑；gray_s3 0.000 无碰撞）")
    print(f"  数据：train {a.n_train} 条 / val {a.n_val} 条   **{N_DIGIT} 个数字**   "
          f"{20} 帧   速度 ±1..±3")
    print(f"  ⚠ 此前该行硬编码为「3 个数字」而实际 N_DIGIT={N_DIGIT} —— 已修；"
          f"真值 λ₁ 必须用**同 n_digit** 的测量（见 t18_truth_n2.py）")

    # ---- 数据 + 编码 + 训练（两段独立缓存：潜向量 / 模型各自可复用）
    ck_lat = os.path.join(CKPT, f"t18_{a.kind}{suf}_latents.pt")
    ck_dyn = os.path.join(CKPT, f"t18_{a.kind}{suf}_dyn.pt")
    if os.path.exists(ck_lat) and not a.retrain:
        print("\n  [1] 复用已保存的潜向量（--retrain 可强制重跑）")
        dd = torch.load(ck_lat, map_location="cpu", weights_only=True)
        ztr, zva = dd["ztr"], dd["zva"]
        rq, ctr = float(dd["rq"]), float(dd["ctr"])
        print(f"    VAE 重建余弦 {rq:.5f}   每序列碰撞 {ctr:.2f}   "
              f"潜向量 {tuple(ztr.shape)}")
    else:
        print("\n  [1] 生成与编码")
        ftr, ctr = make_data(a.kind, a.n_train, 0, True)
        fva, cva = make_data(a.kind, a.n_val, 999, False)
        rq = recon_quality(vae, fva)
        ztr = encode_all(vae, ftr)
        zva = encode_all(vae, fva)
        print(f"    VAE 重建余弦（碰撞数据，跨域）{rq:.5f}"
              f"   ← 对照 gray_s3 同域 0.90484")
        assert ztr.shape == (a.n_train, 20, LATENT), f"形状异常 {tuple(ztr.shape)}"
        assert zva.shape == (a.n_val, 20, LATENT), f"形状异常 {tuple(zva.shape)}"
        assert torch.isfinite(ztr).all(), "潜向量含 NaN/Inf"
        del ftr, fva
        torch.save(dict(ztr=ztr, zva=zva, rq=rq, ctr=ctr), ck_lat)

    mean_g = ztr.mean(dim=(0, 1)).to(DEV)
    std_g = ztr.std(dim=(0, 1)).clamp_min(1e-6).to(DEV)
    print(f"    潜向量 |z| 均值 {float(ztr.abs().mean()):.3f}")

    if os.path.exists(ck_dyn) and not a.retrain and not a.retrain_dyn:
        print("\n  [2] 复用已训练的模型")
        m = LatentDynamics(ctx=CTX).to(DEV)
        m.load_state_dict(torch.load(ck_dyn, map_location=DEV,
                                     weights_only=False)["state"])
        m.eval()
    else:
        print("\n  [2] 训练 dyn（与 gray_s3 单步基线同构同超参）")
        m = train_dyn(ztr, mean_g, std_g, epochs=a.epochs)
        torch.save(dict(state=m.state_dict(), ctx=CTX, latent=LATENT,
                        mean=mean_g.cpu(), std=std_g.cpu(),
                        cfg=dict(kind=a.kind, n_digit=N_DIGIT)), ck_dyn)

    # ---- 判据
    print("\n  [3] 判据")
    cos1 = single_step_cos(m, zva, mean_g, std_g)
    z0qr = np.concatenate([((zva[0, 0].to(DEV) - mean_g) / std_g).cpu().numpy(),
                           ((zva[0, 1].to(DEV) - mean_g) / std_g).cpu().numpy()])
    lam = qr_lam1(m, z0qr, n_steps=8000 if not a.quick else 2000)
    print(f"    单步潜余弦 {cos1:.5f}   （gray_s3 基线 0.92156；退化基线 0.6853）")
    print(f"    QR λ₁(模型) {lam[0]:+.5f}   谱 [{lam[0]:+.4f}, {lam[1]:+.4f}, "
          f"{lam[2]:+.4f}]   和检验 {lam.sum():+.5f}")
    print(f"    真值 λ₁ {LAM_TRUE[a.kind]:+.5f}  → 模型偏差 "
          f"{(lam[0]-LAM_TRUE[a.kind]):+.5f}")

    # T_crash
    lo = float(zva.min()) - 0.5
    hi = float(zva.max()) + 0.5
    span = hi - lo
    print(f"\n    T_crash(b)：状态量化口径（与 T4 一致）；lo/hi 跨度 {span:.2f}，"
          f"δ* = {DELTA_STAR[0]}")
    print(f"    ⚠ floor 判据按**维度**算：L={LATENT} 维的首次注入 rms = "
          f"√L·Δ/√12 ≈ {math.sqrt(LATENT)/math.sqrt(12.0):.2f}·Δ")
    print(f"    {'b':>3} {'Δ':>8} {'首次注入':>9} {'T_crash 中位':>13} {'IQR':>14} "
          f"{'未崩':>5} {'δ_∞ 中位':>10}  备注")
    rows = []
    for b in BITS:
        delta = span / (2 ** b - 1)
        inj = math.sqrt(LATENT) * delta / math.sqrt(12.0)     # 首步注入的范数 rms
        res, cens, endd = rollout_crash(m, None, b, lo, hi, zva=zva)
        v = sorted(res[DELTA_STAR[0]])
        med = float(np.median(v)) if v else None
        q1 = float(np.percentile(v, 25)) if v else None
        q3 = float(np.percentile(v, 75)) if v else None
        dinf = float(np.median(endd)) if endd else None
        floor = inj > DELTA_STAR[0]
        rows.append(dict(bits=b, delta=delta, inj=inj, med=med, q1=q1, q3=q3,
                         n=len(v), censored=cens[DELTA_STAR[0]],
                         d_end_med=dinf, floor=bool(floor)))
        note = "← floor（首步注入即超 δ*，**必须剔除**）" if floor else ""
        print(f"    {b:>3} {delta:>8.4f} {inj:>9.3f} "
              f"{('—' if med is None else f'{med:.1f}'):>13} "
              f"{('—' if not v else f'[{q1:.0f},{q3:.0f}]'):>14} "
              f"{cens[DELTA_STAR[0]]:>5} "
              f"{('—' if dinf is None else f'{dinf:.4f}'):>10}  {note}")

    # ---- 主响应：δ_∞(b)（对所有档位都可测，包括"永不崩溃"的档位）
    print(f"\n    **主响应 δ_∞(b)**（用量化后 rollout 的稳态偏离；比 T_crash 信息量大 ——"
          f"\n      「永不崩溃」的档位在 T_crash 上只能记作删失，在 δ_∞ 上是可测的）")
    b_star = None
    print(f"    {'b':>3} {'δ_∞ 中位':>10} {'δ_∞ / δ*':>10}  判定")
    for r in rows:
        if r["d_end_med"] is None:
            continue
        ratio = r["d_end_med"] / DELTA_STAR[0]
        if ratio < 1.0 and b_star is None:
            b_star = r["bits"]
        print(f"    {r['bits']:>3} {r['d_end_med']:>10.4f} {ratio:>10.4f}  "
              + ("✓ δ_∞ < δ* ⇒ 该档永不崩溃" if ratio < 1 else "δ_∞ ≥ δ* ⇒ 会崩"))
    print(f"    **临界位宽 b\\* = {b_star}**（最小的 b 使 δ_∞ < δ*）")
    Q_bstar = b_star

    # ---- 斜率（剔 floor）与理论对照
    ok = [r for r in rows if r["med"] is not None and not r["floor"]]
    fit_all = fit_line([(r["bits"], r["med"]) for r in rows if r["med"] is not None])
    fit_ok = fit_line([(r["bits"], r["med"]) for r in ok])
    print(f"\n    {'拟合区间':<26} {'斜率':>9} {'R²':>8} {'n':>3} "
          f"{'反推 λ_eff':>11} {'vs 真值':>9}")
    for name, ft in (("含 floor 档（**伪影**）", fit_all), ("剔除 floor 档", fit_ok)):
        if ft:
            sl, _, r2, n = ft
            eff = math.log(2) / sl
            print(f"    {name:<26} {sl:>9.3f} {r2:>8.3f} {n:>3} {eff:>11.4f} "
                  f"{(eff-LAM_TRUE[a.kind])/LAM_TRUE[a.kind]*100:>+8.0f}%")
    print(f"    理论斜率 log2/λ_true = {math.log(2)/LAM_TRUE[a.kind]:.2f} 步/位")

    Q = dict(config=dict(kind=a.kind, n_train=a.n_train, n_val=a.n_val,
                         epochs=a.epochs, bits=BITS, dstar=list(DELTA_STAR),
                         n_ic=N_IC, rollout=ROLLOUT, n_digit=N_DIGIT),
             lam_true=LAM_TRUE[a.kind], collisions_per_seq=ctr,
             vae_recon_cos=rq, cos_single=cos1,
             lam1_model=float(lam[0]), lam_spec=[float(x) for x in lam[:6]],
             sum_check=float(lam.sum()),
             rows=rows, fit_all=fit_all, fit_nofloor=fit_ok, b_star=Q_bstar,
             elapsed_s=round(time.time() - t0, 1))
    prev = {}
    if os.path.exists(OUT):
        prev = json.load(open(OUT, encoding="utf-8"))
    prev[a.kind] = Q
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(prev, f, ensure_ascii=False)
    print(f"\n  → {OUT}（{a.kind} 段已写入，{Q['elapsed_s']}s）")


if __name__ == "__main__":
    main()
