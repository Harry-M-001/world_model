"""校验 optstate_quant.md 与材料评估 md 的关键数字是否与 logs/*.json 一致。"""
import json
import math
import os
import _paths  # noqa: E402
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
T = json.load(open(os.path.join(ROOT, "logs", "t13_optstate.json"), encoding="utf-8"))
Q = json.load(open(os.path.join(ROOT, "logs", "logquant_check.json"), encoding="utf-8"))
doc = open(_paths.phase1("optstate_quant.md"), encoding="utf-8").read()
mat = open(_paths.phase1("材料评估_对数量化与Jev.md"), encoding="utf-8").read()

AB, C = T["AB"], T["C"]
R = {r["bits"] * 10 + (0 if r["mode"] == "全局" else 1): r for r in AB["detail"]}
log = {b: C[f"log_b{b}"] for b in (4, 8, 16, 32)}
lin = {b: C[f"lin_b{b}"] for b in (4, 8, 16)}
base = C["_baseline"]
real = Q["real_weights"]

checks = [
    # T13 Part A
    ("v̂ log10 跨度 9.14", abs(AB["v_log10_span"] - 9.14) < 0.01 and "**9.14**" in doc),
    ("相对误差均值 0.4318 / 0.0965",
     abs(R[40]["rel_mean"] - 0.4318) < 1e-4 and abs(R[80]["rel_mean"] - 0.0965) < 1e-4
     and "0.4318" in doc and "0.0965" in doc),
    ("相对误差 P99 = max = 1.0000",
     R[40]["rel_p99"] == 1.0 and R[40]["rel_max"] == 1.0 and "1.0000" in doc),
    ("max/均值 2.3 / 10.4 / 8.6 / 28.3",
     abs(R[40]["spread"] - 2.3) < 0.1 and abs(R[80]["spread"] - 10.4) < 0.1
     and abs(R[41]["spread"] - 8.6) < 0.1 and abs(R[81]["spread"] - 28.3) < 0.1),
    # T13 Part C
    ("linear 三档全 NaN @step 5/5/3",
     all(lin[b]["nan_step"] is not None for b in (4, 8, 16))
     and [lin[b]["nan_step"] for b in (4, 8, 16)] == [5, 5, 3]),
    ("log b=4 MSE 1.6881", abs(log[4]["val_mse"] - 1.6881) < 1e-4 and "1.6881" in doc),
    ("log b=8 MSE 1.7096", abs(log[8]["val_mse"] - 1.7096) < 1e-4),
    ("log b=16 MSE 1.7052", abs(log[16]["val_mse"] - 1.7052) < 1e-4),
    ("log b=32 基线 MSE 1.7086", abs(log[32]["val_mse"] - 1.7086) < 1e-4),
    ("log b=4 λ₁ +0.01222 ± 0.05151",
     abs(log[4]["lam1"] - 0.01222) < 1e-5 and abs(log[4]["lam1_std"] - 0.05151) < 1e-5),
    ("log b=32 λ₁ −0.03067 ± 0.03542",
     abs(log[32]["lam1"] + 0.03067) < 1e-5 and abs(log[32]["lam1_std"] - 0.03542) < 1e-5),
    ("效应/噪声 1.19 / 1.68 / 1.72（<2.5 判「在噪声内」）",
     all(abs(log[b]["lam1"] - base["lam1"])
         / math.sqrt(log[b]["lam1_std"] ** 2 + base["lam1_std"] ** 2) * math.sqrt(3)
         < 2.5 for b in (4, 8, 16))),
    ("T13 文档含「4 位即无损」的判断", "4 位就与 fp32 持平" in doc or "4 位即无损" in doc),
    # 材料一
    ("真实权重峰度 6.99 / 4.41",
     abs(real["VAE(gray_s3)"]["kurtosis"] - 6.99) < 0.01
     and abs(real["dyn(gray_s3)"]["kurtosis"] - 4.41) < 0.01),
    ("Hill α 2.96 / 2.93",
     abs(real["VAE(gray_s3)"]["hill"] - 2.96) < 0.01
     and abs(real["dyn(gray_s3)"]["hill"] - 2.93) < 0.01),
    ("权重实测均匀优 1.6–2.6×",
     real["_mse"]["VAE(gray_s3)_b8"]["ratio"] < 1 and real["_mse"]["dyn(gray_s3)_b8"]["ratio"] < 1
     and "1.6–2.6" in mat),
    ("材料评估含「判据失效」的判定", "判据会失效" in mat or "已失效" in mat),
]
bad = [n for n, ok in checks if not ok]
print(f"T13 与材料评估的数字核对 {len(checks)} 项：",
      "全部通过 ✅" if not bad else f"失败 {bad}")
print()
print("  参考：")
print(f"    v̂ log10 跨度 {AB['v_log10_span']:.2f}")
print(f"    linear NaN step: " + ", ".join(f"b{b}={lin[b]['nan_step']}" for b in (4, 8, 16)))
print(f"    log MSE: " + ", ".join(f"b{b}={log[b]['val_mse']:.4f}" for b in (4, 8, 16, 32)))
print(f"    log λ₁ : " + ", ".join(f"b{b}={log[b]['lam1']:+.5f}±{log[b]['lam1_std']:.5f}"
                                   for b in (4, 8, 16, 32)))
