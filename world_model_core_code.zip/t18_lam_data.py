"""
T18 补救 · 沿**真值数据轨迹**测 λ₁（替代原先让模型自回归迭代的 QR）

问题（`logs/_t18qr.log` 实测）：
  原先的 QR 迭代让**模型自己**反复作用，结果 **clip 触发率 99.95%–99.98%** ——
  轨迹早已飞出训练分布，测到的是「模型在其有效域之外」的切空间扩张率，
  而且随初值剧烈变化（reflect +0.35~+0.49、periodic +0.41~+0.64）。**该数字不可用。**

修法：轨迹**始终留在数据分布上** —— 用真值潜向量序列上的相邻帧对作为状态，
逐点取模型的局部 Jacobian，累积其 QR 的对数对角元：

    λ₁ ≈ (1/N) Σ_n log σ₁(J(u_n))，  u_n = [z_t, z_{t-1}]（归一化，来自真值数据）

版本一致性注意：若运行时模型 checkpoint 仍在写入，可能静默读到旧版本。
  每次运行打印模型 mtime，并把 mtime 写入结果 JSON，便于核对。

用法：
  python t18_lam_data.py --kinds reflect --steps 20000
  python t18_lam_data.py --kinds reflect,periodic,gray_s3
"""
import argparse
import datetime
import json
import os
import sys

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from dyn import LatentDynamics                      # noqa: E402
from t18_collide import analytic_jac, CTX           # noqa: E402
from vae import LATENT                              # noqa: E402

OUT = os.path.join(ROOT, "logs", "t18_lambda_data.json")

SRC = {
    "reflect": ("t18_reflect_dyn.pt", "t18_reflect_latents.pt", "ztr"),
    "periodic": ("t18_periodic_dyn.pt", "t18_periodic_latents.pt", "ztr"),
    "gray_s3": ("dyn_gray_s3_ctx2.pt", "latents_gray_s3__n_seq12000_seed0.pt", "z"),
}


def lam_on_data(m, ztr, mean, std, n_steps=40000, seed=0):
    """沿真值数据轨迹累积 QR。返回 (λ₁ 谱, 诊断)。"""
    f, j = analytic_jac(m)
    rng = np.random.default_rng(seed)
    n, T = ztr.shape[0], ztr.shape[1]
    ii = rng.integers(0, n, size=n_steps)
    tt = rng.integers(1, T - 1, size=n_steps)          # 保证 t-1 与 t 都存在
    Q = np.eye(2 * LATENT)
    acc = np.zeros(2 * LATENT)
    mx = []
    for k in range(n_steps):
        a = ((ztr[ii[k], tt[k] - 1] - mean) / std).numpy().astype(np.float64)
        b = ((ztr[ii[k], tt[k]] - mean) / std).numpy().astype(np.float64)
        u = np.concatenate([a, b])
        mx.append(float(np.abs(u).max()))
        Q, R = np.linalg.qr(j(u) @ Q)
        acc += np.log(np.maximum(np.abs(np.diag(R)), 1e-300))
    lam = acc / n_steps
    return lam, dict(u_max=float(np.max(mx)), u_max_med=float(np.median(mx)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kinds", default="reflect,periodic,gray_s3")
    ap.add_argument("--steps", type=int, default=40000)
    a = ap.parse_args()
    kinds = [k.strip() for k in a.kinds.split(",") if k.strip()]

    D = json.load(open(os.path.join(ROOT, "logs", "t18_collide.json"),
                       encoding="utf-8"))
    print("=" * 96)
    print("  T18 补救 · 沿真值数据轨迹的 λ₁（轨迹始终在数据分布上）")
    print("=" * 96)
    print(f"  每档 {a.steps} 个转移；**每次都打印模型 mtime**（首跑曾静默用到旧 ckpt）\n")

    out = {}
    for kind in kinds:
        if kind not in SRC:
            print(f"  未知档 {kind}，跳过")
            continue
        dyn_f, lat_f, zkey = SRC[kind]
        ck = os.path.join(ROOT, "ckpt", dyn_f)
        lat = os.path.join(ROOT, "ckpt", lat_f)
        if not (os.path.exists(ck) and os.path.exists(lat)):
            print(f"  {kind}: 缺文件（{dyn_f} / {lat_f}），跳过")
            continue
        mt = os.path.getmtime(ck)
        mts = datetime.datetime.fromtimestamp(mt).strftime("%Y-%m-%d %H:%M:%S")
        sd = torch.load(ck, map_location="cpu", weights_only=False)
        m = LatentDynamics(ctx=CTX)
        m.load_state_dict(sd["state"] if "state" in sd else sd)
        m.eval()
        ztr = torch.load(lat, map_location="cpu", weights_only=True)[zkey]
        mean = ztr.mean(dim=(0, 1))
        std = ztr.std(dim=(0, 1)).clamp_min(1e-6)
        lam, diag = lam_on_data(m, ztr, mean, std, n_steps=a.steps)
        true_lam = float(D[kind]["lam_true"]) if kind in D else 0.0
        print(f"  === {kind} ===")
        print(f"    模型 {dyn_f}   **mtime {mts}**   潜向量 {tuple(ztr.shape)}")
        print(f"    λ₁（数据分布上，{a.steps} 个转移） = **{lam[0]:+.5f}**")
        print(f"    谱前 5: {[round(float(x), 4) for x in lam[:5]]}   "
              f"和检验 {float(lam.sum()):+.3f}")
        print(f"    真值 λ₁ = {true_lam:+.5f}   偏差 {lam[0]-true_lam:+.5f}"
              + (f"   保留比例 {lam[0]/true_lam*100:.1f}%" if true_lam else ""))
        print(f"    诊断：输入 |u| 最大 {diag['u_max']:.3f}"
              f"（中位 {diag['u_max_med']:.3f}）—— 与训练分布一致说明没跑飞")
        out[kind] = dict(lam1_data=float(lam[0]),
                         spec=[float(x) for x in lam[:5]],
                         sum_check=float(lam.sum()),
                         lam_true=true_lam, n_steps=a.steps,
                         model_file=dyn_f, model_mtime=mts,
                         **diag)

    prev = {}
    if os.path.exists(OUT):
        prev = json.load(open(OUT, encoding="utf-8"))
    prev.update(out)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(prev, f, ensure_ascii=False, indent=2)
    print(f"\n  → {OUT}（已合并写入 {list(out)}）")


if __name__ == "__main__":
    main()
