"""
T18 补充 · multistep 对照的**机制诊断**：msK 的地板消失，是「变收缩」还是「变好」？

背景：multistep 训练后 periodic 臂的 δ_∞@b=32 从 1.1178 掉到 1.55e-05、b* 从 None 变成 12。
      两种解释必须分开：
        (a) **变收缩**：msK 训练使模型自身的动力学更耗散 ⇒ 量化扰动被吸收 ⇒ δ_∞→0
            （这是 T4 框架里 δ_∞ = ε/(1−ρ) 的合法机制，但代价是动力学保真度下降）
        (b) **变好**：msK 真的改善了多步预测 ⇒ 扰动不再被放大
      两者对结论的含义完全不同，必须用测量区分。

三个诊断（都不依赖 QR，因此没有 T18 那个 clip 伪影问题）：
  ① **模型自身轨迹的范数**：300 步 rollout 的 ‖z‖ 是否塌缩到一点
     —— 若塌缩，δ_∞→0 只是「两条轨迹都落到同一个不动点」，是平凡结果
  ② **孪生轨迹发散率**（Benettin on model）：模型自身吸引子上两个相距 1e-6 的初值，
     其距离的对数增长率 —— 这是「模型自回归轨迹的 Lyapunov 指数」的直接测量
     （T3/T3b/T4b 报的就是这个量，这里用孪生轨迹法避开 QR 的 clip 伪影）
  ③ **精度侧**：与真值的相对误差、以及开环余弦（衡量「变好」的那一面）

用法：python t18_ms_diag.py
产物：logs/t18_ms_diag.json
"""
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from dyn import LatentDynamics              # noqa: E402
from vae import LATENT, CKPT                # noqa: E402
from t18_collide import CTX                 # noqa: E402

DEV = "cuda" if torch.cuda.is_available() else "cpu"
OUT = os.path.join(ROOT, "logs", "t18_ms_diag.json")
STEPS = 300


def load(kind, arm):
    f = (f"t18_{kind}_dyn.pt" if arm == "single"
         else f"t18_{kind}_K5_ep2000_dyn.pt")
    p = os.path.join(CKPT, f)
    m = LatentDynamics(ctx=CTX).to(DEV)
    m.load_state_dict(torch.load(p, map_location=DEV, weights_only=False)["state"])
    m.eval()
    return m, f


def rollout_stats(m, zva, mean, std, steps=STEPS, take=32):
    """① 自身轨迹范数；③ 与真值的相对误差。"""
    norms, errs = [], []
    with torch.no_grad():
        for i in range(min(take, zva.shape[0])):
            z = zva[i]
            a = (z[0].to(DEV) - mean) / std
            b = (z[1].to(DEV) - mean) / std
            ns, es = [], []
            for k in range(steps):
                p = m(torch.stack([a, b]).unsqueeze(0))[0]
                a, b = b, p
                ns.append(float(p.norm()))
                if k + 1 < z.shape[0]:
                    es.append(float((p * std + mean - z[1 + k].to(DEV)).norm()
                                    / z[1 + k].to(DEV).norm()))
            norms.append(ns)
            if es:
                errs.append(es)
    N = np.array(norms)
    return dict(
        norm_t0=float(N[:, 0].mean()), norm_t5=float(N[:, min(5, N.shape[1]-1)].mean()),
        norm_t50=float(N[:, min(50, N.shape[1]-1)].mean()),
        norm_end=float(N[:, -1].mean()),
        norm_end_std=float(N[:, -1].std()),
        err_early=float(np.mean([e[0] for e in errs])),
        err_t15=float(np.mean([e[min(14, len(e)-1)] for e in errs])),
    )


def twin_divergence(m, zva, mean, std, steps=2000, eps=1e-6, take=32,
                    renorm=0.5, warmup=20):
    """模型**自身轨迹**的 λ₁（孪生轨迹 + 阈值重归一化，口径与 t18_truth.benettin 一致）。

    参数注意：renorm=20 远大于吸引子尺度时，扰动进入饱和区后被截断，
      测得的是「饱和倍率^(1/T)」而非指数增长率，且重归一化几乎不触发（误显示为无扩张）。
      应取 eps=1e-9、renorm=0.5，使扰动保持在线性区。
    这是与 T3/T3b/T4b 的 QR 同一物理量的独立测量（避开 QR 的 clip 伪影）。
    """
    rates, nrens, norms = [], [], []
    with torch.no_grad():
        for i in range(min(take, zva.shape[0])):
            z = zva[i]
            a0 = (z[0].to(DEV) - mean) / std
            b0 = (z[1].to(DEV) - mean) / std
            for _ in range(warmup):               # 先落到模型自己的吸引子上
                p = m(torch.stack([a0, b0]).unsqueeze(0))[0]
                a0, b0 = b0, p
            a1, b1 = a0.clone(), b0.clone()
            b1 = b1 + eps / math.sqrt(LATENT)
            acc, nren, bad = 0.0, 0, False
            for k in range(steps):
                p0 = m(torch.stack([a0, b0]).unsqueeze(0))[0]
                p1 = m(torch.stack([a1, b1]).unsqueeze(0))[0]
                d = float((p1 - p0).norm())
                if not (math.isfinite(d) and d > 0):
                    bad = True
                    break
                if d > renorm:
                    acc += math.log(d / eps)
                    nren += 1
                    p1 = p0 + (p1 - p0) * (eps / d)
                a0, b0 = b0, p0
                a1, b1 = b1, p1
            if bad:
                continue
            norms.append(float(p0.norm()))
            nrens.append(nren)
            if nren:
                rates.append(acc / steps)
    lam = float(np.mean(rates)) if rates else None
    lam_se = (float(np.std(rates, ddof=1) / math.sqrt(len(rates)))
              if len(rates) > 1 else None)
    return dict(lam_own=lam, lam_own_se=lam_se,
                n_renorm_med=float(np.median(nrens)) if nrens else None,
                n_seq_with_events=int(len(rates)), n=int(len(nrens)),
                norm_final=float(np.mean(norms)) if norms else None)


def main():
    t0 = time.time()

    def fmt(x, nd=5):
        return "—" if x is None else f"{x:+.{nd}f}"

    print("=" * 104)
    print("  T18 补充 · msK 地板消失的机制诊断（变收缩 vs 变好）")
    print("=" * 104)
    print(f"  {'环境':<10}{'臂':<9}{'norm t0':>9}{'norm t5':>9}{'norm t50':>10}"
          f"{'norm 末':>9}{'真值误差 t1':>12}{'t15':>8}{'λ₁(自身轨迹)':>15}{'重归一次数':>11}")
    res = {}
    for kind in ("reflect", "periodic"):
        dd = torch.load(os.path.join(CKPT, f"t18_{kind}_latents.pt"),
                        map_location="cpu", weights_only=True)
        ztr, zva = dd["ztr"], dd["zva"]
        mean = ztr.mean(dim=(0, 1)).to(DEV)
        std = ztr.std(dim=(0, 1)).clamp_min(1e-6).to(DEV)
        truth_norm = float(zva.norm(dim=-1).mean())
        for arm in ("single", "msK"):
            m, fn = load(kind, arm)
            R = rollout_stats(m, zva, mean, std)
            T = twin_divergence(m, zva, mean, std)
            res[f"{kind}_{arm}"] = dict(ckpt=fn, truth_norm=truth_norm, **R, **T)
            lo = T["lam_own"]
            print(f"  {kind:<10}{arm:<9}{R['norm_t0']:>9.2f}{R['norm_t5']:>9.2f}"
                  f"{R['norm_t50']:>10.2f}{R['norm_end']:>9.2f}"
                  f"{R['err_early']:>12.3f}{R['err_t15']:>8.3f}"
                  f"{fmt(lo):>15}"
                  f"{(T['n_renorm_med'] if T['n_renorm_med'] is not None else 0):>11.0f}")

    print("\n" + "-" * 104)
    print("  判读规则（写死）")
    print("-" * 104)
    print("  · norm 末 ≪ 真值范数 ⇒ 模型轨迹已脱离数据流形（塌缩）")
    print("  · msK 的 λ₁(自身轨迹) 明显更负 ⇒ 支持「变收缩」机制")
    print("  · 若 λ₁ 相近而真值误差明显更小 ⇒ 支持「变好」")
    print("  · ⚠ 若 msK 靠塌缩把 δ_∞ 压到 0，则**不能**声称「量化鲁棒性改善了」")

    print(f"\n  {'对照':<20}{'真值范数':>10}{'模型 norm 末':>13}{'末/t0':>8}"
          f"{'λ₁(自身)':>11}{'真值误差 t15':>13}")
    for kind in ("reflect", "periodic"):
        for lbl in ("single", "msK"):
            r = res[f"{kind}_{lbl}"]
            lo = r["lam_own"]
            print(f"  {kind+' '+lbl:<20}{r['truth_norm']:>10.2f}{r['norm_end']:>13.2f}"
                  f"{r['norm_end']/r['norm_t0']:>8.3f}"
                  f"{fmt(lo, 5):>11}"
                  f"{r['err_t15']:>13.3f}")

    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(dict(steps=STEPS, res=res, elapsed_s=round(time.time() - t0, 1)),
                  f, ensure_ascii=False, indent=2)
    print(f"\n  → {OUT}（{round(time.time()-t0,1)}s）")


if __name__ == "__main__":
    main()
