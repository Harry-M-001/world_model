"""
T2 · 潜空间动力学模型（在冻结 VAE 的潜空间上学「下一帧去哪里」）
=====================================================================
输入：最近 ctx 帧的潜向量 (z_{t-ctx+1..t})；输出：ẑ_{t+1}。
残差参数化 pred = z_t + net(...)，末层零初始化——这样模型起步就是
「匀速外推」这个强基线，学到的全是真正非线性的部分（碰壁反弹）。

三个刻意的设计选择：
  1. **在归一化潜空间里训练，在原始潜空间里评估**。
     训练用逐维标准化，避免少数大方差维度独占 MSE；但判据
     「单步潜向量预测余弦相似度」是在**原始** z 上算的，两者不能混。
  2. **VAE 全程冻结**，只用 μ（不用采样值）。否则每帧自带采样噪声，
     单步预测误差里会混进 VAE 自己的随机性，后面 T3 估 λ₁ 就脏了。
  3. **ctx 设为可配置参数，并设置 ctx=1 对照臂**。Moving MNIST 里速度可由两帧确定，
     ctx=2 时任务近乎线性外推——把这点量化出来，才知道 0.9 这个判据
     到底有多少信息量。

用法：
    python dyn.py                    # 训练 ctx=2（主线）+ ctx=1（对照）
    python dyn.py --ctx 2
"""
import argparse
import json
import os
import sys
import time

import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vae import CKPT, LOGS, LATENT, encode_sequences, load_vae  # noqa: E402
from guards import G  # noqa: E402

N_TRAIN_SEQ, VAL_SEQ = 12000, 128


class LatentDynamics(nn.Module):
    """ẑ_{t+1} = 匀速外推基线 + 网络学到的修正。

    基线：ctx≥2 时用 z_t + (z_t − z_{t-1})（两帧差分即速度）作为起点。
    初版没有这一项，让网络从零学「identity + 速度」，结果单步余弦只到
    0.871 < 0.9 —— 把已知的线性部分显式给出来，网络只需学碰壁这类非线性残差。
    """

    def __init__(self, latent=LATENT, ctx=2, hidden=512):
        super().__init__()
        self.ctx, self.latent = ctx, latent
        self.net = nn.Sequential(
            nn.Linear(latent * ctx, hidden), nn.SiLU(),
            nn.Linear(hidden, hidden), nn.SiLU(),
            nn.Linear(hidden, latent),
        )
        nn.init.zeros_(self.net[-1].weight)      # 起步 = 纯匀速外推
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, zc):
        """zc: (B, ctx, L) 已归一化 -> 归一化的 ẑ_{t+1}"""
        zt = zc[:, -1]
        base = zt
        if self.ctx >= 2:
            base = zt + (zt - zc[:, -2])         # 匀速外推
        return base + self.net(zc.flatten(1))


def make_pairs(z, ctx):
    """(N,T,L) -> xs (N,T-ctx,ctx,L), ys (N,T-ctx,L)"""
    N, T, L = z.shape
    xs = torch.stack([z[:, i - ctx:i] for i in range(ctx, T)], dim=1)
    ys = torch.stack([z[:, i] for i in range(ctx, T)], dim=1)
    return xs.contiguous(), ys.contiguous()


def get_latents(device, n_seq, seed, train, tag):
    """缓存文件名由 G.cache_key 统一生成，并对缓存做 G4 校验。

    注意：缓存键若只含 split 名，N_TRAIN_SEQ 改变后会命中旧缓存，
    导致数据量变化静默失效（训练对数仍为旧值），日志中无异常。
    缓存文件名必须包含 n_seq 与 seed，命中时还须比对文件内记录的元数据。
    """
    model = load_vae(device)
    params = dict(n_seq=n_seq, seed=seed)
    cache = os.path.join(CKPT, G.cache_key(f"latents_{tag}", params))
    G.cache_meta(cache, **params)
    return encode_sequences(model, n_seq, seed, train, device=device, cache=cache)


def train_one(ctx, lr=1e-3, epochs=600, batch=2048, device="cuda", verbose=True):
    torch.manual_seed(0)
    ztr = get_latents(device, N_TRAIN_SEQ, 0, True, "train")
    zva = get_latents(device, VAL_SEQ, 999, False, "val")
    mean = ztr.mean(dim=(0, 1), keepdim=False).to(device)          # (L,)
    std = ztr.std(dim=(0, 1), keepdim=False).clamp_min(1e-6).to(device)

    xtr, ytr = make_pairs(ztr, ctx)
    xva, yva = make_pairs(zva, ctx)
    xtr = xtr.reshape(-1, ctx, LATENT)
    ytr = ytr.reshape(-1, LATENT)
    xva = xva.reshape(-1, ctx, LATENT)
    yva = yva.reshape(-1, LATENT)

    xn_tr = ((xtr - mean.cpu()) / std.cpu()).to(device)   # 输入归一化：仅为优化条件好
    yn_tr = ytr.to(device)                                # 目标**保持原始尺度**
    n = xn_tr.shape[0]

    model = LatentDynamics(ctx=ctx).to(device)
    npar = sum(p.numel() for p in model.parameters())
    # G6a：判据在「原始」潜空间算余弦，损失就必须在原始潜空间最小化。
    # 初版在归一化空间算 MSE，判据在原始空间算余弦 —— 二者不等价
    # （归一化把权重挪向低方差维度），单步余弦卡在 0.874 上不去。
    # 注意这里比对的是**规范化空间标签**，不是散文。
    G.spaces(metric_space="raw_latent", loss_space="raw_latent",
             metric_desc="cos(z_pred, z_true)，在原始尺度的 z 上算",
             loss_desc="MSE(pred_raw, z_true)，pred_raw = pred_norm*std + mean")
    # G6b：反事实基线 —— 退化预测自己能不能过 0.9？
    # ① 拷贝上一帧 ② 常数（训练集均值）。这两个都过阈的话，判据就没有判别力。
    cos_prev = float(F.cosine_similarity(xva[:, -1], yva, dim=-1).mean())
    cos_mean = float(F.cosine_similarity(
        mean.cpu().expand_as(yva), yva, dim=-1).mean())
    print(f"  [G6b] 退化基线：拷贝上一帧 cos={cos_prev:.4f}  常数均值 cos={cos_mean:.4f}")
    G.counterfactual("单步潜余弦", threshold=0.9,
                     degenerate=max(cos_prev, cos_mean), direction="min")
    if verbose:
        print(f"  ctx={ctx}  训练对 {n}  参数量 {npar/1e3:.1f} K  "
              f"潜维度 {LATENT}  epochs={epochs}")
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    perm = torch.randperm(n)
    t0 = time.time()
    for ep in range(epochs):
        model.train()
        idx = torch.randperm(n, device=device)
        tot = 0.0
        for i in range(0, n, batch):
            b = idx[i:i + batch]
            opt.zero_grad(set_to_none=True)
            # 在**原始**潜空间算 MSE：cos = <a,b>/(|a||b|)，给定 |b| 时
            # 最小化 |a−b|² 等价于最大化 <a,b>，也就等价于最大化余弦。
            # 反过来，逐维归一化后的 MSE 会把权重挪向低方差维度，
            # 与「原始空间余弦 ≥ 0.9」这个判据**不对齐**——初版就栽在这里。
            pred_raw = model(xn_tr[b]) * std + mean
            loss = F.mse_loss(pred_raw, yn_tr[b])
            loss.backward()
            opt.step()
            tot += float(loss.detach()) * b.numel()
        sched.step()
        if verbose and (ep % 50 == 0 or ep == epochs - 1):
            cos, mse = single_step_scores(model, xva, yva, mean, std, device)
            print(f"    ep {ep:3d}  原始潜 MSE {tot/n:.4f}  "
                  f"val 单步 cos {cos:.5f}  val 潜 MSE {mse:.4f}  {time.time()-t0:.0f}s",
                  flush=True)

    cos, mse = single_step_scores(model, xva, yva, mean, std, device)
    ck = os.path.join(CKPT, f"dyn_mvmnist_ctx{ctx}.pt")
    torch.save(dict(state=model.state_dict(), ctx=ctx, latent=LATENT,
                    mean=mean, std=std, val_cos=cos, val_mse=mse), ck)
    if verbose:
        print(f"  ckpt -> {ck}   （{time.time()-t0:.0f}s）")
    return model, dict(ctx=ctx, cos=cos, mse=mse, npar=npar, pairs=n,
                       ckpt=os.path.basename(ck),
                       cos_degenerate_prev_frame=cos_prev,
                       cos_degenerate_mean=cos_mean)


@torch.no_grad()
def single_step_scores(model, xs_raw, ys_raw, mean, std, device="cuda", batch=4096):
    """在**原始**潜空间上算单步余弦相似度与 MSE（判据要求的口径）。"""
    model.eval()
    mean, std = mean.to(device), std.to(device)
    cos_all, mse_all = [], []
    xs = xs_raw.to(device)
    ys = ys_raw.to(device)
    for i in range(0, xs.shape[0], batch):
        xb, yb = xs[i:i + batch], ys[i:i + batch]
        pred = model((xb - mean) / std) * std + mean          # 回到原始潜空间
        cos_all.append(F.cosine_similarity(pred, yb, dim=-1))
        mse_all.append(((pred - yb) ** 2).mean(-1))
    cos = torch.cat(cos_all)
    mse = torch.cat(mse_all)
    return float(cos.mean()), float(mse.mean())


def load_dyn(ctx, device="cuda"):
    d = torch.load(os.path.join(CKPT, f"dyn_mvmnist_ctx{ctx}.pt"),
                   map_location=device, weights_only=True)
    m = LatentDynamics(latent=d["latent"], ctx=d["ctx"]).to(device)
    m.load_state_dict(d["state"])
    m.eval()
    return m, d["mean"].to(device), d["std"].to(device)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ctx", type=int, default=None, help="不填则跑 2 与 1 两档")
    ap.add_argument("--epochs", type=int, default=600)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    a = ap.parse_args()
    os.makedirs(LOGS, exist_ok=True)
    ctxs = [a.ctx] if a.ctx else [2, 1]
    print("=" * 70)
    print("  T2 · 潜空间动力学：单步预测（判据：原始潜空间余弦相似度 ≥ 0.9）")
    print("=" * 70)
    out = []
    for c in ctxs:
        _, r = train_one(c, epochs=a.epochs, device=a.device)
        out.append(r)
    print("-" * 70)
    for r in out:
        ok = "PASS" if r["cos"] >= 0.9 else "FAIL"
        print(f"  ctx={r['ctx']}  单步余弦 {r['cos']:.5f}  潜 MSE {r['mse']:.4f}  "
              f"({r['npar']/1e3:.1f}K 参数)  -> {ok}")
    print("=" * 70)
    with open(os.path.join(LOGS, "t2_dyn.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    return 0 if all(r["cos"] >= 0.9 for r in out if r["ctx"] == 2) else 1


if __name__ == "__main__":
    sys.exit(main())
