# -*- coding: utf-8 -*-
"""T2b 第三轮报告生成器：动作条件化（世界模型第一条判据下的路由实验）。

同时记录 off-by-one 勘误（rounds 1-2 全部重跑）。数字一律从 JSON 读。
"""
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "T2b_第三轮_动作条件化.md")


def load(tag):
    p = os.path.join(ROOT, "logs", f"t2b_route_{tag}.json")
    if not os.path.exists(p):
        return None
    return json.load(open(p, encoding="utf-8"))


def fmt(x, nd=5, sign=False):
    return "—" if x is None else (f"{x:+.{nd}f}" if sign else f"{x:.{nd}f}")


def main():
    A = []
    P = A.append
    arms = [("dense_h480_act", "dense_h480（无路由，容量对齐）"),
            ("moe_lb0.01_act", "moe（标签不可见，lb=0.01）"),
            ("moe_lb0_act", "moe（无负载均衡）"),
            ("oracle_lb0.01_act", "oracle（喂标签＝正对照）")]
    missing = [t for t, _ in arms if load(t) is None]
    if missing:
        print("缺 JSON：", missing)
        return 1
    D = {t: load(t) for t, _ in arms}

    P("# T2b 第三轮 · 动作条件化：满足世界模型第一条判据后，路由结论还成立吗\n")
    P("> 2026-09-20。动作 = 每步对**单个数字**施加 ±0.6 脉冲（digit × (ux,uy) ∈ {−1,0,1}²\\{0,0}），\n"
      "> 施力后按当步过程规则演化；动作分布与过程无关（不泄漏标签）。\n"
      "> 不用 T15 的场景级共享动作 —— T18 实测共享动作 + 速度 clip 破坏伽利略不变性 ⇒ 碰撞消失\n"
      "> （自检：scatter 碰撞/步 0.106 vs 无动作 0.155，比值 0.69，无塌缩）。\n"
      "> 数据用 round-1 过程对（匀速/重力/碰撞），以隔离「+动作」单轴。\n")

    P("## 0 前置勘误：off-by-one（影响 rounds 1–2 全部 cos 数字）\n")
    P("第三轮开工时的输入索引审计发现：`t2b_route` 的输入切片是 `[z_{t−2}, z_{t−1}]` 配目标 "
      "`z_{t+1}` —— 实际是**隔帧两步预测**，与全部文档（switch_eval 注释、round-1 报告的"
      "「输入对 [z_{t−1}, z_t]」）矛盾。**base-only 实测裁决**：代码口径的匀速外推天花板 "
      "cos 0.416（base 差一个速度步），文档口径 0.787 ⇒ 真 bug。")
    P("处置：修正输入为 `[z_{t−1}, z_t]`；rounds 1–2 全部 12 臂在修正口径下重跑"
      "（旧 JSON 备份于 `backup/t2b_json_prefix-20260920-1400`）。"
      "**全部定性结论存活**（见 §3 对照表）；T15/T18 管线审计确认无同病（它们的输入本就是 "
      "[t−1, t]）。\n")

    P("## 1 四臂结果（动作条件化，epochs=400）\n")
    P("| 臂 | 参数量 | 单步潜余弦 | 动作响应度 | 路由熵/logB | 三条判据 |")
    P("|---|---|---|---|---|---|")
    for tag, lbl in arms:
        d = D[tag]
        r = d.get("route")
        if r:
            crit = (f"I(R;P) 超出 {fmt(r['mi']['excess'],4,True)}（p={r['mi']['p_value']:.3f}）；"
                    f"切换 {fmt(r['switch']['hit_rate'],3)} vs {fmt(r['switch']['null_mean'],3)}"
                    f"（p={r['switch']['p_value']:.3f}）")
            ent = f"{fmt(r['entropy'],3)}/{fmt(math.log(d['config']['B']),3)}"
        else:
            crit, ent = "—", "—"
        P(f"| {lbl} | {d['n_params']:,} | {fmt(d['cos']['all'])} | "
          f"{fmt(d['act_response'],3)} | {ent} | {crit} |")
    P("")
    P(f"- **动作响应度全部 > 0.2**（翻转施加数字后预测的相对变化）⇒ 模型真被动作驱动 ——"
      f"本系统**满足世界模型第一条判据**（能被动作驱动），路由结论首次建立在合格系统上。")

    d_moe, d_or, d_dn = D["moe_lb0.01_act"], D["oracle_lb0.01_act"], D["dense_h480_act"]
    gain = d_or["cos"]["all"] - d_moe["cos"]["all"]
    loss = d_moe["cos"]["all"] - d_dn["cos"]["all"]
    m1, o1 = (load("moe_lb0.01"), load("oracle_lb0.01"))
    g1 = o1["cos"]["all"] - m1["cos"]["all"]
    l1 = m1["cos"]["all"] - load("dense_h480")["cos"]["all"]
    ratio = d_moe["route"]["mi"]["excess"] / d_or["route"]["mi"]["excess"]

    P("\n## 2 预注册裁决（与勘误后的 round-1 对照）\n")
    P(f"- **Q2 标签冗余**：oracle − moe = **{fmt(gain, 4, True)}**（round-1 勘误后 {fmt(g1, 4, True)}）"
      "⇒ 在动作驱动系统上依旧 ≈ 0。")
    P(f"- **Q3 净损失**：moe − dense = **{fmt(loss, 4, True)}**（round-1 勘误后 {fmt(l1, 4, True)}）"
      "—— 方向不变。")
    P(f"- **Q1 分工**：涌现臂 I(R;P) excess 为 oracle 的 **{100*ratio:.1f}%**"
      f"（{fmt(d_moe['route']['mi']['excess'],4)} vs {fmt(d_or['route']['mi']['excess'],4)}）；"
      f"oracle 三判据全显著（I +0.5502、切换 0.951 vs 0.856 p=0.000）⇒ 测量机器有鉴别力，"
      "涌现臂仍无可检出的分工信号。")
    P(f"- **top-2 对照**（moe_lb0.01_act_B8k2）：cos {fmt(load('moe_lb0.01_act_B8k2')['cos']['all'])}，"
      f"响应度 {fmt(load('moe_lb0.01_act_B8k2')['act_response'],3)} —— 局部改善但不闭合差距，与第二轮一致。")

    P("\n## 3 勘误后 rounds 1–2 汇总（修正口径重跑）\n")
    P("| 臂 | 旧口径（隔帧两步） | 修正口径 | round |")
    P("|---|---|---|---|")
    for tag, rnd in [("dense_h480", "R1"), ("moe_lb0.01", "R1"), ("moe_lb0", "R1"),
                     ("oracle_lb0.01", "R1"), ("dense_h480_dmp", "R2"),
                     ("moe_lb0.01_dmp", "R2"), ("moe_lb0_dmp", "R2"),
                     ("oracle_lb0.01_dmp", "R2")]:
        d = load(tag)
        old_bak = os.path.join(ROOT, "backup", "t2b_json_prefix-20260920-1400",
                               f"t2b_route_{tag}.json")
        old = json.load(open(old_bak, encoding="utf-8"))["cos"]["all"]
        P(f"| {tag} | {fmt(old)} | {fmt(d['cos']['all'])} | {rnd} |")
    g2 = (load("oracle_lb0.01_dmp")["cos"]["all"] - load("moe_lb0.01_dmp")["cos"]["all"])
    l2 = (load("moe_lb0.01_dmp")["cos"]["all"] - load("dense_h480_dmp")["cos"]["all"])
    m2e = load("moe_lb0.01_dmp")["route"]["mi"]["excess"]
    o2e = load("oracle_lb0.01_dmp")["route"]["mi"]["excess"]
    P("")
    P(f"- 阻尼域勘误后：Q2 {fmt(g2, 4, True)}、Q3 {fmt(l2, 4, True)}、"
      f"Q1 比 {100*m2e/o2e:.1f}% —— **三轮结论一致：路由不按物理过程分工、且分工无收益**，"
      "现在建立在满足第一条判据（动作驱动）的系统上。")
    P("")

    txt = "\n".join(A) + "\n"
    open(OUT, "w", encoding="utf-8").write(txt)
    print(f"→ {OUT}（{len(txt)} 字符）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
