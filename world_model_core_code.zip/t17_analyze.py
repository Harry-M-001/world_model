"""
T17 汇总 · 从 logs/t17_longhorizon*.json 计算失效视界 τ*(b) 与位宽门槛 b*

τ* 定义：d(t) **越过其最小值之后**、连续 k=5 步超过 (min d + margin) 的最小 t。
         （首版 bug：忘了从最小值之后算，d(0)=17 远大于 min+2 → 全部误报 0）

判据：
  · τ* = None  ⇔ 该档在 T_max 内保持（误差被吸收）
  · τ* 有限    ⇔ 误差从该步起持续累积
  · b* = 最小的 b 使 τ* = None（= 「闭环吸收」的位宽门槛）
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)


def fail_horizon(dmed, margin=2.0, k=5):
    arr = np.asarray(dmed, dtype=float)
    i0 = int(np.argmin(arr))
    run = 0
    for t in range(i0, len(arr)):
        run = run + 1 if arr[t] > arr[i0] + margin else 0
        if run >= k:
            return int(t - k + 1)
    return None


def slope(y):
    x = np.arange(len(y), dtype=float)
    A = np.vstack([x, np.ones_like(x)]).T
    (k, _), *_ = np.linalg.lstsq(A, np.asarray(y, float), rcond=None)
    return float(k)


def main():
    arms = {}
    for fn in ("t17_longhorizon.json", "t17_longhorizon_b6to16.json"):
        p = os.path.join(ROOT, "logs", fn)
        if os.path.exists(p):
            arms.update(json.load(open(p, encoding="utf-8"))["arms"])
    keys = sorted(arms, key=lambda k: (k.split("_")[0], arms[k]["bits"]))
    bits = sorted({arms[k]["bits"] for k in keys})
    names = []
    for k in keys:
        n = k.split("_")[0]
        if n not in names:
            names.append(n)

    print("=" * 92)
    print("  T17 汇总 · 闭环吸收的位宽门槛")
    print("=" * 92)
    T = len(arms[keys[0]]["d_median"]) - 1
    print(f"  T_max = {T} 步；阈值的 margin = 2.0、连续 k = 5 步\n")

    print(f"  {'臂':<9}" + "".join(f"{('b'+str(b)):>11}" for b in bits))
    tau = {}
    for nm in names:
        row = f"  {nm:<9}"
        for b in bits:
            k = f"{nm}_b{b}"
            if k not in arms:
                row += f"{'—':>11}"
                continue
            t = fail_horizon(arms[k]["d_median"])
            tau[k] = t
            row += f"{(str(t) if t is not None else '>T'):>11}"
        print(row)

    print(f"\n  {'臂':<9}" + "".join(f"{('b'+str(b)):>11}" for b in bits))
    for nm in names:
        row = f"  {nm:<9}"
        for b in bits:
            k = f"{nm}_b{b}"
            if k not in arms:
                row += f"{'—':>11}"
                continue
            I = np.array(arms[k]["ink_median"])
            row += f"{(I[-1]*100):>10.2f}%"
        print(row)
    print("  （最后一行：末步墨迹占比 —— 崩坏诊断）")

    # 位宽门槛
    print("\n" + "-" * 92)
    closed = {b: tau.get(f"closed_b{b}") for b in bits}
    ok = [b for b in bits if closed.get(b) is None]
    bad = [b for b in bits if closed.get(b) is not None]
    print(f"  闭环（R=1）：吸收的档位 {ok}    失效的档位 "
          f"{[(b, closed[b]) for b in bad]}")
    if ok:
        print(f"  **位宽门槛 b\\* = {min(ok)}** —— b ≥ b* 时闭环在 {T} 步内保持吸收；"
              f"b < b* 时误差从 τ* 起持续累积")
    print(f"\n  开环（R={T}）全部档位："
          f"{[(b, tau.get(f'open_b{b}')) for b in bits]}")

    # 漂移率汇总
    print("\n" + "-" * 92)
    S0 = min(20, T - 15)      # 固定段 [S0, T]：所有臂都已到位（τ_arrive ≤ 7），可公平对比
    print(f"  {'臂':<9}" + "".join(f"{('b'+str(b)):>11}" for b in bits))
    print(f"  稳态段固定为 [{S0},{T}]（保证各臂段长一致，避免段太短导致斜率不稳）")
    for nm in names:
        row = f"  {nm:<9}"
        for b in bits:
            k = f"{nm}_b{b}"
            if k not in arms:
                row += f"{'—':>11}"
                continue
            D = np.array(arms[k]["d_matrix"])
            row += f"{slope(np.median(D[:, S0:], axis=0)):>+11.4f}"
        print(row)
    print("  （到达后稳态段的漂移率 /步：|值| < 0.05 ≈ 平；> 0 = 在累积）")


if __name__ == "__main__":
    main()
