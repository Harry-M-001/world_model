"""
T6 · λ₁ 正则化：将学到的动力学扩张率作为可控设计参数。

版本说明：早期版本用幂迭代（单步 log‖Jv‖ 的均值）作为 λ̂₁ 代理，
    λ₁ 降至 −1.818（方向相反）；根因是单步局部量的均值不等于沿轨迹乘积的渐近指数。
本版改用 **Benettin 沿轨迹算法**（可微）：
    沿模型自身轨迹推 K 步，每步 v ← J(x_k)v 并归一化，λ̂₁ = (1/K)·Σ log‖J(x_k)v_k‖
    —— K 增大时收敛到渐近 λ₁，是 QR 口径的正确可微对应物。

三档目标加基线，验证 λ₁ 可由正则项控制：
    base（无正则，λ₁≈−0.28）、target 0.0453（=真值）、0.10、0.20
判据：达成的 QR λ₁ 随 target 单调上升且量级接近；单步精度代价被如实报出；
      对「匹配真值」的那一臂再跑量化扫描，检查 T_crash(b) 斜率是否 ≈ log2/λ₁(达成)。

产物 logs/t6_reg.json
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from lyap import qr_spectrum_map  # noqa: E402
from guards import G  # noqa: E402

DEV = "cuda" if torch.cuda.is_available() else "cpu"
SIG, RHO, BETA = 10.0, 28.0, 8.0 / 3.0
DT_FINE, SKIP = 0.005, 10
N_TRAJ, N_STEPS, TRANSIENT = 64, 400, 500
LAM_TRUE = 0.906 * SKIP * DT_FINE          # +0.0453 /步
K_TRAJ = 8                                 # Benettin 轨迹长度


def rhs(s):
    x, y, z = s
    return np.array([SIG * (y - x), x * (RHO - z) - y, x * y - BETA * z])


def rk4(s, dt):
    k1 = rhs(s)
    k2 = rhs(s + 0.5 * dt * k1)
    k3 = rhs(s + 0.5 * dt * k2)
    k4 = rhs(s + dt * k3)
    return s + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)


def gen_traj(s0, n):
    s = np.asarray(s0, dtype=np.float64).copy()
    for _ in range(TRANSIENT):
        s = rk4(s, DT_FINE)
    out = [s.copy()]
    for _ in range(n):
        for _ in range(SKIP):
            s = rk4(s, DT_FINE)
        out.append(s.copy())
    return np.array(out)


def quantize(z, bits, lo, hi):
    if bits >= 32:
        return z
    d = (hi - lo) / (2 ** bits - 1)
    return torch.clamp(torch.round(z / d), lo / d, hi / d) * d


class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(3, 64), nn.Tanh(),
                                 nn.Linear(64, 64), nn.Tanh(), nn.Linear(64, 3))

    def forward(self, x):
        return self.net(x)

    def jac(self, x):
        L = self.net
        W1, b1 = L[0].weight, L[0].bias
        W2, b2 = L[2].weight, L[2].bias
        W3 = L[4].weight
        a1 = torch.tanh(x @ W1.T + b1)
        a2 = torch.tanh(a1 @ W2.T + b2)
        D1, D2 = 1 - a1 ** 2, 1 - a2 ** 2
        return torch.einsum("oi,pi,ij,pj,jk->pko", W3, D2, W2, D1, W1)


def lam_hat_benettin(m, x0, K=K_TRAJ):
    """可微有限时间 Lyapunov 指数：沿模型自身轨迹推 K 步（Benettin 重正交化）。

    与 QR 口径一致：累积的是**沿轨迹乘积**的模长增长，不是单步量的均值。
    """
    v = torch.randn_like(x0)
    v = v / (v.norm(dim=1, keepdim=True) + 1e-12)
    x = x0
    tot = 0.0
    for _ in range(K):
        J = m.jac(x)
        w = torch.einsum("bij,bj->bi", J, v)
        n = w.norm(dim=1)
        tot = tot + torch.log(n + 1e-12)
        v = w / (n[:, None] + 1e-12)
        x = m(x)
    return tot.mean() / K


def qr_lam1(m):
    W1 = m.net[0].weight.detach().cpu().numpy().astype(np.float64)
    b1 = m.net[0].bias.detach().cpu().numpy().astype(np.float64)
    W2 = m.net[2].weight.detach().cpu().numpy().astype(np.float64)
    b2 = m.net[2].bias.detach().cpu().numpy().astype(np.float64)
    W3 = m.net[4].weight.detach().cpu().numpy().astype(np.float64)
    b3 = m.net[4].bias.detach().cpu().numpy().astype(np.float64)

    def f(s):
        s = np.asarray(s, dtype=np.float64)
        a1 = np.tanh(W1 @ s + b1)
        a2 = np.tanh(W2 @ a1 + b2)
        return W3 @ a2 + b3

    def jac(s):
        s = np.asarray(s, dtype=np.float64)
        a1 = np.tanh(W1 @ s + b1)
        a2 = np.tanh(W2 @ a1 + b2)
        return W3 @ np.diag(1 - a2 ** 2) @ W2 @ np.diag(1 - a1 ** 2) @ W1

    lam = qr_spectrum_map(f, jac, x0=np.array([1.0, 1.0, 20.0]),
                          n_steps=20000, discard=5000)
    return float(lam[0])


def tcrash_curve(m, ics, lo, hi, bits_list=(4, 6, 8, 12, 16, 32), steps=300, ds=1.0):
    out = []
    for bits in bits_list:
        ts = []
        for z0 in ics:
            with torch.no_grad():
                sr = torch.tensor(z0, dtype=torch.float32, device=DEV)
                sq = sr.clone()
                for t in range(steps):
                    if t > 0:
                        sr = m(sr)
                        sq = quantize(m(sq), bits, lo, hi)
                    if float((sq - sr).norm()) > ds:
                        ts.append(t)
                        break
        out.append(dict(bits=bits, med=float(np.median(ts)) if ts else None, n=len(ts)))
    return out


def fit_slope(rows):
    pts = [(r["bits"], r["med"]) for r in rows if r["med"] is not None and r["med"] > 0]
    if len(pts) < 3:
        return None
    b = np.array([p[0] for p in pts], float)
    t = np.array([p[1] for p in pts], float)
    A = np.vstack([b, np.ones_like(b)]).T
    (sl, ic), *_ = np.linalg.lstsq(A, t, rcond=None)
    pred = A @ np.array([sl, ic])
    r2 = 1 - ((t - pred) ** 2).sum() / ((t - t.mean()) ** 2).sum()
    return dict(slope=float(sl), intercept=float(ic), r2=float(r2), n=len(pts))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=400)
    ap.add_argument("--mu", type=float, default=2.0)
    ap.add_argument("--targets", default="0.0453,0.10,0.20")
    ap.add_argument("--n-ic", type=int, default=32)
    ap.add_argument("--sweep", action="store_true", help="对每臂跑量化扫描（较慢）")
    a = ap.parse_args()
    torch.manual_seed(0)
    rng = np.random.default_rng(0)

    D = np.stack([gen_traj(rng.uniform(-15, 15, 3), N_STEPS) for _ in range(N_TRAJ)])
    lo, hi = float(D.min()) - 1.0, float(D.max()) + 1.0
    Dt = torch.tensor(D, dtype=torch.float32, device=DEV)
    ii, tt = torch.meshgrid(torch.arange(N_TRAJ), torch.arange(N_STEPS), indexing="ij")
    ii, tt = ii.reshape(-1), tt.reshape(-1)
    ics = [D[i, 0] for i in range(a.n_ic)]
    print(f"数据 {D.shape}  λ_true={LAM_TRUE:+.5f}/步  K_traj={K_TRAJ}  μ={a.mu}")

    arms = [("base", None)] + [(f"t{t}", float(t)) for t in a.targets.split(",")]
    OUT = {"lam_true": LAM_TRUE, "config": dict(K=K_TRAJ, mu=a.mu, epochs=a.epochs),
           "arms": []}
    for tag, target in arms:
        torch.manual_seed(0)
        m = Net().to(DEV)
        opt = torch.optim.AdamW(m.parameters(), lr=2e-3, weight_decay=1e-5)
        sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=a.epochs)
        t0 = time.time()
        lam_hat_last = None
        for ep in range(a.epochs):
            perm = torch.randperm(ii.shape[0])[:N_STEPS * N_TRAJ]
            for i0 in range(0, perm.shape[0], 4096):
                sel = perm[i0:i0 + 4096]
                bi, ti = ii[sel].to(DEV), tt[sel].to(DEV)
                x = Dt[bi, ti]
                loss = F.mse_loss(m(x), Dt[bi, ti + 1])
                if target is not None:
                    samp = x[:64]
                    lam_hat = lam_hat_benettin(m, samp)
                    lam_hat_last = float(lam_hat)
                    loss = loss + a.mu * (lam_hat - target) ** 2
                opt.zero_grad(set_to_none=True)
                loss.backward()
                opt.step()
            sch.step()
        tr_s = time.time() - t0
        with torch.no_grad():
            val_mse = float(((m(Dt[:, :-1].reshape(-1, 3)) -
                              Dt[:, 1:].reshape(-1, 3)) ** 2).mean())
        lam1 = qr_lam1(m)
        row = dict(arm=tag, target=target, lam1=lam1, val_mse=val_mse,
                   train_s=round(tr_s, 1), lam_hat_train=lam_hat_last)
        if target is not None and target > 0:
            row["err_vs_target"] = (lam1 - target) / target
        if a.sweep:
            rows = tcrash_curve(m, ics, lo, hi)
            f1 = fit_slope(rows)
            row["tcrash"] = rows
            row["fit"] = f1
            if f1 and lam1 > 1e-3:
                pred = math.log(2) / lam1
                row["slope_pred"] = pred
                row["slope_err"] = abs(f1["slope"] - pred) / pred
        OUT["arms"].append(row)
        msg = f"  [{tag}] target={target}  QR λ₁={lam1:+.5f}  valMSE={val_mse:.4f}  {tr_s:.0f}s"
        if row.get("err_vs_target") is not None:
            msg += f"  与目标偏差 {row['err_vs_target']*100:+.0f}%"
        print(msg)
        if a.sweep and row.get("fit"):
            print(f"       T_crash 斜率 {row['fit']['slope']:.3f}（R²={row['fit']['r2']:.3f}）"
                  + (f"  预测 log2/λ₁={row['slope_pred']:.3f}  差 {row['slope_err']*100:.0f}%"
                     if row.get("slope_pred") else ""))

    print("\n" + "=" * 78)
    print("  汇总：λ₁ 是否可控？")
    print("=" * 78)
    print(f"  {'臂':<8} {'target':>9} {'QR λ₁':>10} {'偏差':>8} {'valMSE':>9} {'latent λ̂':>10}")
    for r in OUT["arms"]:
        tg = f"{r['target']:.4f}" if r["target"] is not None else "—"
        er = f"{r['err_vs_target']*100:+.0f}%" if r.get("err_vs_target") is not None else "—"
        lh = f"{r['lam_hat_train']:+.4f}" if r.get("lam_hat_train") is not None else "—"
        print(f"  {r['arm']:<8} {tg:>9} {r['lam1']:>+10.5f} {er:>8} {r['val_mse']:>9.4f} {lh:>10}")
    reg = [r for r in OUT["arms"] if r["target"] is not None]
    if len(reg) >= 2:
        mono = all(reg[i]["lam1"] < reg[i + 1]["lam1"] for i in range(len(reg) - 1))
        print(f"\n  λ₁ 随 target 单调上升：{'是 ✓' if mono else '否 ✗'}")
        print(f"  base 的 λ₁ = {OUT['arms'][0]['lam1']:+.5f}（无正则的收缩倾向）")
        best = min(reg, key=lambda r: abs(r.get("err_vs_target", 9e9)))
        print(f"  最接近目标的臂：{best['arm']}（target {best['target']:.4f}，"
              f"达成 {best['lam1']:+.5f}，偏差 {best['err_vs_target']*100:+.0f}%）")
        OUT["monotone"] = bool(mono)
        OUT["best_arm"] = best["arm"]

    with open(os.path.join(ROOT, "logs", "t6_reg.json"), "w", encoding="utf-8") as f:
        json.dump(OUT, f, ensure_ascii=False, indent=2)
    print(f"\n-> logs/t6_reg.json")


if __name__ == "__main__":
    sys.exit(main())
