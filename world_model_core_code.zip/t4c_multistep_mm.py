"""
T5 前哨 · multistep 训练机制搬回 Moving MNIST。

洛伦兹侧的结论：单步 MSE 学不到正确的多步行为；multistep（K 步展开 loss）
让模型的多步保真度显著提升。这里验证它是否跨任务成立：
  同一数据（gray_s3 灰度、速度 {±1..±3}）、同一网络、同一轮数，
  唯一差异是训练目标：单步 MSE vs K=5 展开损失。
  指标：多步 rollout 的 T_crash（潜 cos<0.9 与 像素 5×VAE 地板）。

预测：multistep 模型的 T_crash 更长（T2 的单步模型在 18 步内早就崩了）。

产物 logs/t4c_multistep_mm.json
"""
import json
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from vae import LATENT, CKPT, LOGS, load_vae  # noqa: E402
from dyn import LatentDynamics, single_step_scores  # noqa: E402
from guards import G  # noqa: E402

DEV = "cuda" if torch.cuda.is_available() else "cpu"
H = W = 64
CTX, K, EPOCHS, BATCH = 2, 5, 600, 2048


def rollout(m, z, mean, std, vae, steps=18, factor=5.0):
    """真值前 CTX 帧出发的自回归 rollout。z: (20,64) 真值潜轨迹。"""
    a, b = z[0].to(DEV), z[1].to(DEV)
    an = (a - mean) / std
    bn = (b - mean) / std
    cos_list, preds = [], []
    cur_a, cur_b = an, bn
    for t in range(steps):
        with torch.no_grad():
            pn = m(torch.stack([cur_a, cur_b])[None])[0]
        raw = (pn * std + mean).cpu()
        preds.append(raw)
        cos_list.append(float(F.cosine_similarity(raw, z[CTX + t], dim=-1)))
        cur_a, cur_b = cur_b, pn
        cur_a = cur_a.clamp(-8, 8)
        cur_b = cur_b.clamp(-8, 8)
    P = torch.stack(preds)                                   # (steps, 64)
    t_lat = next((i + 1 for i in range(steps) if cos_list[i] < 0.9), None)
    gti = z[CTX:CTX + steps]                                  # 潜真值（像素判据另用图像）
    px = None
    return dict(cos=cos_list, t_latent=t_lat, P=P)


def main():
    torch.manual_seed(0)
    ztr = torch.load(os.path.join(CKPT, "latents_gray_s3__n_seq12000_seed0.pt"),
                     map_location="cpu", weights_only=True)["z"]
    zva = torch.load(os.path.join(CKPT, "latents_gray_s3__n_seq128_seed999.pt"),
                     map_location="cpu", weights_only=True)["z"]
    mean = ztr.mean(dim=(0, 1)).to(DEV)
    std = ztr.std(dim=(0, 1)).clamp_min(1e-6).to(DEV)
    vae = load_vae()
    sd = torch.load(os.path.join(CKPT, "vae_gray_s3.pt"),
                    map_location=DEV, weights_only=True)
    vae.load_state_dict(sd["state"])
    print(f"数据：train {tuple(ztr.shape)}  val {tuple(zva.shape)}  "
          f"ctx={CTX}  K={K}  epochs={EPOCHS}")

    # 单步基线（已有 ckpt）
    base = LatentDynamics(ctx=CTX).to(DEV)
    sd = torch.load(os.path.join(CKPT, "dyn_gray_s3_ctx2.pt"),
                    map_location=DEV, weights_only=True)
    base.load_state_dict(sd["state"])
    base_mean, base_std = sd["mean"].to(DEV), sd["std"].to(DEV)
    print(f"  单步基线已载入（val cos {json.load(open(os.path.join(LOGS,'t2_variant_gray_s3.json'),encoding='utf-8'))['val_cos']:.5f}）")

    # 多步模型（ckpt 已存则跳过训练）
    m = LatentDynamics(ctx=CTX).to(DEV)
    ms_ckpt = os.path.join(CKPT, "dyn_gray_s3_ms5_ctx2.pt")
    if os.path.exists(ms_ckpt):
        sd = torch.load(ms_ckpt, map_location=DEV, weights_only=True)
        m.load_state_dict(sd["state"])
        print("  multistep ckpt 已存在，跳过训练")
    else:
        opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=1e-4)
        sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
        n_tr = ztr.shape[0]
        t_max = ztr.shape[1] - K                  # 一步的 t 范围 [CTX, t_max)
        t0 = time.time()
        for ep in range(EPOCHS):
            for _ in range(105):                   # 每轮 105 个 batch（与单步基线同口径）
                ti = torch.randint(CTX, t_max, (BATCH,), device=DEV)
                bi = torch.randint(0, n_tr, (BATCH,), device=DEV)
                bi, ti = bi.cpu(), ti.cpu()
                ca = ztr[bi, ti - CTX].to(DEV)            # (B, 64)
                cb = ztr[bi, ti - CTX + 1].to(DEV)        # (B, 64)
                tgt = torch.stack([ztr[bi, ti + k].to(DEV) for k in range(K)], 1)
                opt.zero_grad(set_to_none=True)
                loss = 0.0
                for k in range(K):
                    pn = m(torch.stack([ca, cb], dim=1))
                    raw = pn * std + mean
                    loss = loss + F.mse_loss(raw, tgt[:, k])
                    ca, cb = cb, pn
                    ca = ca.clamp(-8, 8)
                    cb = cb.clamp(-8, 8)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(m.parameters(), 5.0)
                opt.step()
            sch.step()
        torch.save(dict(state=m.state_dict(), ctx=CTX, latent=LATENT,
                        mean=mean, std=std, cfg=dict(K=K, tag="gray_s3_ms5")),
                   ms_ckpt)
        print(f"  multistep 训练完成 ({time.time()-t0:.0f}s)")

    # ---------------------------------------------------------- 评估
    OUT = {"config": dict(CTX=CTX, K=K, EPOCHS=EPOCHS, n_val=64), "arms": []}
    n_val = 64
    for name, model, mean_, std_ in (("single", base, base_mean, base_std),
                                     ("multistep", m, mean, std)):
        with torch.no_grad():
            xv = torch.stack([zva[:, i - CTX:i] for i in range(CTX, 20)], 1
                             ).reshape(-1, CTX, LATENT).to(DEV)
            yv = torch.stack([zva[:, i] for i in range(CTX, 20)], 1
                             ).reshape(-1, LATENT).to(DEV)
            pr = model(xv) * std_ + mean_
        cos1 = float(F.cosine_similarity(pr, yv, dim=-1).mean())
        mse1 = float(((pr - yv) ** 2).mean())
        rolls = [rollout(model, zva[i], mean_, std_, vae) for i in range(n_val)]
        t_lats = [r["t_latent"] for r in rolls if r["t_latent"] is not None]
        cos_mat = np.array([r["cos"] for r in rolls])
        # 像素口径
        imgs = torch.stack([torch.from_numpy(
            __import__("variant2").VariantMNIST(
                n_val, 999, False, speeds=(1, 2, 3), gamma=0.0)[i].numpy())
            for i in range(n_val)]).float() / 255.0          # (64,20,64,64)
        P = torch.stack([r["P"] for r in rolls])              # (64,18,64)
        with torch.no_grad():
            px = torch.sigmoid(vae.decode(P.to(DEV).reshape(-1, LATENT))
                               ).view(n_val, 18, H, W).cpu()
        bce = F.binary_cross_entropy(px.clamp(1e-6, 1 - 1e-6), imgs[:, CTX:],
                                     reduction="none").flatten(2).mean(-1)  # (64,18)
        with torch.no_grad():
            zt = zva[:n_val].to(DEV)
            base_px = torch.sigmoid(vae.decode(zt[:, CTX:].reshape(-1, LATENT))
                                    ).view(n_val, 18, H, W).cpu()
        floor = float(F.binary_cross_entropy(
            base_px.clamp(1e-6, 1 - 1e-6), imgs[:, CTX:],
            reduction="none").flatten(2).mean(-1).mean())
        ratio = (bce.mean(0) / floor)
        t_pix = next((i + 1 for i in range(18) if ratio[i] > 5.0), None)
        row = dict(arm=name, single_cos=cos1, single_mse=mse1,
                   t_latent_med=float(np.median(t_lats)) if t_lats else None,
                   t_latent_iqr=([float(np.percentile(t_lats, 25)),
                                  float(np.percentile(t_lats, 75))] if t_lats else None),
                   n_crash=len(t_lats), cos_curve=[float(x) for x in cos_mat.mean(0)],
                   floor=floor, pixel_ratio=[float(x) for x in ratio],
                   t_pixel=t_pix)
        OUT["arms"].append(row)
        print(f"\n  [{name}]  单步 val cos {cos1:.5f}  MSE {mse1:.4f}")
        print(f"    潜 T_crash：中位 {row['t_latent_med']}  "
              f"IQR {row['t_latent_iqr']}  ({row['n_crash']}/{n_val} 崩)")
        print(f"    像素 T_crash（5×地板 {floor:.4f}）：第 {t_pix} 步  "
              f"比率曲线前 5 步 {[round(float(x), 2) for x in ratio[:5]]}")

    G.spaces("raw_latent", "raw_latent")
    a1, a2 = OUT["arms"]
    print("\n" + "=" * 78)
    print("  对照结论")
    print("=" * 78)
    print(f"  潜 T_crash 中位：单步 {a1['t_latent_med']} vs multistep {a2['t_latent_med']}")
    print(f"  像素 T_crash：   单步 {a1['t_pixel']} vs multistep {a2['t_pixel']}")
    print(f"  单步精度：       {a1['single_cos']:.5f} vs {a2['single_cos']:.5f}")
    verdict = (f"multistep 的 T_crash {'更长 ✓' if (a2['t_latent_med'] or 0) > (a1['t_latent_med'] or 0) else '未变长 ✗'}")
    print(f"  → {verdict}")
    OUT["verdict"] = verdict
    p = os.path.join(ROOT, "logs", "t4c_multistep_mm.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(OUT, f, ensure_ascii=False, indent=2)
    print(f"\n-> {p}")


if __name__ == "__main__":
    sys.exit(main())
