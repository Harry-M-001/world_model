"""
可配置生成器 + 变体训练（T2 的下一代数据）。

四项配置改动：
  1. 像素表示取「更好」的：灰度（官方一致，且实测潜 MSE 改善 7.6%）
  2. 速度范围取「更宽」的：{±1..±4}（覆盖官方实测到的 1–4，官方主峰 3）
  3. 阻尼 γ 作为可调参数（为「阻尼帮助低精度」的扫描实验留好口子）
  4. test split：seed 777 的 256 条，落盘，永不参与任何决策

用法：
  python variant2.py --speeds 1,2,3,4 --gamma 0.0 --tag gray_s4
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from vae import LATENT, VAE, CKPT, LOGS, kl_per_dim, rec_term          # noqa: E402
from dyn import LatentDynamics, make_pairs, single_step_scores          # noqa: E402
from guards import G                                                    # noqa: E402
from mvmnist import DIGIT, H, N_DIGIT, T_FRAMES, W, MNIST_RAW           # noqa: E402

DEV = "cuda" if torch.cuda.is_available() else "cpu"


def read_idx_images(path):
    with open(path, "rb") as f:
        assert int.from_bytes(f.read(4), "big") == 2051
        n = int.from_bytes(f.read(4), "big")
        r = int.from_bytes(f.read(4), "big")
        c = int.from_bytes(f.read(4), "big")
        return np.frombuffer(f.read(), np.uint8).reshape(n, r, c)


_raw = os.path.join(MNIST_RAW, "MNIST", "raw")
GRAY = {True: read_idx_images(os.path.join(_raw, "train-images-idx3-ubyte")),
        False: read_idx_images(os.path.join(_raw, "t10k-images-idx3-ubyte"))}


def make_seq_gray(digits, rng, speeds, gamma, n_frames=T_FRAMES, n_digit=N_DIGIT):
    """运动规则与 mvmnist.make_sequence 一致，三处可调：速度集合、阻尼 γ、灰度贴图。

    γ = 0：完全弹性（守恒，真值 λ₁ = 0）；位置保持整数（与原二值生成器逐位一致）
    γ > 0：每步 v ← (1−γ)v（真实耗散，真值 λ₁ = log(1−γ) < 0）；位置转浮点、取整贴图
    """
    frames = np.zeros((n_frames, H, W), dtype=np.uint8)
    lim, limy = W - DIGIT, H - DIGIT
    order = rng.permutation(len(digits))[:n_digit]
    for k in order:
        d = digits[k]
        xf = float(rng.integers(0, lim + 1))
        yf = float(rng.integers(0, limy + 1))
        vx = float(int(rng.choice(speeds)) * int(rng.choice((-1, 1))))
        vy = float(int(rng.choice(speeds)) * int(rng.choice((-1, 1))))
        for t in range(n_frames):
            xi = int(min(max(round(xf), 0), lim))
            yi = int(min(max(round(yf), 0), limy))
            patch = frames[t, yi:yi + DIGIT, xi:xi + DIGIT]
            np.maximum(patch, d, out=patch)
            vx *= (1.0 - gamma)
            vy *= (1.0 - gamma)
            xf += vx
            yf += vy
            if xf < 0 or xf > lim:
                vx = -vx
                xf = min(max(xf, 0.0), float(lim))
            if yf < 0 or yf > limy:
                vy = -vy
                yf = min(max(yf, 0.0), float(limy))
    return frames


class VariantMNIST(Dataset):
    def __init__(self, n, seed=0, train=True, speeds=(1, 2, 3, 4), gamma=0.0):
        self.n, self.seed = int(n), int(seed)
        self.speeds, self.gamma = tuple(speeds), float(gamma)
        self.digits = GRAY[train]

    def __len__(self):
        return self.n

    def __getitem__(self, i):
        rng = np.random.default_rng((self.seed * 1_000_003 + int(i)) % (2 ** 32))
        return torch.from_numpy(make_seq_gray(self.digits, rng, self.speeds, self.gamma))


def to_img_g(seq):
    return seq.float().unsqueeze(2) / 255.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--speeds", default="1,2,3,4")
    ap.add_argument("--gamma", type=float, default=0.0)
    ap.add_argument("--tag", default="gray_s4")
    ap.add_argument("--n-train", type=int, default=4000)
    ap.add_argument("--n-dyn", type=int, default=12000)
    ap.add_argument("--vae-epochs", type=int, default=40)
    ap.add_argument("--dyn-epochs", type=int, default=600)
    a = ap.parse_args()
    speeds = tuple(int(x) for x in a.speeds.split(","))
    cfg = dict(speeds=list(speeds), gamma=a.gamma, tag=a.tag, n_train=a.n_train,
               n_dyn=a.n_dyn, vae_epochs=a.vae_epochs, dyn_epochs=a.dyn_epochs)
    print(f"配置 {cfg}")

    trl = DataLoader(VariantMNIST(a.n_train, 0, True, speeds, a.gamma),
                     batch_size=32, shuffle=True, num_workers=0, drop_last=True)
    val = DataLoader(VariantMNIST(128, 999, False, speeds, a.gamma),
                     batch_size=32, shuffle=False, num_workers=0)
    model = VAE().to(DEV)
    xb = to_img_g(next(iter(trl))).flatten(0, 1)
    G.input_stats(xb, f"VAE 输入[{a.tag}]", kind="any", expect_shape=(None, 1, H, W))
    _l = model(xb.to(DEV))[0]
    G.loss_reduction(float(rec_term(_l, xb.to(DEV)).detach()),
                     float(F.binary_cross_entropy_with_logits(
                         _l, xb.to(DEV), reduction="sum").detach() / xb.size(0)),
                     "重建项")
    opt = torch.optim.AdamW(model.parameters(), lr=2e-3, weight_decay=1e-5)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=a.vae_epochs)
    t0 = time.time()
    for ep in range(a.vae_epochs):
        model.train()
        beta = min(1.0, (ep + 1) / 5)
        for seq in trl:
            x = to_img_g(seq).flatten(0, 1).to(DEV)
            logits, mu, lv, z = model(x)
            loss = rec_term(logits, x) + beta * kl_per_dim(mu, lv).sum(1).mean()
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
        sch.step()
    ck = os.path.join(CKPT, f"vae_{a.tag}.pt")
    torch.save(dict(state=model.state_dict(), latent=LATENT, cfg=cfg), ck)
    print(f"  VAE -> {ck}  ({time.time()-t0:.0f}s)")

    def encode(n_seq, seed, train, tag):
        c = os.path.join(CKPT, f"latents_{tag}__n_seq{n_seq}_seed{seed}.pt")
        if os.path.exists(c):
            return torch.load(c, map_location="cpu", weights_only=True)["z"]
        ds = VariantMNIST(n_seq, seed, train, speeds, a.gamma)
        out = []
        model.eval()
        with torch.no_grad():
            for i in range(0, n_seq, 64):
                idx = list(range(i, min(i + 64, n_seq)))
                s = torch.stack([ds[j] for j in idx])
                z = model.encode_det(to_img_g(s).flatten(0, 1).to(DEV))
                out.append(z.view(len(idx), -1, LATENT).float().cpu())
        z = torch.cat(out)
        torch.save(dict(z=z, n_seq=n_seq, seed=seed), c)
        return z

    ztr = encode(a.n_dyn, 0, True, a.tag)
    zva = encode(128, 999, False, a.tag)
    mean = ztr.mean(dim=(0, 1)).to(DEV)
    std = ztr.std(dim=(0, 1)).clamp_min(1e-6).to(DEV)

    ctx = 2
    xt, yt = make_pairs(ztr, ctx)
    xv, yv = make_pairs(zva, ctx)
    xt, yt = xt.reshape(-1, ctx, LATENT), yt.reshape(-1, LATENT)
    xv, yv = xv.reshape(-1, ctx, LATENT), yv.reshape(-1, LATENT)
    xn = ((xt - mean.cpu()) / std.cpu()).to(DEV)
    yn = yt.to(DEV)
    m = LatentDynamics(ctx=ctx).to(DEV)
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=1e-4)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=a.dyn_epochs)
    n = xn.shape[0]
    t0 = time.time()
    for ep in range(a.dyn_epochs):
        idx = torch.randperm(n, device=DEV)
        for i in range(0, n, 2048):
            b = idx[i:i + 2048]
            opt.zero_grad(set_to_none=True)
            F.mse_loss(m(xn[b]) * std + mean, yn[b]).backward()
            opt.step()
        sch.step()
    cos, mse = single_step_scores(m, xv, yv, mean, std, DEV)
    tr_cos, _ = single_step_scores(m, xt, yt, mean, std, DEV)
    torch.save(dict(state=m.state_dict(), ctx=ctx, latent=LATENT,
                    mean=mean, std=std, cfg=cfg),
               os.path.join(CKPT, f"dyn_{a.tag}_ctx2.pt"))
    cos_prev = float(F.cosine_similarity(xv[:, -1], yv, dim=-1).mean())
    G.spaces("raw_latent", "raw_latent")
    G.counterfactual(f"单步潜余弦[{a.tag}]", threshold=0.9, degenerate=cos_prev,
                     direction="min")
    verdict = "PASS" if cos >= 0.9 else "FAIL"
    print(f"\n  [{a.tag}] speeds={speeds} γ={a.gamma}  单步潜余弦 val {cos:.5f}  "
          f"train {tr_cos:.5f}  潜 MSE {mse:.4f}  退化基线 {cos_prev:.4f}")
    print(f"  判定：{verdict}（阈值 0.9）  （dyn {time.time()-t0:.0f}s）")
    with open(os.path.join(LOGS, f"t2_variant_{a.tag}.json"), "w", encoding="utf-8") as f:
        json.dump(dict(config=cfg, val_cos=cos, train_cos=tr_cos, val_mse=mse,
                       degenerate_prev=cos_prev, verdict=verdict), f,
                  ensure_ascii=False, indent=2)
    print(f"-> logs/t2_variant_{a.tag}.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
