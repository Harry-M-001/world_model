"""
T15 的理论前提验证：**动作条件化不改变真值 λ₁（仍为 0）**。

真值映射（单个数字，状态 s=(x,y,vx,vy)，动作 a=(ax,ay)）：
    v' = clip(v + a, −vmax, +vmax)      （动作只改变速度）
    x' = x + v'                          （然后碰壁反射）
未饱和时 Jacobian = [[1, 1], [0, 1]]（按 (x,vx) 分块）→ 特征值 {1,1} → logλ = 0；
饱和（clip 生效）时 ∂v'/∂v = 0 → [[1,0],[0,0]] → 特征值 {1,0} → λ₁ 仍为 0（有一个恒为 1）。
**动作 a 不进入 Jacobian**（f 显式依赖 a，但 ∂f/∂s 里 a 是常数）→ 动作条件化不改变 λ₁。

注意：单步 log σ_max([[1,1],[0,1]]) = log((3+√5)/2) ≈ 0.962 ≠ 0，
但这是**代数增长**（J^T = [[1,T],[0,1]]，‖J^T‖ ~ T）→ 渐近 λ₁ = (1/T)log T → 0。
所以本验证必须跑足够长的 T 并观察 log‖Φ‖ 对 T 呈**对数**而非线性。

产物 logs/t15_truth.json
"""
import json
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from lyap import qr_spectrum_map  # noqa: E402

V_MAX, A_MAX = 3.0, 1.0
LIM = 36.0


def step(s, a, lim=LIM):
    x, y, vx, vy = s
    vx = float(np.clip(vx + a[0], -V_MAX, V_MAX))
    vy = float(np.clip(vy + a[1], -V_MAX, V_MAX))
    x = x + vx
    y = y + vy
    if x < 0 or x > lim:
        vx = -vx
        x = min(max(x, 0.0), lim)
    if y < 0 or y > lim:
        vy = -vy
        y = min(max(y, 0.0), lim)
    return np.array([x, y, vx, vy])


def jac(s, a, lim=LIM):
    """解析雅可比：d(x,y,vx,vy)'/d(x,y,vx,vy)。"""
    x, y, vx, vy = s
    J = np.zeros((4, 4))
    # v' 对 v 的偏导：未饱和为 1，饱和为 0（分段线性，几乎处处可微）
    dvx = 1.0 if abs(vx + a[0]) < V_MAX else 0.0
    dvy = 1.0 if abs(vy + a[1]) < V_MAX else 0.0
    # x' = x + v'（若未碰壁）
    x2 = x + float(np.clip(vx + a[0], -V_MAX, V_MAX))
    y2 = y + float(np.clip(vy + a[1], -V_MAX, V_MAX))
    hit_x = (x2 < 0) or (x2 > lim)
    hit_y = (y2 < 0) or (y2 > lim)
    sign_x = -1.0 if hit_x else 1.0
    sign_y = -1.0 if hit_y else 1.0
    J[0, 0] = 1.0            # x' 对 x
    J[0, 2] = sign_x * dvx   # x' 对 vx
    J[1, 1] = 1.0
    J[1, 3] = sign_y * dvy
    J[2, 2] = sign_x * dvx   # v' 对 v
    J[3, 3] = sign_y * dvy
    return J


def main():
    rng = np.random.default_rng(0)
    print("=" * 92)
    print("  T15 理论前提：动作条件化的真值 λ₁（应为 0，且与动作序列无关）")
    print("=" * 92)

    # ① 解析：单点 Jacobian 的特征值
    s0 = np.array([10.0, 10.0, 2.0, -1.0])
    for a in ([0, 0], [1, 1], [-1, -1], [1, 0]):
        J = jac(s0, a)
        ev = np.linalg.eigvals(J)
        print(f"  a={a}  特征值 {np.round(ev, 6).tolist()}  "
              f"max|λ| {max(abs(ev)):.6f}  log 谱半径 {math.log(max(abs(ev))):+.6f}")

    # ② QR 沿真实动作序列测 λ₁
    print(f"\n  {'动作序列':<26} {'λ₁ (QR)':>12} {'谱前 4':>34}")
    rows = []
    for name, gen in (
            ("全是 (0,0)（无动作）", lambda: np.zeros(2)),
            ("全是 (+1,+1)", lambda: np.array([1.0, 1.0])),
            ("全是 (−1,−1)", lambda: np.array([-1.0, -1.0])),
            ("随机 ∈{−1,0,+1}²", lambda: rng.integers(-1, 2, 2).astype(float))):
        acts = [gen() for _ in range(40000)]

        # qr_spectrum_map 的顺序是「先 jac(x)、再 f(x)」，且两者用**同一个 x**
        # → 必须让 jac 与 f 取到同一个动作索引（jac 取 idx，f 取 idx 后递增）
        idx = [0]

        def j(s):
            return jac(s, acts[idx[0] % len(acts)])

        def f(s):
            r = step(s, acts[idx[0] % len(acts)])
            idx[0] += 1
            return r

        lam = qr_spectrum_map(f, j, x0=np.array([10.0, 10.0, 2.0, -1.0]),
                              n_steps=20000, discard=2000)
        rows.append(dict(actions=name, lam=list(map(float, lam))))
        print(f"  {name:<26} {lam[0]:>+12.5f}   "
              + np.array2string(lam[:4], precision=5, floatmode="fixed"))

    # ③ 代数增长检验：‖Φ(T)‖ 对 T 呈对数而非线性
    print(f"\n  代数增长检验（λ₁ 应 → 0，因为 ‖J^T‖ ~ T）：")
    print(f"  {'T':>7} {'(1/T)·log‖Φ(T)‖':>18} {'是否随 T 下降':>14}")
    s = np.array([10.0, 10.0, 2.0, -1.0])
    M = np.eye(4)
    marks = {200, 1000, 5000, 20000}
    for T in range(1, 20001):
        M = jac(s, np.array([0.0, 0.0])) @ M
        s = step(s, np.array([0.0, 0.0]))
        if T in marks:
            rate = math.log(np.linalg.norm(M, 2)) / T
            print(f"  {T:>7} {rate:>18.6f}   " +
                  ("是（→0）" if T > 1000 else "—"))

    out = {"eigen_at_s0": [list(map(float, np.linalg.eigvals(jac(s0, a))))
                           for a in ([0, 0], [1, 1], [-1, -1])],
           "qr_rows": rows}
    with open(os.path.join(ROOT, "logs", "t15_truth.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"\n-> logs/t15_truth.json")


if __name__ == "__main__":
    main()
