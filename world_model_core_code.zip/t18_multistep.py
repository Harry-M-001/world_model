"""
T18 补充 · multistep 训练对照 —— 检验「不连续动力学没有有限 b*」是不是「训练方式不够」的假象

背景（T18 主结果）：
  periodic（环绕边界、真值 λ₁=+0.350）的 δ_∞ 在**所有位宽**上饱和在 ~1.07–1.12（连 b=32 都不降）
  ⇒ b* = None。而 reflect（反射边界、真值 λ₁=+0.051）b* = 12、δ_∞ → 6e-6。
  但 periodic 的单步 cos 只有 **0.70734**（退化基线 0.6853，真实余量 +0.022）。
  ⇒ **替代解释**：不是「动力学没有解」，而是**我们的训练方式不够**。
     T4b 的经验正是：multistep 训练能显著改善多步保真度（洛伦兹上把 λ₁ 从 −0.28 推到 ≈0）。

设计（单变量 = 训练目标，其余全部相同）：
  · 数据：复用 `ckpt/t18_{kind}_latents.pt`（同一份 ztr/zva，不重新生成）
  · 网络：dyn.LatentDynamics(ctx=2)，同 lr/batch/epochs/seed
  · 唯一差异：
         single : MSE(f(z_{t-1}, z_t), z_{t+1})
         msK    : Σ_{k=1..K} MSE(f^k(z_{t-1}, z_t), z_{t+k})      均匀权重（与 T4b/T4c 一致）
  · 判据：单步 cos / **开环 rollout 对真值的相对误差**（多步保真度的直接度量）/
          δ_∞(b) / b* / T_crash（同 BITS、同 lo,hi、同 δ*、同 IC）/ λ₁（沿真值数据轨迹）
  · 对照臂：**本次运行为单步基线重新计算全部指标**（同代码、同一时刻），
            并与日志里的 ep2000 值核对 ⇒ 排除「静默用错版本」

守卫：
  G-ms1  K=1 时损失必须与单步公式**逐位一致**（两条独立路径各跑 1 步，比对全部参数）
  G-ms2  floor 判据按**维度**：L 维潜空间首步注入 rms = √L·Δ/√12
  G-ms3  单步基线模型的 cos 必须复现日志 ep2000 值（否则拒绝比较，除非 --allow-version-mismatch）
  G-ms4  打印并记录输入潜向量、参照模型与产出模型三者的 mtime（防止静默使用旧版本文件）
  G-ms5  量化必须真的改变状态（b=3 与 b=32 至少一个指标差 > 1e-4）

已知口径差异：K>1 时每个 epoch 可用的 (i,t) 对更少（T=20、K=5 ⇒ 13/17 = 76%），
  但每个对带 K 个监督项 ⇒ 每 epoch 消费的目标帧数为 3.8×。epoch 数保持一致（同数据遍数），
  总优化步数因此少 24% —— 报告里两个数都给出。

用法：
  python t18_multistep.py --kind periodic --K 5 --epochs 2000 --tag ms5
  python t18_multistep.py --kind reflect --K 1  --epochs 60     # smoke
"""
import argparse
import datetime
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from dyn import LatentDynamics                                   # noqa: E402
from vae import LATENT, CKPT                                     # noqa: E402
import t18_collide as T18                                        # noqa: E402
from t18_collide import (CTX, BITS, DELTA_STAR, N_IC, ROLLOUT,   # noqa: E402
                         analytic_jac, single_step_cos, qstate,
                         fit_line, LAM_TRUE)
from t18_lam_data import lam_on_data                             # noqa: E402

DEV = T18.DEV
BATCH_DEF = 2048
# 输出文件名含 kind 与 tag：两个臂并行时若共用一个 JSON，
#    读-改-写存在竞态（后写者覆盖先写者），会静默丢失数据。
OUT_TMPL = os.path.join(ROOT, "logs", "t18_multistep_{}.json")

# 单步基线（ep2000）的**日志实测** cos —— G-ms3 用它核对版本
EXPECT_COS = {"reflect": (0.90453, "logs/_t18r_long.log"),
              "periodic": (0.70734, "logs/_t18p_long.log")}
LAM_STEPS = 20000      # λ₁（数据轨迹）的转移数


def mtime(p):
    return datetime.datetime.fromtimestamp(
        os.path.getmtime(p)).strftime("%Y-%m-%d %H:%M:%S")


# ---------------------------------------------------------------- 守卫 G-ms1
def guard_k1_equivalence(seed=1234, batch=256):
    """K=1 的展开路径必须与 t18_collide.train_dyn 的单步公式**逐位一致**。"""
    torch.manual_seed(seed)
    z = torch.randn(512, 20, LATENT) * 0.5 + 1.0
    mean = z.mean(dim=(0, 1))
    std = z.std(dim=(0, 1)).clamp_min(1e-6)
    n, T = z.shape[0], z.shape[1]
    ii, tt = torch.meshgrid(torch.arange(n), torch.arange(CTX, T - 1), indexing="ij")
    ii, tt = ii.reshape(-1)[:batch], tt.reshape(-1)[:batch]

    def one_step(unroll_k):
        torch.manual_seed(seed)
        m = LatentDynamics(ctx=CTX).to(DEV)
        opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=1e-4)
        ca = ((z[ii, tt - 1].to(DEV) - mean.to(DEV)) / std.to(DEV))
        cb = ((z[ii, tt].to(DEV) - mean.to(DEV)) / std.to(DEV))
        if unroll_k == 1:                       # 参照：t18_collide 的单步写法
            zc = torch.cat([ca.unsqueeze(1), cb.unsqueeze(1)], dim=1)
            loss = F.mse_loss(m(zc) * std.to(DEV) + mean.to(DEV), z[ii, tt + 1].to(DEV))
        else:                                   # 本文的展开写法（K=1）
            loss = 0.0
            for _ in range(1, 2):
                pn = m(torch.stack([ca, cb], dim=1))
                loss = loss + F.mse_loss(pn * std.to(DEV) + mean.to(DEV),
                                         z[ii, tt + 1].to(DEV))
                ca, cb = cb, pn
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(m.parameters(), 5.0)
        opt.step()
        return ({k: v.detach().clone() for k, v in m.state_dict().items()},
                float(loss.detach()))

    sd_a, la = one_step(1)
    sd_b, lb = one_step(2)
    gap = max(float((sd_a[k] - sd_b[k]).abs().max()) for k in sd_a)
    ok = gap < 1e-12
    print(f"  G-ms1 K=1 与单步公式逐位一致：损失 {la:.12f} vs {lb:.12f}  "
          f"参数最大差 {gap:.3e}  {'✓' if ok else '✗'}")
    assert ok, "K=1 的展开路径与单步公式不一致 —— 展开实现有误"
    return gap


# ---------------------------------------------------------------- 训练
def train_ms(ztr, mean, std, K=5, epochs=600, batch=BATCH_DEF, seed=0, verbose=True):
    """展开 K 步的多步训练。K=1 时与单步基线数学等价（G-ms1 已验证）。"""
    torch.manual_seed(seed)
    n, T = ztr.shape[0], ztr.shape[1]
    ii, tt = torch.meshgrid(torch.arange(n), torch.arange(CTX, T - K), indexing="ij")
    ii, tt = ii.reshape(-1), tt.reshape(-1)          # 索引留 CPU
    m = LatentDynamics(ctx=CTX).to(DEV)
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=1e-4)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    n_idx = ii.shape[0]
    steps = 0
    t0 = time.time()
    for ep in range(epochs):
        perm = torch.randperm(n_idx)[:min(n_idx, 105 * batch)]
        for i0 in range(0, perm.numel(), batch):
            sel = perm[i0:i0 + batch]
            bi, bt = ii[sel], tt[sel]
            ca = (ztr[bi, bt - 1].to(DEV) - mean) / std
            cb = (ztr[bi, bt].to(DEV) - mean) / std
            loss = 0.0
            for k in range(1, K + 1):
                pn = m(torch.stack([ca, cb], dim=1))              # (B, L) 归一化预测
                loss = loss + F.mse_loss(pn * std + mean, ztr[bi, bt + k].to(DEV))
                ca, cb = cb, pn
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(m.parameters(), 5.0)
            opt.step()
            steps += 1
        sch.step()
    if verbose:
        print(f"    训练完成 {time.time()-t0:.0f}s   优化步 {steps}   "
              f"（单步 K=1 同配置为 {math.ceil(n*(T-1-CTX)/batch)*epochs} 步）")
    return m, steps


# ---------------------------------------------------------------- 评估
def openloop_vs_truth(m, zva, mean, std, horizons=(1, 5, 10, 15), take=64):
    """模型自回归 rollout 对**真值潜向量**的相对误差与余弦（多步保真度的直接度量）。

    两个口径都给：相对误差会在长视界饱和到 ~1.0（预测与真值不相关），
    余弦是尺度无关的，能继续分辨「完全不相关(0)」与「反向相关(−1)」。
    """
    errs = {h: [] for h in horizons}
    coss = {h: [] for h in horizons}
    with torch.no_grad():
        for i in range(min(take, zva.shape[0])):
            z = zva[i]
            a = (z[0].to(DEV) - mean) / std
            b = (z[1].to(DEV) - mean) / std
            preds = []
            for _ in range(max(horizons)):
                p = m(torch.stack([a, b]).unsqueeze(0))[0]
                preds.append(p)
                a, b = b, p
            for h in horizons:
                p = preds[h - 1] * std + mean
                t = z[1 + h].to(DEV)
                errs[h].append(float((p - t).norm() / t.norm()))
                coss[h].append(float(F.cosine_similarity(p, t, dim=-1)))
    return ({h: float(np.mean(v)) for h, v in errs.items()},
            {h: float(np.mean(v)) for h, v in coss.items()})


def degenerate_copy_last(zva, horizons=(1, 5, 10, 15), take=64):
    """退化基线：预测 z_{t+1} := z_t（拷贝上一帧）。任何模型都必须显著优于它。"""
    errs = {h: [] for h in horizons}
    coss = {h: [] for h in horizons}
    for i in range(min(take, zva.shape[0])):
        z = zva[i]
        for h in horizons:
            p, t = z[1].to(DEV), z[1 + h].to(DEV)
            errs[h].append(float((p - t).norm() / t.norm()))
            coss[h].append(float(F.cosine_similarity(p, t, dim=-1)))
    return ({h: float(np.mean(v)) for h, v in errs.items()},
            {h: float(np.mean(v)) for h, v in coss.items()})


def eval_model(m, zva, mean, std, kind, tag, verbose=True):
    """全部指标（与 t18_collide 同口径）。"""
    r = dict(tag=tag, kind=kind)
    r["cos_single"] = single_step_cos(m, zva, mean, std)
    r["openloop_err"], r["openloop_cos"] = openloop_vs_truth(m, zva, mean, std)
    lo = float(zva.min()) - 0.5
    hi = float(zva.max()) + 0.5
    r["lo"], r["hi"] = lo, hi
    r["span"] = hi - lo
    rows = []
    for b in BITS:
        delta = r["span"] / (2 ** b - 1)
        inj = math.sqrt(LATENT) * delta / math.sqrt(12.0)      # G-ms2：按维度
        res, cens, endd = T18.rollout_crash(m, None, b, lo, hi, zva=zva)
        v = sorted(res[DELTA_STAR[0]])
        rows.append(dict(bits=b, delta=delta, inj=inj,
                         med=float(np.median(v)) if v else None,
                         q1=float(np.percentile(v, 25)) if v else None,
                         q3=float(np.percentile(v, 75)) if v else None,
                         n=len(v), censored=cens[DELTA_STAR[0]],
                         d_end_med=float(np.median(endd)) if endd else None,
                         floor=bool(inj > DELTA_STAR[0])))
    r["rows"] = rows
    best = None
    for x in rows:
        if x["d_end_med"] is None:
            continue
        if x["d_end_med"] / DELTA_STAR[0] < 1.0 and best is None:
            best = x["bits"]
    r["b_star"] = best
    ok = [x for x in rows if x["med"] is not None and not x["floor"]]
    r["fit_all"] = fit_line([(x["bits"], x["med"]) for x in rows if x["med"] is not None])
    r["fit_nofloor"] = fit_line([(x["bits"], x["med"]) for x in ok])
    if verbose:
        print(f"    cos {r['cos_single']:.5f}   b* {best}   "
              f"δ_∞@32 {rows[-1]['d_end_med']:.6g}   "
              f"开环误差 " + " ".join(f"t{h}={v:.3f}" for h, v in r["openloop_err"].items()))
    return r, (lo, hi)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kind", default="periodic", choices=["reflect", "periodic"])
    ap.add_argument("--K", type=int, default=5)
    ap.add_argument("--epochs", type=int, default=600)
    ap.add_argument("--batch", type=int, default=BATCH_DEF)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--tag", default="")
    ap.add_argument("--lam-steps", type=int, default=LAM_STEPS)
    ap.add_argument("--skip-lam", action="store_true")
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--allow-version-mismatch", action="store_true")
    a = ap.parse_args()
    if a.quick:
        a.epochs, a.lam_steps = 40, 2000
    tag = a.tag or f"K{a.K}_ep{a.epochs}"
    t0 = time.time()
    print("=" * 100)
    print(f"  T18 补充 · multistep 对照 —— kind={a.kind}  K={a.K}  epochs={a.epochs}  tag={tag}")
    print("=" * 100)

    # ---- 守卫 G-ms1
    print("\n  [0] 守卫")
    guard_k1_equivalence()

    # ---- 数据（复用潜向量）
    lat_p = os.path.join(CKPT, f"t18_{a.kind}_latents.pt")
    assert os.path.exists(lat_p), f"缺潜向量缓存 {lat_p}"
    print(f"    潜向量 {os.path.basename(lat_p)}  mtime {mtime(lat_p)}   "   # G-ms4
          f"{os.path.getsize(lat_p)/1e6:.1f} MB")
    dd = torch.load(lat_p, map_location="cpu", weights_only=True)
    ztr, zva = dd["ztr"], dd["zva"]
    assert ztr.shape == (12000, 20, LATENT), f"形状异常 {tuple(ztr.shape)}"
    print(f"    ztr {tuple(ztr.shape)}  zva {tuple(zva.shape)}  "
          f"VAE 重建余弦 {float(dd['rq']):.5f}  每序列碰撞 {float(dd['ctr']):.2f}")
    mean_c = ztr.mean(dim=(0, 1))
    std_c = ztr.std(dim=(0, 1)).clamp_min(1e-6)
    mean, std = mean_c.to(DEV), std_c.to(DEV)
    T18.mean_g, T18.std_g = mean, std                 # rollout_crash 用模块级变量

    # ---- 参照臂：单步基线模型（本次同时刻重算全部指标，并核对版本）
    ref_p = os.path.join(CKPT, f"t18_{a.kind}_dyn.pt")
    print(f"\n  [1] 参照臂（单步基线）{os.path.basename(ref_p)}  mtime {mtime(ref_p)}")
    ref = LatentDynamics(ctx=CTX).to(DEV)
    ref.load_state_dict(torch.load(ref_p, map_location=DEV, weights_only=False)["state"])
    ref.eval()
    R, (lo, hi) = eval_model(ref, zva, mean, std, a.kind, "single")
    exp_cos, src = EXPECT_COS[a.kind]
    gap_cos = abs(R["cos_single"] - exp_cos)
    print(f"    G-ms3 版本核对：cos {R['cos_single']:.5f} vs 日志 ep2000 {exp_cos:.5f}"
          f"（{src}）差 {gap_cos:.2e}  " + ("✓" if gap_cos < 1e-4 else "✗"))
    if gap_cos >= 1e-4 and not a.allow_version_mismatch:
        raise SystemExit(f"参照模型的 cos 与日志不符（差 {gap_cos:.2e}）—— 可能是别的 epoch 版本，"
                         f"拒绝比较。核对 mtime {mtime(ref_p)}；如确认无误加 --allow-version-mismatch")
    deg_e, deg_c = degenerate_copy_last(zva)
    print(f"    退化基线（拷贝上一帧）：误差 "
          + " ".join(f"t{h}={v:.3f}" for h, v in deg_e.items())
          + "   余弦 " + " ".join(f"t{h}={v:.3f}" for h, v in deg_c.items()))

    # ---- 训练 msK
    print(f"\n  [2] 训练 multistep K={a.K}")
    msm, n_steps = train_ms(ztr, mean, std, K=a.K, epochs=a.epochs,
                            batch=a.batch, seed=a.seed)
    ck = os.path.join(CKPT, f"t18_{a.kind}_K{a.K}_ep{a.epochs}_dyn.pt")
    torch.save(dict(state=msm.state_dict(), ctx=CTX, latent=LATENT,
                    mean=mean_c, std=std_c,
                    cfg=dict(kind=a.kind, K=a.K, epochs=a.epochs, seed=a.seed)),
               ck)
    print(f"    已保存 {os.path.basename(ck)}  mtime {mtime(ck)}")           # G-ms4

    # ---- 评估 msK
    print(f"\n  [3] msK 评估")
    Ms, _ = eval_model(msm, zva, mean, std, a.kind, f"msK{a.K}")

    # ---- G-ms5：量化必须真的改变状态
    d3 = next(x for x in Ms["rows"] if x["bits"] == 3)["d_end_med"]
    d32 = next(x for x in Ms["rows"] if x["bits"] == 32)["d_end_med"]
    assert d3 is not None and d32 is not None and abs(d3 - d32) > 1e-4, \
        f"b=3 与 b=32 的 δ_∞ 几乎相同（{d3} vs {d32}）—— 量化可能没接进被测路径"
    print(f"    G-ms5 b=3 δ_∞ {d3:.4f} vs b=32 δ_∞ {d32:.6g}  差 {abs(d3-d32):.4f} ✓")

    # ---- λ₁（沿真值数据轨迹）
    lam_res = {}
    if not a.skip_lam:
        print(f"\n  [4] λ₁（沿真值数据轨迹，{a.lam_steps} 个转移）")
        for name, mm in (("single", ref), ("msK", msm)):
            lam, diag = lam_on_data(mm, ztr, mean_c, std_c, n_steps=a.lam_steps)
            lam_res[name] = dict(lam1=float(lam[0]),
                                 spec=[float(x) for x in lam[:5]],
                                 **diag)
            print(f"    {name:<7} λ₁ {lam[0]:+.5f}   |u|max {diag['u_max']:.2f} "
                  f"(中位 {diag['u_max_med']:.2f})")

    # ---- 汇总
    print("\n" + "=" * 100)
    print(f"  汇总：{a.kind}   single(ep2000 基线) vs msK={a.K}(ep{a.epochs})")
    print("=" * 100)
    print(f"    {'指标':<24}{'single':>14}{'msK':>14}{'Δ':>12}")
    print(f"    {'单步 cos':<24}{R['cos_single']:>14.5f}{Ms['cos_single']:>14.5f}"
          f"{Ms['cos_single']-R['cos_single']:>+12.5f}")
    for h in R["openloop_err"]:
        print(f"    {f'开环误差 vs 真值 t={h}':<24}{R['openloop_err'][h]:>14.4f}"
              f"{Ms['openloop_err'][h]:>14.4f}{Ms['openloop_err'][h]-R['openloop_err'][h]:>+12.4f}")
    for h in R["openloop_cos"]:
        print(f"    {f'开环余弦 vs 真值 t={h}':<24}{R['openloop_cos'][h]:>14.4f}"
              f"{Ms['openloop_cos'][h]:>14.4f}"
              f"{Ms['openloop_cos'][h]-R['openloop_cos'][h]:>+12.4f}")
    for lbl, key in (("δ_∞ @b=32", 32), ("δ_∞ @b=8", 8)):
        ra = next(x for x in R["rows"] if x["bits"] == key)["d_end_med"]
        rb = next(x for x in Ms["rows"] if x["bits"] == key)["d_end_med"]
        print(f"    {lbl:<24}{ra:>14.6g}{rb:>14.6g}{rb-ra:>+12.4g}")
    print(f"    {'b*':<24}{str(R['b_star']):>14}{str(Ms['b_star']):>14}")
    if lam_res:
        print(f"    {'λ₁（数据轨迹）':<24}{lam_res['single']['lam1']:>14.5f}"
              f"{lam_res['msK']['lam1']:>14.5f}"
              f"{lam_res['msK']['lam1']-lam_res['single']['lam1']:>+12.5f}")
    print(f"    真值 λ₁ {LAM_TRUE[a.kind]:+.5f}")

    Q = dict(config=dict(kind=a.kind, K=a.K, epochs=a.epochs, batch=a.batch,
                         seed=a.seed, bits=BITS, dstar=list(DELTA_STAR),
                         n_ic=N_IC, rollout=ROLLOUT, lam_steps=a.lam_steps),
             ref=R, ms=Ms, lam=lam_res, steps=n_steps,
             degenerate=dict(err=deg_e, cos=deg_c),
             single_ckpt_mtime=mtime(ref_p), latents_mtime=mtime(lat_p),
             ms_ckpt_mtime=mtime(ck), ms_ckpt=os.path.basename(ck),
             lam_true=LAM_TRUE[a.kind], elapsed_s=round(time.time() - t0, 1))
    out_p = OUT_TMPL.format(f"{a.kind}_{tag}")
    with open(out_p, "w", encoding="utf-8") as f:
        json.dump(Q, f, ensure_ascii=False, indent=2)
    print(f"\n  → {out_p}（{Q['elapsed_s']}s）")


if __name__ == "__main__":
    main()
