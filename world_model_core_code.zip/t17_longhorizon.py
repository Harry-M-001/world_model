"""
T17 · 长视界规划：闭环的误差吸收能力在什么视界失效

背景：T16 发现「规划对量化远比预测鲁棒」（b=4 时预测掉 7.13%，规划只掉 3.1pp，
      且后者在噪声内），并给出机制猜测：**MPC 是闭环 + 相对比较**，量化误差让所有
      候选同向偏移，而决策只依赖候选之间的相对排序 → 一致偏移被抵消。
      但 T16 只跑了 10 步。**这个猜测没有在长视界上被检验过。**

本任务把它变成可测量的量：

  三臂 —— 唯一变量是「重规划周期 R」：
    R=1   标准 MPC（每步用最新状态重规划） = 完全闭环
    R=8   每 8 步重规划一次              = 半开环
    R=T   只在 t=0 规划一次，之后周期执行同一动作序列 = 开环（无反馈）

  响应：d(t) = 质心到目标距离（**全轨迹**，不只末值）、ink(t) = 墨迹占比（崩坏诊断）

  判据：
    ① 免费守卫：同一种子下三臂的 d(t) 前 8 步必须逐位一致
       （t=0 的规划三臂完全相同，执行的前 min(R,8) 步也相同；
        不一致 ⇒ 实现里存在与 R 相关的隐藏状态）
    ② 闭环 d(t) 在到达目标后的漂移率 ≈ 0（= 误差被吸收）；
       开环 > 0（= 误差累积）
    ③ 「失效视界」= 闭环 d(t) 开始显著上升的 t（若在 60 步内不出现，如实报「未失效」）

  量化对照 b ∈ {32, 4}：
    若「闭环吸收」成立，则 b=4 的开环应比 b=32 的开环更早发散，
    而两者的**闭环**都应保持平稳 —— 这是吸收能力的定量证明，而不是一句机制猜测。

产物 logs/t17_longhorizon.json
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from vae import CKPT, load_vae                       # noqa: E402
from t15_action import ActDynamics, H, W, DEV        # noqa: E402
from t16_plan import Planner, rollout_candidates, quantize_model  # noqa: E402

OUT_TMPL = os.path.join(ROOT, "logs", "t17_longhorizon{}.json")
N_EP, T_MAX, N_CAND, H_PLAN = 128, 60, 128, 8
BITS = [32, 4]
ARMS = [("closed", 1), ("half", 8), ("open", T_MAX)]

YY, XX = torch.meshgrid(torch.arange(H), torch.arange(W), indexing="ij")
YY, XX = YY.float(), XX.float()


def probe(pl, zc):
    """zc: (1,2,L) 归一化上下文 → (质心 tensor(2,), 墨迹占比 float)。

    一次解码同时给出两个诊断量（分开调用会重复解码，且这函数每步都调）。
    """
    with torch.no_grad():
        img = torch.sigmoid(pl.vae.decode((zc[:, -1] * pl.std + pl.mean).to(DEV)))
        img = img.view(H, W).cpu()
    s = img.sum().clamp_min(1e-6)
    c = torch.stack([(img * XX).sum() / s, (img * YY).sum() / s])
    return c, float((img > 0.5).float().mean())


def init_ctx(pl, z0, a0):
    return torch.cat([((z0.to(DEV) - pl.mean) / pl.std).unsqueeze(0),
                      ((a0.to(DEV) - pl.mean) / pl.std).unsqueeze(0)],
                     dim=0).unsqueeze(0)


def run_episode(pl, z0, a0, goal, R, gen, t_max=T_MAX, n_cand=N_CAND, Hh=H_PLAN):
    """跑一条 episode，返回 d(t)/ink(t)/cents(t) 全轨迹。

    R = 重规划周期。R > Hh 时，一次规划出的 Hh 步序列被**周期重复**执行到下次重规划。
    """
    zc = init_ctx(pl, z0, a0)
    c, iv = probe(pl, zc)
    ds, inks, cents = [float((c - goal).norm())], [iv], [c.tolist()]
    t, n_replan = 0, 0
    while t < t_max:
        acts = torch.randint(-1, 2, (n_cand, Hh, 2), generator=gen,
                             device=DEV).float()
        c_end, _ = rollout_candidates(pl, zc, acts)
        d = (c_end - goal.unsqueeze(0)).norm(dim=-1)
        seq = acts[int(d.argmin())]
        n_replan += 1
        for k in range(R):
            if t >= t_max:
                break
            zc = pl.step(zc, seq[k % Hh][None])
            t += 1
            c, iv = probe(pl, zc)
            ds.append(float((c - goal).norm()))
            inks.append(iv)
            cents.append(c.tolist())
    return dict(d=ds, ink=inks, cents=cents, n_replan=n_replan)


def slope(y):
    """线性拟合斜率（y 为等间隔序列）。"""
    n = len(y)
    x = np.arange(n, dtype=float)
    A = np.vstack([x, np.ones(n)]).T
    (k, _), *_ = np.linalg.lstsq(A, np.asarray(y, float), rcond=None)
    return float(k)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-ep", type=int, default=N_EP)
    ap.add_argument("--t-max", type=int, default=T_MAX)
    ap.add_argument("--bits", default="32,4", help="逗号分隔的位宽")
    ap.add_argument("--arms", default="closed,half,open", help="逗号分隔的臂名")
    ap.add_argument("--tag", default="", help="输出文件后缀")
    ap.add_argument("--quick", action="store_true", help="小样本测速")
    a = ap.parse_args()
    bits_use = [int(x) for x in a.bits.split(",")]
    arms_use = [(nm, R) for nm, R in ARMS if nm in a.arms.split(",")]
    assert arms_use, f"没有匹配的臂：{a.arms}"
    t0 = time.time()
    torch.manual_seed(0)

    d = torch.load(os.path.join(CKPT, "t15_act_data.pt"), map_location="cpu",
                   weights_only=False)
    zva = d["zva"]
    mean = zva.mean(dim=(0, 1)).to(DEV)
    std = zva.std(dim=(0, 1)).clamp_min(1e-6).to(DEV)
    m = ActDynamics().to(DEV)
    m.load_state_dict(torch.load(os.path.join(CKPT, "t15_act_dyn.pt"),
                                 map_location=DEV, weights_only=False)["state"])
    m.eval()
    vae = load_vae()
    vae.load_state_dict(torch.load(os.path.join(CKPT, "vae_gray_s3.pt"),
                                   map_location=DEV, weights_only=True)["state"])
    vae.eval()

    n = min(a.n_ep, zva.shape[0])
    T = a.t_max
    pl0 = Planner(m, vae, mean, std)
    GTC = pl0.centroid(zva[:n, -1])
    C0 = pl0.centroid(zva[:n, 1])
    dist0 = (C0 - GTC).norm(dim=-1)
    thresh = float(dist0.median()) * 0.5

    print("=" * 100)
    print("  T17 · 长视界规划：闭环的误差吸收在什么视界失效")
    print("=" * 100)
    print(f"  回合数 {n}   最大视界 T_max={T}   候选 {N_CAND}   内部规划视界 {H_PLAN}")
    print(f"  起始→目标距离：中位 {dist0.median():.1f} "
          f"(IQR [{dist0.quantile(.25):.1f}, {dist0.quantile(.75):.1f}])"
          f"   成功阈值 {thresh:.1f}")
    print(f"  三臂 = 重规划周期 R ∈ {{1, 8, {T}}}（闭环 / 半开环 / 开环）")

    Q = {"config": dict(n=n, t_max=T, n_cand=N_CAND, h_plan=H_PLAN,
                        thresh=thresh, bits=bits_use,
                        arms=[{"name": nm, "R": R} for nm, R in arms_use]),
         "dist0_median": float(dist0.median()), "arms": {}}

    for b in bits_use:
        mq = quantize_model(m, b)
        pl = Planner(mq, vae, mean, std)
        wd = getattr(mq, "_rel_delta", 0.0)
        print("\n" + "-" * 100)
        print(f"  b = {b}   权重相对扰动 {wd:.4g}")
        print("-" * 100)
        for name, R in arms_use:
            # 每条 episode 用固定种子 → 三臂的采样序列在对应规划次数上完全一致
            dmat, imat, replans = [], [], []
            for i in range(n):
                gen = torch.Generator(device=DEV)
                gen.manual_seed(1000 + i)
                r = run_episode(pl, zva[i, 0], zva[i, 1], GTC[i], R, gen, t_max=T)
                dmat.append(r["d"])
                imat.append(r["ink"])
                replans.append(r["n_replan"])
            D = np.array(dmat)                       # (n, T+1)
            I = np.array(imat)
            key = f"{name}_b{b}"
            Q["arms"][key] = dict(
                bits=b, R=R, n_replan_med=float(np.median(replans)),
                d_median=[float(x) for x in np.median(D, axis=0)],
                d_q25=[float(x) for x in np.quantile(D, .25, axis=0)],
                d_q75=[float(x) for x in np.quantile(D, .75, axis=0)],
                ink_median=[float(x) for x in np.median(I, axis=0)],
                hold=[float(x) for x in (D < thresh).mean(axis=0)],
                d_end_med=float(np.median(D[:, -1])),
                d_min_med=float(np.median(D.min(axis=1))),
                d_matrix=[[float(x) for x in row] for row in D],
            )
            print(f"    {name:<7}(R={R:>2})  重规划 {np.median(replans):>5.0f} 次   "
                  f"d(0) {np.median(D[:,0]):>6.2f}  d_min {np.median(D.min(1)):>6.2f}  "
                  f"d(T) {np.median(D[:,-1]):>6.2f}   "
                  f"保持率@T {(D[:,-1] < thresh).mean()*100:>5.1f}%   "
                  f"ink 末 {np.median(I[:,-1])*100:>5.2f}%")

    # ---------------- 判据①：免费守卫
    # 三臂唯一**强制**重合的位置是 t=1：t=0 那次规划三臂拿到同一批候选、同一个最优序列，
    # 执行的也都是 seq[0]。t≥2 起必然分叉 —— closed 用的是第 2 批采样的动作，
    # 而 half/open 用的是第 1 批序列的第 2 个动作。守卫不得写成「前 8 步一致」，
    # 该假设不符合算法结构（此处曾因假设错误导致守卫误报）。
    print("\n" + "=" * 100)
    print("  判据① · 免费守卫：三臂的 d(1) 必须逐位一致（唯一强制的重合点）")
    print("=" * 100)
    guard_ok = True
    for b in bits_use:
        base = np.array(Q["arms"][f"closed_b{b}"]["d_median"])
        for name, R in arms_use:
            if R == 1:
                continue
            cur = np.array(Q["arms"][f"{name}_b{b}"]["d_median"])
            gap = float(abs(base[1] - cur[1]))
            ok = gap < 1e-4
            guard_ok &= ok
            print(f"  b={b:<3} closed vs {name:<7}  d(1)={base[1]:.5f} vs {cur[1]:.5f}  "
                  f"差 {gap:.2e}  " + ("✓" if ok else "✗ t=0 的规划未被三臂共享"))
    Q["guard1_pass"] = bool(guard_ok)

    # ---------------- 判据②③：漂移率与失效视界
    print("\n" + "=" * 100)
    print("  判据②③ · 到达后的漂移率（正 = 误差在累积，≈0 = 被吸收）")
    print("=" * 100)
    print(f"  {'b':>3} {'臂':<8} {'τ_arrive 中位':>13} {'稳态段':>14} "
          f"{'漂移率/步':>11} {'判定':>16}")
    summary = {}
    for b in bits_use:
        for name, R in arms_use:
            D = np.array(Q["arms"][f"{name}_b{b}"]["d_matrix"])
            arr = []
            for row in D:
                idx = np.where(row < thresh)[0]
                arr.append(int(idx[0]) if len(idx) else -1)
            arr = np.array(arr)
            got = arr[arr >= 0]
            tau = float(np.median(got)) if len(got) else None
            if tau is None or tau >= 0.9 * T:
                sl = slope(np.median(D[:, int(T * 0.5):], axis=0))
                seg = f"[{int(T*0.5)},{T}]"
                note = "未到达（全程段斜率）"
            else:
                s0 = int(min(tau + 5, T - 3))
                sl = slope(np.median(D[:, s0:], axis=0))
                seg = f"[{s0},{T}]"
                note = "吸收（平）" if abs(sl) < 0.05 else ("累积（升）" if sl > 0 else "接近（降）")
            summary[f"{name}_b{b}"] = dict(tau_arrive_med=tau, slope=sl,
                                           seg=seg, verdict=note,
                                           arrive_rate=float((arr >= 0).mean()))
            print(f"  {b:>3} {name:<8} {('—' if tau is None else f'{tau:.0f}'):>13} "
                  f"{seg:>14} {sl:>+11.4f} {note:>16}")
    Q["steady"] = summary

    # ---------------- 闭环 vs 开环的分离
    print("\n" + "=" * 100)
    print("  闭环吸收的定量：闭环 d(t) vs 开环 d(t)（同一位宽）")
    print("=" * 100)
    print(f"  {'t':>4} " + "".join(f"{f'b{b} closed':>12}{f'b{b} open':>12}" for b in bits_use))
    for t in range(0, T + 1, max(1, T // 12)):
        row = f"  {t:>4} "
        for b in bits_use:
            dc = Q["arms"][f"closed_b{b}"]["d_median"][t]
            do = Q["arms"][f"open_b{b}"]["d_median"][t]
            row += f"{dc:>12.2f}{do:>12.2f}"
        print(row)
    for b in bits_use:
        dc = Q["arms"][f"closed_b{b}"]["d_median"]
        do = Q["arms"][f"open_b{b}"]["d_median"]
        gain = float(np.mean(do) - np.mean(dc))
        print(f"\n  b={b:<3} 全程 d 均值：闭环 {np.mean(dc):.3f}  开环 {np.mean(do):.3f}  "
              f"→ 闭环 − 开环 = {gain:+.3f}"
              + ("（正 = 闭环更优）" if gain >= 0 else "（**负 = 这一段开环反而更优**）"))

    # ---------------- 失效视界 τ*
    print("\n" + "=" * 100)
    print("  失效视界 τ*：d(t) 连续 5 步超过 (本臂 min d + 2.0) 的最小 t   —— 超过即误差开始累积")
    print("=" * 100)

    def fail_horizon(dmed, margin=2.0, k=5):
        dmin = float(np.min(dmed))
        over = np.asarray(dmed) > (dmin + margin)
        run = 0
        for t, o in enumerate(over):
            run = run + 1 if o else 0
            if run >= k:
                return int(t - k + 1)
        return None

    print(f"  {'臂':<10}" + "".join(f"{('b' + str(b)):>10}" for b in bits_use))
    for name, R in arms_use:
        row = f"  {name:<10}"
        for b in bits_use:
            fh = fail_horizon(Q["arms"][f"{name}_b{b}"]["d_median"])
            row += f"{(str(fh) if fh is not None else '>T'):>10}"
        print(row)
    Q["fail_horizon"] = {f"{name}_b{b}": fail_horizon(Q["arms"][f"{name}_b{b}"]["d_median"])
                         for name, R in arms_use for b in bits_use}

    Q["elapsed_s"] = round(time.time() - t0, 1)
    OUT = OUT_TMPL.format(a.tag)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(Q, f, ensure_ascii=False)
    print(f"\n  → {OUT}  ({Q['elapsed_s']}s)")


if __name__ == "__main__":
    main()
