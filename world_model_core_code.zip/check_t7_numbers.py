"""校验 train_noise.md 的关键数字与 logs/t7_range.json 一致。"""
import json
import math
import os
import _paths  # noqa: E402
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
D = json.load(open(os.path.join(ROOT, "logs", "t7_range.json"), encoding="utf-8"))
doc = open(_paths.phase1("train_noise.md"), encoding="utf-8").read()

A, B, C = D["A_theory"], D["B_range"], D["C_sigma"]
rows = {r["B"]: r for r in A["rows"]}
v = {b: r["var_mc"] for b, r in rows.items()}
v8_12 = v[8] / v[12]
dev_max = max(d["ratio"] for d in A["deviation"])
ref = {r["bits"]: r for r in B["groups"]["① 全局（现状）"]["rows"]}
pd = {r["bits"]: r for r in B["groups"]["② per-dimension"]["rows"]}
g8 = math.log2(pd[8]["med"] / ref[8]["med"])
g6 = math.log2(pd[6]["med"] / ref[6]["med"])
nz = (g6 + g8) / 2
cr = C["sigma_critical"]
sig = {r["sigma"]: r for r in C["rows"]}
base = sig[0.0]["train_mse"]

checks = [
    ("位宽定律 257.5", abs(v8_12 - 257.5) < 0.2 and "257.5×" in doc),
    ("范围定律 3.99", abs(A["range_law"] - 3.99) < 0.01 and "3.99×" in doc),
    ("相位上界 2.98", abs(dev_max - 2.98) < 0.01 and "2.98" in doc),
    ("全局跨度 74.247", abs((B["global_range"][1] - B["global_range"][0]) - 74.247) < 0.01
     and "74.247" in doc),
    ("理论省位 0.662", abs(B["save_bits_theory"] - 0.662) < 0.001 and "0.662 位" in doc),
    ("分位省位 1.022", abs(B["save_bits_theory_quantile"] - 1.022) < 0.001 and "1.022 位" in doc),
    ("b=8 实测增益 +0.652", abs(g8 - 0.652) < 0.002 and "+0.652 位" in doc),
    ("b=6 实测增益 +1.000", abs(g6 - 1.000) < 0.002 and "+1.000 位" in doc),
    ("非平凡档均值 +0.826", abs(nz - 0.826) < 0.002 and "+0.826 位" in doc),
    ("σ_critical = 0.3", cr == 0.3 and "σ_critical ≈ 0.3" in doc),
    ("σ=0.3 退化 1.63×", abs(sig[0.3]["train_mse"] / base - 1.63) < 0.01 and "1.63×" in doc),
    ("σ=1.0 退化 4.18×", abs(sig[1.0]["train_mse"] / base - 4.18) < 0.01 and "4.18×" in doc),
    ("λ₁ 跳幅 −0.96…+0.085",
     abs(min(r["lam1"] for r in C["rows"]) + 0.963) < 0.002
     and abs(max(r["lam1"] for r in C["rows"]) - 0.085) < 0.002),
    ("0.48% 裁剪比例",
     abs(B["clip_frac"]["③ per-dim + 1/99 分位"][0] * 100 - 0.48) < 0.01
     and "0.48%" in doc),
]
bad = [n for n, ok in checks if not ok]
print(f"train_noise.md 数字核对 {len(checks)} 项：", "全部通过 ✅" if not bad else f"失败 {bad}")
print()
print("  参考数据：")
print(f"    位宽定律 Var(8)/Var(12) = {v8_12:.1f}×   范围定律 {A['range_law']:.2f}×")
print(f"    相位比值上确界 {dev_max:.3f}")
print(f"    b=6 增益 {g6:+.3f} 位   b=8 增益 {g8:+.3f} 位   非平凡均值 {nz:+.3f} 位")
print(f"    σ_critical {cr}   σ=0.3 退化 {sig[0.3]['train_mse']/base:.2f}×")
print(f"    λ₁ 范围 [{min(r['lam1'] for r in C['rows']):+.4f}, "
      f"{max(r['lam1'] for r in C['rows']):+.4f}]")
