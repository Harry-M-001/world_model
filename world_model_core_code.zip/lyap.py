"""
lyap.py —— QR 法估计 Lyapunov 谱（T3 的核心工具）

自检（python lyap.py）：
  线性映射   特征值即指数（解析）
  Hénon      a=1.4, b=0.3 → λ₁≈0.418, λ₂≈−1.623（文献值）
  Lorenz     σ=10, ρ=28, β=8/3 → λ₁≈0.906, λ₂≈0, λ₃≈−14.57（文献值）
  三条都必须 < 10% 误差，且「和检验」Σλ 必须吻合（Hénon: Σλ=log|b|；Lorenz: Σλ=−(σ+1+β)）

两个实现要点（均可由自检中的和检验检出）：
  1. discard 期间的累积必须剔除。若 acc 从第 0 步开始累、却只除以 discard 之后的步数，
     估计会整体偏高 (discard+n)/n 倍 —— Hénon 的和检验差了 1.25 倍，正好是 25000/20000。
  2. 变分方程 M' = J(s)·M 必须与状态方程用**同阶积分器**。状态 RK4、矩阵 Euler 的话，
     Euler 每步引入 O((dt‖J‖)²) 的增长偏差，Lorenz 上足以把 λ₁ 从 0.9 抬到 1.07。
"""
import sys

import numpy as np


def qr_spectrum_map(f_step, jac, x0, n_steps, discard=2000, dt=1.0):
    """离散映射的 Lyapunov 谱。f_step: x→x'；jac: x→(d,d)。返回 (d,) 降序。"""
    x = np.asarray(x0, dtype=np.float64).copy()
    d = x.size
    Q = np.eye(d)
    acc = np.zeros(d)
    used = 0
    for n in range(discard + n_steps):
        J = np.asarray(jac(x), dtype=np.float64)
        x = np.asarray(f_step(x), dtype=np.float64).copy()
        Q, R = np.linalg.qr(J @ Q)
        # 只在 discard 之后累积：discard 阶段只更新正交基（让轨迹落到吸引子上）。
        #   若这里照常累积、却只除以 discard 之后的步数，估计会整体偏高
        #   (discard+n)/n 倍 —— Hénon 的和检验当场抓住了它（−1.505×0.8 = −1.204）。
        if n >= discard:
            acc += np.log(np.maximum(np.abs(np.diag(R)), 1e-300))
            used += 1
    return acc / max(used, 1) / dt


# ------------------------------------------------------- Hénon（验证）
def henon_step(s, a=1.4, b=0.3):
    x, y = s
    return np.array([1.0 - a * x * x + y, b * x])


def henon_jac(s, a=1.4, b=0.3):
    x, _ = s
    return np.array([[-2.0 * a * x, 1.0], [b, 0.0]])


# ------------------------------------------------------- Lorenz（验证）
def lorenz_rhs(s, sigma=10.0, rho=28.0, beta=8.0 / 3.0):
    x, y, z = s
    return np.array([sigma * (y - x), x * (rho - z) - y, x * y - beta * z])


def lorenz_jac(s, sigma=10.0, rho=28.0, beta=8.0 / 3.0):
    x, y, z = s
    return np.array([[-sigma, sigma, 0.0],
                     [rho - z, -1.0, -x],
                     [y, x, -beta]])


def qr_spectrum_flow(rhs, jac, x0, t_total, dt=0.005, reorth=10, discard_t=0.0):
    """连续流的 Lyapunov 谱：状态与变分方程**同用 RK4**，每 reorth 步 QR 一次。"""
    s = np.asarray(x0, dtype=np.float64).copy()
    d = s.size
    M = np.eye(d)
    acc = np.zeros(d)
    used_t = 0.0
    n_re = int(round(t_total / (dt * reorth)))
    skip = int(round(discard_t / (dt * reorth)))
    for i in range(n_re):
        for _ in range(reorth):
            k1s = rhs(s);                    k1M = jac(s) @ M
            s2 = s + 0.5 * dt * k1s;         M2 = M + 0.5 * dt * k1M
            k2s = rhs(s2);                   k2M = jac(s2) @ M2
            s3 = s + 0.5 * dt * k2s;         M3 = M + 0.5 * dt * k2M
            k3s = rhs(s3);                   k3M = jac(s3) @ M3
            s4 = s + dt * k3s;               M4 = M + dt * k3M
            k4s = rhs(s4);                   k4M = jac(s4) @ M4
            s = s + (dt / 6.0) * (k1s + 2 * k2s + 2 * k3s + k4s)
            M = M + (dt / 6.0) * (k1M + 2 * k2M + 2 * k3M + k4M)
        Q, R = np.linalg.qr(M)
        if i >= skip:      # 同上：discard 阶段只更新正交基，不累积
            acc += np.log(np.maximum(np.abs(np.diag(R)), 1e-300))
            used_t += reorth * dt
        M = Q
    return acc / max(used_t, 1e-12), used_t


# ------------------------------------------------------- 自检
def selftest():
    print("=" * 76)
    print("  lyap.py 自检：在已知解析值/文献值的系统上验证 QR 估计器")
    print("=" * 76)
    ok = True

    eig = np.array([np.log(1.2), np.log(0.9), np.log(0.7)])
    A = np.diag(np.exp(eig))
    lam = qr_spectrum_map(lambda s: A @ s, lambda s: A,
                          x0=np.full(3, 1e-6), n_steps=400, discard=0)
    err = np.abs(lam - eig).max() / np.abs(eig[0])
    print(f"\n  [线性映射] 解析 {eig.round(5)}")
    print(f"             QR   {lam.round(5)}   相对误差 {err*100:.4f}%")
    ok &= err < 0.10

    lam = qr_spectrum_map(henon_step, henon_jac, x0=np.array([0.1, 0.1]),
                          n_steps=20000, discard=5000)
    print(f"\n  [Hénon a=1.4 b=0.3]  文献 λ₁≈0.418, λ₂≈−1.623")
    print(f"             QR   {lam.round(4)}")
    e1 = abs(lam[0] - 0.418) / 0.418
    print(f"             λ₁ 相对误差 {e1*100:.2f}%   和检验 Σλ={lam.sum():.4f} "
          f"vs log|b|={np.log(0.3):.4f}")
    ok &= e1 < 0.10 and abs(lam.sum() - np.log(0.3)) < 0.02

    lam, t_used = qr_spectrum_flow(lorenz_rhs, lorenz_jac,
                                   x0=np.array([1.0, 1.0, 20.0]),
                                   t_total=250.0, dt=0.005, reorth=10, discard_t=25.0)
    print(f"\n  [Lorenz σ=10 ρ=28 β=8/3]  文献 λ₁≈0.906, λ₂≈0, λ₃≈−14.57  (T={t_used:.0f})")
    print(f"             QR   {lam.round(4)}")
    e1 = abs(lam[0] - 0.906) / 0.906
    print(f"             λ₁ 相对误差 {e1*100:.2f}%   和检验 Σλ={lam.sum():.4f} "
          f"vs −(σ+1+β)={-(10+1+8/3):.4f}")
    ok &= e1 < 0.10 and abs(lam.sum() + (10 + 1 + 8 / 3)) < 0.3

    print("\n" + "=" * 76)
    print(f"  自检结论：{'PASS（三条系统全部 < 10%，且和检验吻合）' if ok else 'FAIL'}")
    print("=" * 76)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(selftest())
