"""
T18 补充 · multistep 对照的汇总与**预注册判据**

读 `logs/t18_multistep_{kind}_ms5ep2000.json`，把单步基线与 multistep 臂对齐成一张表，
并按**事先写死**的判据给出裁决（判据在此文件里，不在事后报告里 —— 防止挪动门槛）。

被检验的问题：
  T18 主结果说「不连续动力学（periodic）没有有限的 b*」—— δ_∞ 在所有位宽上饱和在 ~1.10。
  替代解释：**训练方式不够**（该臂单步 cos 只有 0.707，退化基线 0.685）。

预注册判据（写死，不因结果而改）：
  H1「训练方式假说」成立 ⟺ 两臂**同时**满足
       (a) msK 的 δ_∞@b=32 < 0.5·δ*        （地板被压到 δ* 的一半以下）
       (b) msK 的 b* 不为 None
  H2「动力学假说」成立 ⟺ δ_∞@b=32 ≥ 0.5·δ*（地板基本不动）
  H0（无法判定）⟺ 落在 0.5·δ* 两侧的模糊区，或 cos 没有实质提升

辅助证据（不参与裁决，但解释机制）：
  · λ₁（沿真值数据轨迹）的方向变化 —— 若 msK 使 periodic 的 λ₁ 更负而地板仍不降，
    则「地板 ⇔ λ₁>0 + 有界吸引子」的解释被加强；若 λ₁ 更负且地板降了，同样加强。
  · 开环余弦 t=5/10/15 —— 检验 multistep 到底有没有改善多步保真度。
  · δ_∞(b) 在 b≥6 的平台比 max/min —— 平台越平越说明它不由注入量决定。

用法：python t18_ms_compare.py
产物：logs/t18_multistep_analysis.json
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

OUT = os.path.join(ROOT, "logs", "t18_multistep_analysis.json")
PAIRS = [("reflect", os.path.join(ROOT, "logs", "t18_multistep_reflect_ms5ep2000.json")),
         ("periodic", os.path.join(ROOT, "logs", "t18_multistep_periodic_ms5ep2000.json"))]
DSTAR = 1.0


def d_end(rec, b):
    return next(x for x in rec["rows"] if x["bits"] == b)["d_end_med"]


def main():
    print("=" * 104)
    print("  T18 补充 · multistep 对照汇总（预注册判据）")
    print("=" * 104)
    res = {}
    missing = [k for k, p in PAIRS if not os.path.exists(p)]
    if missing:
        print(f"  ⚠ 缺结果文件：{missing} —— 实验可能还在跑")
        raise SystemExit(1)

    print(f"\n  {'环境':<10}{'臂':<10}{'K':>4}{'epochs':>8}{'单步cos':>10}"
          f"{'开环余弦 t=5':>13}{'t=15':>9}{'δ_∞@8':>10}{'δ_∞@32':>12}{'b*':>6}"
          f"{'λ₁(数据)':>11}")
    for kind, path in PAIRS:
        D = json.load(open(path, encoding="utf-8"))
        for lbl, rec in (("single", D["ref"]), (f"msK={D['config']['K']}", D["ms"])):
            lam = D["lam"]["single" if lbl == "single" else "msK"]["lam1"]
            print(f"  {kind:<10}{lbl:<10}{D['config']['K']:>4}{D['config']['epochs']:>8}"
                  f"{rec['cos_single']:>10.5f}{rec['openloop_cos']['5']:>13.4f}"
                  f"{rec['openloop_cos']['15']:>9.4f}{d_end(rec, 8):>10.4f}"
                  f"{d_end(rec, 32):>12.6g}{str(rec['b_star']):>6}{lam:>+11.5f}")
        # 平台统计（b ≥ 6 且非 floor）
        plat = [x["d_end_med"] for x in D["ms"]["rows"]
                if x["bits"] >= 6 and not x["floor"] and x["d_end_med"] is not None]
        res[kind] = dict(
            config=D["config"], lam_true=D["lam_true"],
            single=dict(cos=D["ref"]["cos_single"], b_star=D["ref"]["b_star"],
                        d32=d_end(D["ref"], 32), d8=d_end(D["ref"], 8),
                        cos_t5_ref=D["ref"]["openloop_cos"]["5"],
                        cos_t15_ref=D["ref"]["openloop_cos"]["15"],
                        lam1=D["lam"]["single"]["lam1"]),
            ms=dict(cos=D["ms"]["cos_single"], b_star=D["ms"]["b_star"],
                    d32=d_end(D["ms"], 32), d8=d_end(D["ms"], 8),
                    cos_t5=D["ms"]["openloop_cos"]["5"],
                    cos_t15=D["ms"]["openloop_cos"]["15"],
                    lam1=D["lam"]["msK"]["lam1"]),
            plateau=dict(vals=plat, max=float(max(plat)), min=float(min(plat)),
                         ratio=float(max(plat) / min(plat))),
            mtimes=dict(single_ckpt=D["single_ckpt_mtime"], latents=D["latents_mtime"],
                        ms_ckpt=D["ms_ckpt_mtime"], ms_ckpt_name=D["ms_ckpt"]),
        )

    # ---- 真值基准改用**同 n_digit** 的测量（2026-09-19 勘误）
    n2p = os.path.join(ROOT, "logs", "t18_truth_n2.json")
    assert os.path.exists(n2p), "缺 logs/t18_truth_n2.json（同 n_digit 的真值测量）"
    T2 = json.load(open(n2p, encoding="utf-8"))
    key = {"periodic": "⑥ n=2 环绕 a≡0（periodic 臂的正确基准；对拍已存 +0.24431）",
           "reflect": "⑥b n=2 反射 a≡0（reflect 臂的正确基准，**此前缺失**）"}
    print("\n" + "-" * 104)
    print("  真值基准（勘误：改用**同 n_digit** 的测量，旧值来自 n=3）")
    print("-" * 104)
    for kind, _ in PAIRS:
        r2 = next(x for x in T2["rows"] if x["name"] == key[kind])
        old_v = res[kind]["lam_true"]
        res[kind]["lam_true"] = float(r2["lam_mean"])
        res[kind]["lam_true_se"] = float(r2["lam_se"])
        res[kind]["lam_true_old_wrong"] = float(old_v)
        print(f"  {kind:<10} 正确 {r2['lam_mean']:+.5f}±{r2['lam_se']:.5f}"
              f"（n_digit={r2['n_digit']}）   旧误用 {old_v:+.5f}")
    _col = json.load(open(os.path.join(ROOT, "logs", "t18_collide.json"),
                          encoding="utf-8"))
    print(f"  数据 config.n_digit = {_col['periodic']['config']['n_digit']}"
          f" ⇒ 必须与真值测量一致（n_digit={T2['rows'][0]['n_digit']}）")

    print("\n" + "-" * 104)
    print("  裁决")
    print("-" * 104)
    verdict = {}
    for kind, _ in PAIRS:
        r = res[kind]
        d32, bstar = r["ms"]["d32"], r["ms"]["b_star"]
        h1 = (d32 < 0.5 * DSTAR) and (bstar is not None)
        h2 = d32 >= 0.5 * DSTAR
        v = "H1（训练方式假说）" if h1 else ("H2（动力学假说）" if h2 else "H0（无法判定）")
        verdict[kind] = dict(verdict=v, d32=d32, b_star=bstar,
                             d32_ratio=d32 / DSTAR, h1=bool(h1), h2=bool(h2))
        print(f"  {kind:<10} msK δ_∞@32 = {d32:.6g}（{d32/DSTAR:.3f}·δ*）  b* = {bstar}"
              f"   ⇒ **{v}**")
        print(f"             cos {r['single']['cos']:.5f} → {r['ms']['cos']:.5f}"
              f"（Δ{r['ms']['cos']-r['single']['cos']:+.5f}）"
              f"   开环余弦 t=5 {r['single']['cos_t5_ref']:.4f} → {r['ms']['cos_t5']:.4f}"
              f"   平台比 max/min = {r['plateau']['ratio']:.3f}")
        print(f"             λ₁（数据轨迹）{r['single']['lam1']:+.5f} → {r['ms']['lam1']:+.5f}"
              f"   真值 {r['lam_true']:+.5f}")

    print("\n" + "-" * 104)
    print("  附加观察（机制侧，不参与裁决）")
    print("-" * 104)
    for kind, _ in PAIRS:
        r = res[kind]
        print(f"  {kind:<10} 平台值 {[round(x,4) for x in r['plateau']['vals']]}"
              f"   ← b≥6 各档的 δ_∞；平台越平越说明它不由量化注入量决定")
    print("\n  λ₁ 符号 vs 地板：")
    for kind, _ in PAIRS:
        r = res[kind]
        for lbl, lam, d32 in (("single", r["single"]["lam1"], r["single"]["d32"]),
                              ("msK", r["ms"]["lam1"], r["ms"]["d32"])):
            print(f"    {kind:<10} {lbl:<7} λ₁ {lam:+.5f}  δ_∞@32 {d32:>10.6g}"
                  f"   {'有地板' if d32 > 0.5 * DSTAR else '无地板'}")

    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(dict(verdict=verdict, res=res, dstar=DSTAR), f,
                  ensure_ascii=False, indent=2)
    print(f"\n  → {OUT}")


if __name__ == "__main__":
    main()
