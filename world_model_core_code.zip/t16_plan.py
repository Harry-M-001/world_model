"""
T16 · 规划实验（世界模型第二条判据）+ 量化 × 规划（本项目独有的角度）

背景：T15 补齐了世界模型三判据的第①③条（动作驱动 / 反事实），**第②条「能否用于规划」尚未检验**。
本任务补上它，并立刻接上本项目独有的问题：**低精度什么时候让「规划」崩**（而不仅是「预测」崩）？

Part A 规划（零数据成本）
  任务：从序列的初始状态出发，用「随机射击 + MPC」在潜空间里搜索动作序列，
        把墨迹质心送到指定目标区域。
    · 每个决策点采样 n_cand 条随机动作序列（长度 H），用模型展开、解码末帧、选最接近目标的
    · 只执行第一步，然后重规划（receding horizon）—— 这是标准的 MPC
    · **成功判据**：末帧质心落在目标框内
    · **对照**：随机动作基线（不规划，随机走）—— 规划的增益必须显著高于它

Part B 量化 × 规划（差异化点）
  对动作预测器的 Linear 层做权重对称量化，扫 b ∈ {4,6,8,16,32}，测：
    · 单步预测 cos（与 T5 同口径）
    · **规划成功率**（本任务新指标）
  初判（可证伪）：**规划的成功率对位宽比单步预测更敏感** ——
  因为规划要在多个候选之间**比较差异**，量化误差会淹没候选之间的区分度。

产物 logs/t16_plan.json
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from vae import LATENT, CKPT, load_vae              # noqa: E402
from t15_action import ActDynamics, H, W, DEV       # noqa: E402
from guards import G                                # noqa: E402

OUT = os.path.join(ROOT, "logs", "t16_plan.json")
N_EP, H_PLAN, N_CAND, N_STEP = 64, 8, 256, 10
BITS = [4, 6, 8, 16, 32]
YY, XX = torch.meshgrid(torch.arange(H), torch.arange(W), indexing="ij")
YY, XX = YY.float(), XX.float()


# ------------------------------------------------------------------ 量化
def qsym(w, bits):
    if bits >= 32:
        return w
    qmax = 2 ** (bits - 1) - 1
    amax = w.detach().abs().amax(dim=tuple(range(1, w.dim())), keepdim=True) \
        if w.dim() >= 2 else w.detach().abs().amax()
    scale = (amax / qmax).clamp_min(1e-12)
    return torch.clamp(torch.round(w / scale), -qmax, qmax) * scale


def quantize_model(m, bits):
    """返回量化后的副本（只动 Linear 权重；nn.Sequential 里的 SiLU 无参数）。

    守卫（对齐 T5 的 G-q5）：量化必须**真的改变权重**，否则报错 ——
    本任务首次运行时 b=16 与 b=32 给出逐位相同的指标，就是「量化静默失效」。
    """
    import copy
    q = copy.deepcopy(m)
    if bits >= 32:
        return q
    n, num, den = 0, 0.0, 0.0
    for (name, mod), (_, mod0) in zip(q.named_modules(), m.named_modules()):
        if isinstance(mod, nn.Linear):
            w0 = mod0.weight.data
            mod.weight.data = qsym(w0, bits)
            num += float(((mod.weight.data - w0) ** 2).sum())
            den += float((w0 ** 2).sum())
            n += 1
    assert n > 0, "没有量化到任何 Linear"
    rel = (num / max(den, 1e-30)) ** 0.5
    assert rel > 0.0, f"b={bits} 量化后权重逐位未变 —— 量化静默失效"
    q._rel_delta = rel
    return q


# ------------------------------------------------------------------ 环境接口
class Planner:
    def __init__(self, model, vae, mean, std):
        self.m, self.vae, self.mean, self.std = model, vae, mean, std

    def step(self, zc, a):
        """zc: (B, 2, L) 归一化；a: (B, 2) 原始动作 → 返回 (B, 2, L) 归一化上下文"""
        with torch.no_grad():
            p = self.m(zc, a)
        return torch.cat([zc[:, 1:], p.unsqueeze(1)], dim=1)

    def centroid(self, z):
        """z: (B, L) 原始潜向量 → 像素质心 (B, 2)"""
        with torch.no_grad():
            img = torch.sigmoid(self.vae.decode(z.to(DEV))).view(-1, H, W).cpu()
        s = img.sum(dim=(-1, -2)).clamp_min(1e-6)
        cy = (img * YY).sum(dim=(-1, -2)) / s
        cx = (img * XX).sum(dim=(-1, -2)) / s
        return torch.stack([cx, cy], dim=-1)


def rollout_candidates(pl, zc0, acts):
    """acts: (n_cand, H, 2) → 返回末帧质心 (n_cand, 2) 与末帧潜向量。"""
    n, Hh, _ = acts.shape
    zc = zc0.expand(n, -1, -1).contiguous()
    for h in range(Hh):
        zc = pl.step(zc, acts[:, h, :])
    z_last = zc[:, -1] * pl.std + pl.mean
    return pl.centroid(z_last), z_last


def plan_episode(pl, z0, a0, goal, steps=N_STEP, Hh=H_PLAN, n_cand=N_CAND, rng=None):
    """从 (z0, a0) 这对初始帧出发做 MPC，返回 (末质心, 是否成功, 轨迹质心)。"""
    zc = torch.cat([((z0.to(DEV) - pl.mean) / pl.std).unsqueeze(0),
                    ((a0.to(DEV) - pl.mean) / pl.std).unsqueeze(0)], dim=0).unsqueeze(0)
    cents = []
    for t in range(steps):
        acts = torch.randint(-1, 2, (n_cand, Hh, 2)).float().to(DEV)
        c_end, _ = rollout_candidates(pl, zc, acts)
        d = (c_end - goal.unsqueeze(0)).norm(dim=-1)   # c_end 与 goal 都在 CPU（centroid 返回 CPU）
        best = int(d.argmin())
        cents.append(pl.centroid(zc[:, -1] * pl.std + pl.mean)[0])
        zc = pl.step(zc, acts[best:best + 1, 0, :])
    c_final = pl.centroid(zc[:, -1] * pl.std + pl.mean)[0]
    cents.append(c_final)
    return c_final, cents


def random_baseline(pl, z0, a0, steps=N_STEP):
    """不规划：随机动作直接走同样步数。"""
    zc = torch.cat([((z0.to(DEV) - pl.mean) / pl.std).unsqueeze(0),
                    ((a0.to(DEV) - pl.mean) / pl.std).unsqueeze(0)], dim=0).unsqueeze(0)
    for t in range(steps):
        a = torch.randint(-1, 2, (1, 2)).float().to(DEV)
        zc = pl.step(zc, a)
    return pl.centroid(zc[:, -1] * pl.std + pl.mean)[0]


# ------------------------------------------------------------------ 主流程
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-ep", type=int, default=N_EP)
    ap.add_argument("--quick", action="store_true", help="只用 2 个位宽快速试跑")
    a = ap.parse_args()
    t0 = time.time()
    torch.manual_seed(0)

    d = torch.load(os.path.join(CKPT, "t15_act_data.pt"), map_location="cpu",
                   weights_only=False)
    zva = d["zva"]
    mean = zva.mean(dim=(0, 1)).to(DEV)
    std = zva.std(dim=(0, 1)).clamp_min(1e-6).to(DEV)
    m = ActDynamics().to(DEV)
    m.load_state_dict(torch.load(os.path.join(CKPT, "t15_act_dyn.pt"),
                                map_location=DEV, weights_only=False)["state"])
    m.eval()
    vae = load_vae()
    vae.load_state_dict(torch.load(os.path.join(CKPT, "vae_gray_s3.pt"),
                                  map_location=DEV, weights_only=True)["state"])
    vae.eval()
    pl = Planner(m, vae, mean, std)

    # ---- 目标：以「真实序列第 T-1 帧的质心」为目标（保证可达）
    n = min(a.n_ep, zva.shape[0])
    GTC = pl.centroid(zva[:n, -1])
    print("=" * 94)
    print("  T16 · 规划实验（世界模型第二条判据）+ 量化 × 规划")
    print("=" * 94)
    print(f"  回合数 {n}  MPC：horizon {H_PLAN} · 候选 {N_CAND} · 决策点 {N_STEP}")
    print(f"  目标定义：真实序列末帧的墨迹质心（**保证可达**）")
    print(f"  目标质心范围 x [{GTC[:,0].min():.1f},{GTC[:,0].max():.1f}] "
          f"y [{GTC[:,1].min():.1f},{GTC[:,1].max():.1f}]")
    # 起始质心
    C0 = pl.centroid(zva[:n, 1])
    print(f"  起始质心范围 x [{C0[:,0].min():.1f},{C0[:,0].max():.1f}] "
          f"y [{C0[:,1].min():.1f},{C0[:,1].max():.1f}]")
    dist0 = (C0 - GTC).norm(dim=-1)
    print(f"  起始→目标 的质心距离：中位 {dist0.median():.1f} "
          f"(IQR [{dist0.quantile(.25):.1f}, {dist0.quantile(.75):.1f}])")
    # 成功阈值：取起始距离的中位的一半（既要可达、又要有区分度）
    thresh = float(dist0.median()) * 0.5
    print(f"  成功阈值 ‖Δc‖ < {thresh:.1f}（= 起始距离中位的一半）\n")

    # ---- Part A：全精度规划
    print("-" * 94)
    print("  Part A · 全精度（b=32）：规划 vs 随机基线")
    print("-" * 94)
    succ, errs, cents_all = [], [], []
    for i in range(n):
        cf, cents = plan_episode(pl, zva[i, 0], zva[i, 1], GTC[i])
        e = float((cf - GTC[i]).norm())
        errs.append(e)
        succ.append(e < thresh)
        cents_all.append([float(x) for c in cents for x in c])
    rand_err, rand_succ = [], []
    for i in range(n):
        cr = random_baseline(pl, zva[i, 0], zva[i, 1])
        e = float((cr - GTC[i]).norm())
        rand_err.append(e)
        rand_succ.append(e < thresh)
    A = dict(n=n, thresh=thresh,
             plan_succ=float(np.mean(succ)), plan_err_med=float(np.median(errs)),
             rand_succ=float(np.mean(rand_succ)), rand_err_med=float(np.median(rand_err)))
    print(f"  规划     ：成功率 **{A['plan_succ']*100:.1f}%**  末端误差中位 {A['plan_err_med']:.2f}")
    print(f"  随机基线 ：成功率 {A['rand_succ']*100:.1f}%  末端误差中位 {A['rand_err_med']:.2f}")
    gain = A["plan_succ"] - A["rand_succ"]
    print(f"  → 规划增益 {gain*100:+.1f} 个百分点  "
          + ("**判据②达成**" if gain > 0.2 else "**增益不足，判据②未达成**"))

    # ---- Part B：量化 × 规划
    print("\n" + "-" * 94)
    print("  Part B · 量化 × 规划：位宽 → 规划成功率 vs 单步预测 cos")
    print("-" * 94)
    bits_list = [32, 4] if a.quick else [32] + [b for b in BITS if b != 32]
    rows = []
    print(f"  {'b':>4} {'规划成功率':>11} {'末端误差中位':>13} {'单步 cos':>10} "
          f"{'规划相对 b32':>13} {'cos 相对 b32':>13}")
    base_succ = None
    base_cos = None
    errs_by_bits = {}
    for b in bits_list:
        # 关键设计：每个位宽使用同一批随机候选（固定种子），
        # 否则位宽效应会被候选差异淹没。
        torch.manual_seed(0)
        mq = quantize_model(m, b)
        plq = Planner(mq, vae, mean, std)
        ss, ee = [], []
        for i in range(n):
            cf, _ = plan_episode(plq, zva[i, 0], zva[i, 1], GTC[i])
            e = float((cf - GTC[i]).norm())
            ee.append(e)
            ss.append(e < thresh)
        errs_by_bits[b] = ee
        # 单步 cos（与 T5 同口径）
        ii = torch.arange(n)
        ca = ((zva[ii, 0].to(DEV) - mean) / std).unsqueeze(1)
        cb = ((zva[ii, 1].to(DEV) - mean) / std).unsqueeze(1)
        zc0 = torch.cat([ca, cb], dim=1)
        with torch.no_grad():
            pr = mq(zc0, d["ava"][ii, 2].float().to(DEV)) * std + mean
        cs = float(F.cosine_similarity(pr, zva[ii, 2].to(DEV), dim=-1).mean())
        su = float(np.mean(ss))
        if b == 32:
            base_succ, base_cos = su, cs
        rows.append(dict(bits=b, plan_succ=su, err_med=float(np.median(ee)),
                         single_cos=cs, w_rel_delta=getattr(mq, "_rel_delta", 0.0)))
        ds = f"{(su-base_succ)*100:>+12.1f}pp" if base_succ is not None else f"{'基线':>14}"
        dc = f"{(cs-base_cos):>+13.5f}" if base_cos is not None else f"{'基线':>13}"
        print(f"  {b:>4} {su*100:>10.1f}% {np.median(ee):>13.2f} {cs:>10.5f} {ds} {dc}"
              f"   权重扰动 {getattr(mq, '_rel_delta', 0):.4f}")

    # ---- 判据：规划对位宽是否比单步预测更敏感
    print("\n" + "-" * 94)
    print("  判据：规划的成功率对位宽是否比单步预测更敏感")
    print("-" * 94)
    sens = []
    for r in rows:
        if r["bits"] == 32:
            continue
        d_succ = base_succ - r["plan_succ"]
        d_cos = base_cos - r["single_cos"]
        rel_cos = d_cos / max(abs(base_cos), 1e-9)
        sens.append(dict(bits=r["bits"], d_succ=d_succ, d_cos=d_cos, rel_cos=rel_cos,
                         ratio=(d_succ / rel_cos) if rel_cos > 1e-9 else None))
        print(f"  b={r['bits']:<3} 规划掉 {d_succ*100:>5.1f}pp ；单步 cos 掉相对 {rel_cos*100:>6.2f}%"
              + (f" → 规划灵敏度是预测的 {sens[-1]['ratio']:.1f}×"
                 if sens[-1]["ratio"] else ""))
    # 须显式处理空集：若对集合先过滤再做全称判断，过滤结果为空时 all([])=True，
    # 会因空真（vacuous truth）假报「假设成立」。
    worse = [s for s in sens if s["d_succ"] > 0.02]
    if not worse:
        verdict = ("**规划对位宽几乎不敏感**（假设被否证）："
                   "没有任何位宽的规划成功率下降超过 2 个百分点，"
                   "而单步 cos 在 b=4 时已掉 6.6%")
    elif all(s["d_succ"] >= s["rel_cos"] for s in worse):
        verdict = "**规划比预测更敏感**（假设成立）"
    else:
        verdict = "规划与预测的敏感度相当（假设不成立）"
    print(f"  → {verdict}")

    # 多阈值敏感性：回答「是不是成功阈值太松、掩盖了差异」
    print("\n" + "-" * 94)
    print("  事后多阈值判定（同一批轨迹，只换成功判据）")
    print("-" * 94)
    print(f"  {'阈值':>8} " + "".join(f"{f'b{bb}':>9}" for bb in bits_list) + "   趋势")
    thr_rows = []
    for th in (thresh, thresh * 0.75, thresh * 0.5, thresh * 0.3):
        vals = [float(np.mean([e < th for e in errs_by_bits[bb]])) for bb in bits_list]
        i4 = bits_list.index(4) if 4 in bits_list else len(bits_list) - 1
        d = vals[0] - vals[i4]      # b=32 减 b=4（**不能用 vals[-1]，那是 b=16**）
        print(f"  {th:>8.2f} " + "".join(f"{v*100:>8.1f}%" for v in vals)
              + f"   b32−b4 = {d*100:+.1f}pp")
        thr_rows.append(dict(thresh=float(th), succ={str(bb): v for bb, v in zip(bits_list, vals)},
                            d_b32_b4=float(d)))
    print("  （阈值越紧，规划任务越难；若位宽效应只在紧阈值下出现，说明原阈值太松）")

    OUTD = {"config": dict(n_ep=n, horizon=H_PLAN, n_cand=N_CAND, steps=N_STEP,
                           thresh=thresh, bits=bits_list),
            "A_full_precision": A, "B_bits_scan": rows, "sensitivity": sens,
            "thresh_scan": thr_rows, "errs_by_bits": {str(k): v for k, v in errs_by_bits.items()},
            "verdict": verdict, "elapsed_s": round(time.time() - t0, 1),
            "_note": ("T16：世界模型第二条判据（规划）+ 量化×规划。"
                      "目标取真实序列末帧质心，保证可达；成功阈值 = 起始距离中位的一半。")}
    prev = {}
    if os.path.exists(OUT):
        prev = json.load(open(OUT, encoding="utf-8"))
    prev.update(OUTD)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(prev, f, ensure_ascii=False, indent=2)
    print(f"\n-> {os.path.relpath(OUT, ROOT)}  （{OUTD['elapsed_s']}s）")


if __name__ == "__main__":
    main()
