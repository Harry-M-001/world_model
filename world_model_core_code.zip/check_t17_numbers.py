"""核验 T17_长视界规划.md 中的数字与 logs/t17_longhorizon*.json 一致。"""
import json
import os
import _paths  # noqa: E402
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from t17_analyze import fail_horizon, slope   # noqa: E402


def main():
    arms = {}
    for fn in ("t17_longhorizon.json", "t17_longhorizon_b6to16.json"):
        p = os.path.join(ROOT, "logs", fn)
        arms.update(json.load(open(p, encoding="utf-8"))["arms"])
    doc = open(_paths.phase1("T17_长视界规划.md"), encoding="utf-8").read()

    def tau(nm, b):
        return fail_horizon(arms[f"{nm}_b{b}"]["d_median"])

    def drift(nm, b):
        D = np.array(arms[f"{nm}_b{b}"]["d_matrix"])
        T = D.shape[1] - 1
        return slope(np.median(D[:, min(20, T - 15):], axis=0))

    def hold(b):
        return arms[f"closed_b{b}"]["hold"][-1]

    def wd(b):
        for k, v in arms.items():
            if v["bits"] == b and v.get("R") == 1:
                return v
        return None

    checks = [
        ("T_max = 60", arms["closed_b32"]["d_median"].__len__() == 61 and "60 步" in doc),
        ("τ*(closed,b4)=41", tau("closed", 4) == 41 and "**41**" in doc),
        ("τ*(closed,b≥6)=None", all(tau("closed", b) is None for b in (6, 8, 12, 16, 32))),
        ("τ*(half,b4)=18", tau("half", 4) == 18 and "**18**" in doc),
        ("τ*(half,b6)=42", tau("half", 6) == 42 and "**42**" in doc),
        ("τ*(half,b≥8)=None", all(tau("half", b) is None for b in (8, 12, 16, 32))),
        ("τ*(open) 全在 10–11", all(tau("open", b) in (10, 11) for b in (4, 6, 8, 12, 16, 32))),
        ("漂移 closed b4=+0.1504", abs(drift("closed", 4) - 0.1504) < 5e-4),
        ("漂移 half b4=+0.2477", abs(drift("half", 4) - 0.2477) < 5e-4),
        ("漂移 closed b≥6 全在 ±0.008", all(abs(drift("closed", b)) < 0.008 for b in (6, 8, 12, 16, 32))),
        ("漂移 open b≥6 全为正且 ≤0.031", all(0 < drift("open", b) <= 0.031 for b in (6, 8, 12, 16, 32))),
        ("漂移 open b4=+0.1283", abs(drift("open", 4) - 0.1283) < 5e-4),
        ("保持率 closed b4=43.0%", abs(hold(4) - 0.430) < 0.002 and "43.0%" in doc),
        ("保持率 closed b32=88.3%", abs(hold(32) - 0.883) < 0.002 and "88.3%" in doc),
        ("保持率 half b32=95.3%", abs(arms["half_b32"]["hold"][-1] - 0.953) < 0.002),
        ("保持率 open b32=32.8%", abs(arms["open_b32"]["hold"][-1] - 0.328) < 0.002),
        ("守卫 d(1) 差 ≤2.86e-06", abs(arms["closed_b32"]["d_median"][1]
                                     - arms["open_b32"]["d_median"][1]) < 1e-9),
        ("文档含权重扰动逐个值", all(x in doc for x in
         ("0.1535", "0.0347", "0.0084", "5.25e-4", "3.28e-5"))),
        ("起始距离中位 17.1", "17.1" in doc),
    ]
    bad = [n for n, ok in checks if not ok]
    print(f"T17 数字核对 {len(checks)} 项：", "全部通过 ✅" if not bad else f"失败 {bad}")
    print()
    print("  τ* 表:")
    for nm in ("closed", "half", "open"):
        print(f"    {nm:<7}" + "".join(
            f"{(str(tau(nm, b)) if tau(nm, b) is not None else '>T'):>8}"
            for b in (4, 6, 8, 12, 16, 32)))
    print("  b* = ", min([b for b in (4, 6, 8, 12, 16, 32) if tau("closed", b) is None]))


if __name__ == "__main__":
    main()
