# -*- coding: utf-8 -*-
"""G1② 第一步 · 短视界规划的功效确认（n=80 回合/臂，预注册判据）

G1① 的结论：oracle 评分 100% ⇒ 天花板高；模型 8 步评分与真值脱钩（Spearman −0.009）；
视界扫描 H=1 62.5% > 随机 33.3%（n=24，方向性）。本步在 **80 回合/臂** 上确认：

──────────────── 预注册（跑之前写死）────────────────
臂（同一 80 回合；前 24 回合与 T19 逐位一致，后 56 回合为新样本）：
  R  随机对照（rng 5000+e，40 步随机动作，无规划）
  M1 模型评分规划器 H=1（k=1，每步重规划；h192）
  M2 模型评分规划器 H=2（k=1）
  O  oracle 评分 H=1（真值动力学 rollout 1 步 → 真值质心距；天花板参照）

主判据（预注册）：M1 与 R 的成功率差，双样本双比例 z 检验，双侧 α=0.05。
  · 若 M1 显著 > R ⇒ 短视界规划可行，G1② 主线（「在模型诚实范围内规划」）确立；
  · 若不显著 ⇒ 「规划价值」负面结果成立，冻结规划类（Q2/Q3/Q4 照常）。
次要判据：M2 vs M1（视界效应确认）；O（天花板参照）；前 24 回合子集与 T19 的可比性。
多重性：主判据 1 个，不校正；次要判据标注为探索性。
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

from t19_pareto import (L_EP, H_PLAN, render, step_true)      # noqa: E402
from t14_warn import load_act_model, act_feats                # noqa: E402
from multiphys import rand_state, H, W, LIM                   # noqa: E402
from collide import DIGIT                                     # noqa: E402
from variant2 import GRAY                                     # noqa: E402
from vae import load_vae, CKPT                                # noqa: E402

DEV = "cuda" if torch.cuda.is_available() else "cpu"
OUT = os.path.join(ROOT, "logs", "g1_step2_horizon.json")
N_EP = 80
N_CAND = 32
ALPHA = 0.05
YY, XX = torch.meshgrid(torch.arange(H).float(), torch.arange(W).float(), indexing="ij")


def two_prop_z(s1, n1, s2, n2):
    """双比例合并 z 统计（双侧）。"""
    p1, p2 = s1 / n1, s2 / n2
    pp = (s1 + s2) / (n1 + n2)
    se = math.sqrt(pp * (1 - pp) * (1 / n1 + 1 / n2))
    if se == 0:
        return 0.0, 1.0
    z = (p1 - p2) / se
    # 正态尾（无 scipy 依赖）：erfc
    pval = math.erfc(abs(z) / math.sqrt(2))
    return z, pval


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-ep", type=int, default=N_EP)
    a = ap.parse_args()
    t0 = time.time()
    print("=" * 100)
    print(f"  G1② 第一步 · 短视界规划功效确认（{a.n_ep} 回合/臂，预注册 α={ALPHA}）")
    print("=" * 100)

    vae = load_vae()
    vae.load_state_dict(torch.load(os.path.join(CKPT, "vae_gray_s3.pt"),
                                   map_location=DEV, weights_only=True)["state"])
    vae.eval()
    digits_pool = GRAY[True]

    def encode(frame):
        x = torch.from_numpy(frame).float().div_(255.0).view(1, 1, H, W).to(DEV)
        with torch.no_grad():
            return vae.encode_det(x)[0]

    def centroid(z_raw):
        with torch.no_grad():
            img = torch.sigmoid(vae.decode(z_raw.to(DEV))).view(-1, H, W).cpu()
        s = img.sum(dim=(-1, -2)).clamp_min(1e-6)
        cy = (img * YY).sum(dim=(-1, -2)) / s
        cx = (img * XX).sum(dim=(-1, -2)) / s
        return torch.stack([cx, cy], dim=-1)

    # ---- 回合构造（与前 24 回合逐位一致于 T19；24–79 为新样本）----
    goals, starts = [], []
    for e in range(a.n_ep):
        rng = np.random.default_rng(1900 + e)
        st0 = rand_state(rng, 2)
        order = rng.permutation(len(digits_pool))[:2]
        digs = [digits_pool[i] for i in order]
        acts = np.zeros((L_EP, 3))
        for t in range(L_EP):
            di = int(rng.integers(0, 2))
            ux = uy = 0
            while ux == 0 and uy == 0:
                ux, uy = int(rng.integers(-1, 2)), int(rng.integers(-1, 2))
            acts[t] = (di, ux, uy)
        st = st0.copy()
        for t in range(L_EP):
            st = step_true(st, acts[t])
        z_end = encode(render(st, digs))
        goals.append(centroid(z_end).cpu()[0])
        starts.append(dict(st=st0, digs=digs, frame1=render(st0, digs)))
    starts_c = [centroid(encode(sd["frame1"])).cpu()[0] for sd in starts]
    goals_t = torch.stack(goals)
    starts_t = torch.stack(starts_c)
    dist0 = (starts_t - goals_t).norm(dim=-1)
    thresh = float(dist0.median()) * 0.5
    print(f"  距离中位 {dist0.median():.4f}；阈值 {thresh:.4f}"
          f"（前 24 回合与 T19 同构）")

    def sample_cands(rng, h_plan):
        cands = np.zeros((N_CAND, h_plan, 3))
        for c in range(N_CAND):
            for h in range(h_plan):
                di = int(rng.integers(0, 2))
                ux = uy = 0
                while ux == 0 and uy == 0:
                    ux, uy = int(rng.integers(-1, 2)), int(rng.integers(-1, 2))
                cands[c, h] = (di, ux, uy)
        return cands

    # ---------------- R 随机对照 ----------------
    print("\n[R] 随机对照（80 回合）")
    succ_R = []
    for e in range(a.n_ep):
        sd = starts[e]
        st = sd["st"].copy()
        digs = sd["digs"]
        rng = np.random.default_rng(5000 + e)
        for t in range(L_EP):
            di = int(rng.integers(0, 2))
            ux = uy = 0
            while ux == 0 and uy == 0:
                ux, uy = int(rng.integers(-1, 2)), int(rng.integers(-1, 2))
            st = step_true(st, (di, ux, uy))
        z_obs = encode(render(st, digs))
        succ_R.append(float((centroid(z_obs).cpu()[0] - goals[e]).norm()) < thresh)
    print(f"  随机成功率 {sum(succ_R)}/{a.n_ep} = {np.mean(succ_R)*100:.1f}%")

    # ---------------- 规划臂 ----------------
    tag = "dense_h192_act"
    m, mean, std = load_act_model(tag)

    def plan_arm(h_plan, e, label):
        """模型评分规划器，k=1，每步重规划；返回成功与逐步在阈率。"""
        sd = starts[e]
        st = sd["st"].copy()
        digs = sd["digs"]
        goal = goals[e]
        z_prev = encode(sd["frame1"]).cpu()
        z_cur = z_prev.clone()
        rng = np.random.default_rng(9000 + e)
        for rp in range(L_EP):
            zc = torch.cat([((z_prev.to(DEV) - mean) / std).unsqueeze(0),
                            ((z_cur.to(DEV) - mean) / std).unsqueeze(0)],
                           dim=0).unsqueeze(0)
            cands = sample_cands(rng, h_plan)
            af = act_feats(torch.tensor(cands.reshape(-1, 3),
                                        dtype=torch.float32)).to(DEV)
            zc_rep = zc.expand(N_CAND, -1, -1)
            with torch.no_grad():
                for h in range(h_plan):
                    ah = af[h * N_CAND:(h + 1) * N_CAND]
                    pm, _ = m(zc_rep, None, ah)
                    zc_rep = torch.cat([zc_rep[:, 1:], pm.unsqueeze(1)], dim=1)
            z_last = zc_rep[:, -1] * std + mean
            cc = []
            for c in range(0, N_CAND, 16):
                cc.append(centroid(z_last[c:c + 16]).cpu())
            cc = torch.cat(cc, dim=0)
            d_m = (cc - goal.unsqueeze(0)).norm(dim=-1).cpu().numpy()
            best = int(d_m.argmin())
            st = step_true(st, cands[best, 0])
            z_obs = encode(render(st, digs))
            z_prev, z_cur = z_cur, z_obs.cpu()
        fd = float((centroid(z_cur.to(DEV)).cpu()[0] - goal).norm())
        return fd < thresh, fd

    def oracle_arm(e):
        """oracle 评分 k=1（天花板参照）：真值 rollout 1 步 → 真值质心距。"""
        sd = starts[e]
        st = sd["st"].copy()
        digs = sd["digs"]
        goal = goals[e]
        rng = np.random.default_rng(9000 + e)
        for rp in range(L_EP):
            cands = sample_cands(rng, 1)
            ds = np.zeros(N_CAND)
            for c in range(N_CAND):
                sc = st.copy()
                sc = step_true(sc, cands[c, 0])
                z_end = encode(render(sc, digs))
                ds[c] = float((centroid(z_end).cpu()[0] - goal).norm())
            best = int(ds.argmin())
            st = step_true(st, cands[best, 0])
            z_obs = encode(render(st, digs))
        fd = float((centroid(z_obs).cpu()[0] - goal).norm())
        return fd < thresh, fd

    arms = {}
    for label, h_plan in (("M1(H=1)", 1), ("M2(H=2)", 2)):
        print(f"\n[{label}] 模型评分规划器（{a.n_ep} 回合）")
        succ, dists = [], []
        for e in range(a.n_ep):
            s_, fd = plan_arm(h_plan, e, label)
            succ.append(s_)
            dists.append(fd)
            if (e + 1) % 20 == 0:
                print(f"    {e+1}/{a.n_ep}  累计成功率 {np.mean(succ)*100:.1f}%")
        arms[label] = dict(success=float(np.mean(succ)), succ=succ,
                           mean_dist=float(np.mean(dists)))
        print(f"  {label}: {sum(succ)}/{a.n_ep} = {np.mean(succ)*100:.1f}%"
              f"  末距均值 {np.mean(dists):.2f}")

    print(f"\n[O] oracle 评分 H=1（天花板参照，{a.n_ep} 回合）")
    succ_O, dists_O = [], []
    for e in range(a.n_ep):
        s_, fd = oracle_arm(e)
        succ_O.append(s_)
        dists_O.append(fd)
        if (e + 1) % 20 == 0:
            print(f"    {e+1}/{a.n_ep}  累计成功率 {np.mean(succ_O)*100:.1f}%")
    arms["O(oracle H=1)"] = dict(success=float(np.mean(succ_O)), succ=succ_O,
                                 mean_dist=float(np.mean(dists_O)))
    print(f"  oracle: {sum(succ_O)}/{a.n_ep} = {np.mean(succ_O)*100:.1f}%"
          f"  末距均值 {np.mean(dists_O):.2f}")
    arms["R(随机)"] = dict(success=float(np.mean(succ_R)), succ=succ_R,
                           mean_dist=float("nan"))

    # ---------------- 预注册主判据 ----------------
    def ztest(a1, a2):
        s1, s2 = sum(a1), sum(a2)
        n1 = n2 = len(a1)
        z, p = two_prop_z(s1, n1, s2, n2)
        return z, p

    print("\n" + "=" * 100)
    print("  预注册主判据：M1(H=1) vs R(随机)，双比例 z 检验，双侧 α=0.05")
    print("=" * 100)
    n = a.n_ep
    z, p = two_prop_z(sum(succ_R), n, sum(arms["M1(H=1)"]["succ"]), n)
    d_pp = (arms["M1(H=1)"]["success"] - arms["R(随机)"]["success"]) * 100
    sig = p < ALPHA
    print(f"  M1 {arms['M1(H=1)']['success']*100:.1f}% vs R {arms['R(随机)']['success']*100:.1f}%"
          f"（差 {d_pp:+.1f}pp）z={z:+.2f} p={p:.4f} ⇒ "
          f"{'显著 ⇒ 短视界规划可行，G1② 主线确立' if sig and d_pp > 0 else ('显著但方向相反' if sig else '不显著 ⇒ 规划价值负面结果成立，冻结规划类')}")
    z2, p2 = two_prop_z(sum(arms["M2(H=2)"]["succ"]), n, sum(arms["M1(H=1)"]["succ"]), n)
    print(f"  次要（探索性）M2 vs M1：{arms['M2(H=2)']['success']*100:.1f}% vs "
          f"{arms['M1(H=1)']['success']*100:.1f}% z={z2:+.2f} p={p2:.4f}")
    zo, po = two_prop_z(sum(succ_O), n, sum(succ_R), n)
    print(f"  次要 O(天花板) vs R：{np.mean(succ_O)*100:.1f}% vs {np.mean(succ_R)*100:.1f}%"
          f" z={zo:+.2f} p={po:.4f}")
    # 前 24 回合子集（与 T19 可比性）
    sub = slice(0, 24)
    print(f"  可比性：前 24 回合 M1 = {np.mean(succ[:24] if False else arms['M1(H=1)']['succ'][:24])*100:.1f}%"
          f"（G1① 视界扫描 H=1 为 62.5%）｜R = {np.mean(succ_R[:24])*100:.1f}%（T19 33.3%）")

    verdict = ("短视界规划显著优于随机 ⇒ G1② 主线确立：在模型诚实范围内规划"
               if (sig and d_pp > 0) else
               ("规划价值负面结果成立（M1 不显著优于随机）⇒ 冻结规划类" if not sig else "方向相反（异常，需检查）"))
    res = dict(config=dict(n_ep=n, n_cand=N_CAND, alpha=ALPHA, model=tag,
                           thresh=thresh, L_ep=L_EP),
               arms={k: dict(success=v["success"], mean_dist=v["mean_dist"],
                             succ=v["succ"]) for k, v in arms.items()},
               primary=dict(M1_vs_R=dict(z=z, p=p, diff_pp=d_pp, significant=bool(sig))),
               secondary=dict(M2_vs_M1=dict(z=z2, p=p2), O_vs_R=dict(z=zo, p=po)),
               subset24=dict(M1=float(np.mean(arms["M1(H=1)"]["succ"][:24])),
                             R=float(np.mean(succ_R[:24]))),
               verdict=verdict, elapsed_s=round(time.time() - t0, 1))
    json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"\n  产物 → {OUT}（{res['elapsed_s']}s）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
