r"""
T4b 数据的第二轮复核：

(1) λ₁(模型) 的可复现性与估计稳定性 —— 原报告写「single 臂 λ₁ = −0.281（偏差 −721%）」
    是**单次训练 + 单初值 + 单步数**的单个样本。重训给出 +0.00003。若该量本身方差极大，
    论文里的「−721%」不可复现，必须改成分布。

(2) δ 的饱和与临界位宽：高 b 档大量「永不越阈」到底是真的饱和，还是测量窗口不够？
    机制：误差递推 δ_{t+1} ≈ e^{λ_t} δ_t + η，若有限时间扩张结束后进入收缩区，
    δ 有上界 δ_∞(b)。当 η(b) 小到 δ_∞ < δ* 时 T_crash = ∞。
    → 可证伪预测：**渐近 λ₁ ≤ 0 的模型存在临界位宽 b\***，b > b* 时永不崩溃。

(3) 零参数理论预测：T(b) = (1/λ)·log(1 + δ*(e^λ−1)/η)，η(b)=delta(b)/2，
    只用真值 λ 与解析 η，不拟合任何参数。

产物 logs/recheck_tcrash2.json
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from t4b_arms import Net, gen_traj, quantize, qr_lam1, LAM_TRUE, N_TRAJ, N_STEPS, DEV  # noqa: E402

OUT = os.path.join(ROOT, "logs", "recheck_tcrash2.json")
CKPT = os.path.join(ROOT, "ckpt")


def make_data():
    rng = np.random.default_rng(0)
    D = np.stack([gen_traj(rng.uniform(-15, 15, 3), N_STEPS) for _ in range(N_TRAJ)])
    lo, hi = float(D.min()) - 1.0, float(D.max()) + 1.0
    return torch.tensor(D, dtype=torch.float32, device=DEV), lo, hi


def train_arm(arm, seed, Dt, epochs=600, K=5):
    torch.manual_seed(seed)
    ii, tt = torch.meshgrid(torch.arange(N_TRAJ), torch.arange(N_STEPS - K), indexing="ij")
    ii, tt = ii.reshape(-1).to(DEV), tt.reshape(-1).to(DEV)
    m = Net().to(DEV)
    opt = torch.optim.AdamW(m.parameters(), lr=2e-3, weight_decay=1e-5)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    n_idx = ii.shape[0]
    for ep in range(epochs):
        perm = torch.randperm(n_idx, device=DEV)
        for i0 in range(0, n_idx, 4096):
            sel = perm[i0:i0 + 4096]
            bi, bt = ii[sel], tt[sel]
            opt.zero_grad(set_to_none=True)
            z0 = Dt[bi, bt]
            loss = F.mse_loss(m(z0), Dt[bi, bt + 1])
            if arm == "multistep":
                zk = z0
                for k in range(2, K + 1):
                    zk = m(zk)
                    loss = loss + F.mse_loss(zk, Dt[bi, bt + k])
            loss.backward()
            opt.step()
        sch.step()
    with torch.no_grad():
        val = float(((m(Dt[:, :-1].reshape(-1, 3)) - Dt[:, 1:].reshape(-1, 3)) ** 2).mean())
    return m, val


def lam_of(m, x0=None, n_steps=20000, discard=5000):
    """QR λ₁，允许指定初值与步数（qr_lam1 固定 x0=[1,1,20]、20000 步）。"""
    from lyap import qr_spectrum_map
    W1 = m.net[0].weight.detach().cpu().numpy().astype(np.float64)
    b1 = m.net[0].bias.detach().cpu().numpy().astype(np.float64)
    W2 = m.net[2].weight.detach().cpu().numpy().astype(np.float64)
    b2 = m.net[2].bias.detach().cpu().numpy().astype(np.float64)
    W3 = m.net[4].weight.detach().cpu().numpy().astype(np.float64)
    b3 = m.net[4].bias.detach().cpu().numpy().astype(np.float64)

    def f(s):
        s = np.asarray(s, dtype=np.float64)
        a2 = np.tanh(W2 @ np.tanh(W1 @ s + b1) + b2)
        return W3 @ a2 + b3

    def jac(s):
        s = np.asarray(s, dtype=np.float64)
        a1 = np.tanh(W1 @ s + b1)
        a2 = np.tanh(W2 @ a1 + b2)
        return W3 @ np.diag(1 - a2 ** 2) @ W2 @ np.diag(1 - a1 ** 2) @ W1

    x0 = np.array([1.0, 1.0, 20.0]) if x0 is None else np.asarray(x0, float)
    lam = qr_spectrum_map(f, jac, x0=x0, n_steps=n_steps, discard=discard)
    return float(lam[0])


def phase_stab(seeds=(0, 1, 2, 3, 4)):
    print("\n" + "=" * 90)
    print("  (1) λ₁(模型) 可复现性：不同训练 seed / 不同初值 / 不同 QR 步数")
    print("=" * 90)
    Dt, lo, hi = make_data()
    res = {}
    for arm in ("single", "multistep"):
        res[arm] = []
        print(f"\n  [{arm}]")
        for sd in seeds:
            t0 = time.time()
            m, val = train_arm(arm, sd, Dt)
            lams = [lam_of(m, x0=x0, n_steps=20000)
                    for x0 in ([1.0, 1.0, 20.0], [-8.0, 7.0, 27.0], [13.0, 12.0, 35.0])]
            steps = [lam_of(m, x0=[1.0, 1.0, 20.0], n_steps=n) for n in (2000, 8000)]
            res[arm].append(dict(seed=sd, val_mse=val, train_s=round(time.time() - t0, 1),
                                 lam_x0=lams, lam_steps=steps,
                                 lam_main=lams[0]))
            print(f"    seed {sd}: valMSE {val:.4f}  λ₁ "
                  f"x0=[1,1,20]{lams[0]:+.5f}  [−8,7,27]{lams[1]:+.5f}  [13,12,35]{lams[2]:+.5f}"
                  f"   | 2000步 {steps[0]:+.5f}  8000步 {steps[1]:+.5f}")
        k = np.array([r["lam_main"] for r in res[arm]])
        print(f"    → λ₁（x0=[1,1,20]，20000 步）mean {k.mean():+.5f}  std {k.std():.5f}  "
              f"范围 [{k.min():+.5f}, {k.max():+.5f}]")
    return res


def phase_sat(steps=20000, bits=(6, 7, 8, 10, 12, 14, 16, 18, 20)):
    """δ 的饱和与临界位宽。"""
    print("\n" + "=" * 90)
    print("  (2) δ 的饱和与临界位宽：高 b 档是「真的永不崩」还是「窗口不够」")
    print(f"      窗口 {steps} 步（原为 300）")
    print("=" * 90)
    Dt, lo, hi = make_data()
    ics = Dt[:32, 0].contiguous()
    out = {}
    for arm, ck in (("single", "lorenz_single.pt"), ("multistep", "lorenz_multistep.pt")):
        m = Net().to(DEV)
        m.load_state_dict(torch.load(os.path.join(CKPT, ck), map_location=DEV,
                                     weights_only=True)["state"])
        lam1 = lam_of(m)
        print(f"\n  [{arm}]  QR λ₁(渐近) = {lam1:+.5f}   真值 {LAM_TRUE:+.5f}")
        print(f"    {'b':>3} {'delta/2':>9} {'δ_∞(中位)':>10} {'越阈':>6} "
              f"{'T_crash中位':>11} {'零参数理论':>10} {'实测/理论':>9}")
        rows = []
        traj_ref = []          # 无量化参考轨迹（各档共用）
        s_ref = ics.clone()
        with torch.no_grad():
            for t in range(steps):
                if t > 0:
                    s_ref = m(s_ref)
                traj_ref.append(s_ref.clone())
        for b in bits:
            delta = (hi - lo) / (2 ** b - 1)
            eta = delta / 2.0
            with torch.no_grad():
                s_q = ics.clone()
                ts = torch.full((ics.shape[0],), -1, dtype=torch.long, device=DEV)
                d_last = torch.zeros(ics.shape[0], device=DEV)
                for t in range(steps):
                    if t > 0:
                        s_q = quantize(m(s_q), b, lo, hi)
                    d = (s_q - traj_ref[t]).norm(dim=1)
                    d_last = d
                    new = (ts < 0) & (d > 1.0)
                    ts[new] = t
                obs = ts[ts >= 0].cpu().numpy().astype(float)
                cens = int((ts < 0).sum())
                d_end = d_last.detach().clone()      # 跑满 steps，取末步 δ 作为 δ_∞
            # 零参数理论
            if eta > 0 and LAM_TRUE > 0:
                T_th = math.log(1 + 1.0 * (math.exp(LAM_TRUE) - 1) / eta) / LAM_TRUE
            else:
                T_th = None
            med = float(np.median(obs)) if obs.size else None
            rows.append(dict(bits=b, delta=delta, eta=eta,
                             delta_inf_med=float(d_end.median()),
                             n=len(obs), censored=cens, med=med, T_theory=T_th))
            ratio = (f"{med/T_th:.2f}×" if (med and T_th) else "—")
            print(f"    {b:>3} {eta:>9.5f} {float(d_end.median()):>10.4f} "
                  f"{len(obs):>3}/{ics.shape[0]:<2} {str(med):>11} "
                  f"{(f'{T_th:.1f}' if T_th else '—'):>10} {ratio:>9}")
        out[arm] = dict(lam1=lam1, rows=rows, steps=steps)
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--phases", default="stab,sat")
    a = ap.parse_args()
    O = {}
    if "stab" in a.phases:
        O["stab"] = phase_stab()
    if "sat" in a.phases:
        O["sat"] = phase_sat()
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(O, f, ensure_ascii=False, indent=2)
    print(f"\n-> {os.path.relpath(OUT, ROOT)}")
