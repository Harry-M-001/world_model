# -*- coding: utf-8 -*-
"""T2b 第二轮 (a) 报告数字校验：报告中的数字必须能从 JSON 复算。

判据全部写成断言 + 非零退出码（交付门槛 = 全绿）。
"""
import json
import math
import os
import _paths  # noqa: E402
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DOC = _paths.phase1("T2b_第二轮_阻尼档.md")


def J(name):
    p = os.path.join(ROOT, "logs", name)
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def main():
    doc = open(DOC, encoding="utf-8").read()
    checks = []

    def C(name, ok):
        checks.append((name, bool(ok)))

    # ---- 真值 ----
    mp = J("multiphys_check.json")
    td = next(r for r in mp["truth"]["rows"] if r["proc"] == "damped")
    C("λ_max 读数与 JSON 一致（≈0）", f"{td['lam_mean']:.5f}" in doc and abs(td["lam_mean"]) < 1e-9)
    C("λ_v 读数与 JSON 一致", f"{td['lam_vel_mean']:.5f}" in doc)
    C("λ_v 理论值在报告中", f"log(1−γ) = {td['lam_vel_theory']:.5f}" in doc)
    C("λ_v 与理论差 < 1e-3", abs(td["lam_vel_mean"] - td["lam_vel_theory"]) < 1e-3)
    C("测量教训（δv/γ=20δ₀ 饱和）已写入", "20δ₀" in doc and "benettin_vel" in doc)

    # ---- VAE ----
    vae = J("multiphys_vae.json")
    vd = vae["verdict"]["damped"]
    C("VAE verdict damped 全 True", all(vd.values()))
    C("VAE 重建读数一致", f"{vae['damped']['recon']['pix_cos']:.4f}" in doc)
    C("VAE 帧对速度读出一致",
      f"{vae['damped']['readout_pair']['vel_mlp']:.3f}" in doc)

    # ---- 四臂 ----
    arms = {"dense_h480_dmp": None, "moe_lb0.01_dmp": None,
            "moe_lb0_dmp": None, "oracle_lb0.01_dmp": None}
    for k in arms:
        arms[k] = J(f"t2b_route_{k}.json")
        C(f"{k} cos 读数一致", f"{arms[k]['cos']['all']:.5f}" in doc)
    moe, orac, dense = arms["moe_lb0.01_dmp"], arms["oracle_lb0.01_dmp"], arms["dense_h480_dmp"]

    # ---- 裁决复算 ----
    gain = orac["cos"]["all"] - moe["cos"]["all"]
    C("Q2 标签冗余增益复算一致", f"{gain:+.4f}" in doc and abs(gain) < 0.03)
    loss = moe["cos"]["all"] - dense["cos"]["all"]
    C("Q3 净损失复算一致（负值）", f"{loss:+.4f}" in doc and loss < 0)
    r1m = J("t2b_route_moe_lb0.01.json")
    r1d = J("t2b_route_dense_h480.json")
    l1 = r1m["cos"]["all"] - r1d["cos"]["all"]        # 输入对齐勘误后的 round-1 参照
    C("Q3 引用勘误后 round-1 净损失", f"{l1:+.4f}" in doc and l1 < 0)
    ratio = moe["route"]["mi"]["excess"] / orac["route"]["mi"]["excess"]
    C("Q1 效应量比值复算一致（<10%）", f"{ratio*100:.1f}%" in doc and ratio < 0.10)
    C("oracle 三条判据显著（切换 p=0.000）",
      orac["route"]["switch"]["p_value"] < 0.001
      and f"{orac['route']['switch']['hit_rate']:.3f}" in doc)
    C("涌现臂切换命中不显著（p>0.05）", moe["route"]["switch"]["p_value"] > 0.05)
    C("Q4 判读存在（两臂一致）", "两臂一致" in doc)

    # ---- 卫生 ----
    C("无「五臂」残留", "五臂" not in doc)
    C("round-1 对照节存在", "与第一轮同构臂对照" in doc)
    import re
    C("无残留占位符", not re.findall(r"\{[a-z_]+\}", doc))
    C("粗体标记成对", doc.count("**") % 2 == 0)

    n_ok = sum(1 for _, ok in checks if ok)
    for name, ok in checks:
        print(f"  [{'✓' if ok else '✗'}] {name}")
    print(f"\n{n_ok}/{len(checks)} 通过")
    return 0 if n_ok == len(checks) else 1


if __name__ == "__main__":
    sys.exit(main())
