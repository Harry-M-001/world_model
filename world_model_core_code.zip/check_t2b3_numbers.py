# -*- coding: utf-8 -*-
"""T2b 第三轮（动作条件化）报告数字校验：报告数字必须能从 JSON 复算。"""
import json
import math
import os
import _paths  # noqa: E402
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DOC = _paths.phase1("T2b_第三轮_动作条件化.md")


def J(name):
    return json.load(open(os.path.join(ROOT, "logs", f"t2b_route_{name}.json"),
                          encoding="utf-8"))


def main():
    doc = open(DOC, encoding="utf-8").read()
    checks = []

    def C(name, ok):
        checks.append((name, bool(ok)))

    # 四臂 cos + 动作响应度
    arms = {}
    for k in ("dense_h480_act", "moe_lb0.01_act", "moe_lb0_act", "oracle_lb0.01_act"):
        arms[k] = J(k)
        C(f"{k} cos 读数一致", f"{arms[k]['cos']['all']:.5f}" in doc)
        C(f"{k} 动作响应度读数一致",
          f"{arms[k]['act_response']:.3f}" in doc and arms[k]["act_response"] > 0.2)

    moe, orac, dense = arms["moe_lb0.01_act"], arms["oracle_lb0.01_act"], arms["dense_h480_act"]
    gain = orac["cos"]["all"] - moe["cos"]["all"]
    loss = moe["cos"]["all"] - dense["cos"]["all"]
    C("Q2 增益复算（<0.02 ⇒ 标签冗余）", f"{gain:+.4f}" in doc and abs(gain) < 0.02)
    C("Q3 净损失复算（负值）", f"{loss:+.4f}" in doc and loss < 0)
    ratio = moe["route"]["mi"]["excess"] / orac["route"]["mi"]["excess"]
    C("Q1 效应量比值复算（<10%）", f"{100*ratio:.1f}%" in doc and ratio < 0.10)
    C("oracle 三判据显著（切换 p=0.000）",
      orac["route"]["switch"]["p_value"] < 0.001
      and f"{orac['route']['switch']['hit_rate']:.3f}" in doc)
    C("涌现臂切换不显著", moe["route"]["switch"]["p_value"] > 0.05)

    # 勘误对照表
    for k in ("dense_h480", "moe_lb0.01", "moe_lb0", "oracle_lb0.01",
              "dense_h480_dmp", "moe_lb0.01_dmp", "moe_lb0_dmp", "oracle_lb0.01_dmp"):
        d = J(k)
        C(f"勘误表 {k} 修正读数一致", f"{d['cos']['all']:.5f}" in doc)
    g2 = (J("oracle_lb0.01_dmp")["cos"]["all"] - J("moe_lb0.01_dmp")["cos"]["all"])
    l2 = (J("moe_lb0.01_dmp")["cos"]["all"] - J("dense_h480_dmp")["cos"]["all"])
    C("阻尼域 Q2/Q3 复算一致",
      f"{g2:+.4f}" in doc and f"{l2:+.4f}" in doc and g2 < 0.02 and l2 < 0)

    # 文档完整性
    C("off-by-one 勘误节存在", "base-only 实测裁决" in doc and "0.416" in doc)
    C("T18 护栏记录（碰撞比值）", "0.69" in doc)
    C("备份路径记录", "t2b_json_prefix-20260920-1400" in doc)
    C("无残留占位符", not re.findall(r"\{[a-z_]+\}", doc))
    C("粗体成对", doc.count("**") % 2 == 0)

    n_ok = sum(1 for _, ok in checks if ok)
    for name, ok in checks:
        print(f"  [{'✓' if ok else '✗'}] {name}")
    print(f"\n{n_ok}/{len(checks)} 通过")
    return 0 if n_ok == len(checks) else 1


if __name__ == "__main__":
    sys.exit(main())
