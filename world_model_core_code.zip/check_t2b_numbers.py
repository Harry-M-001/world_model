"""
T2b 数字校验 —— 报告里的每条关键声称必须与 logs/t2b_route_*.json 一致。

判据（失败即非零退出）：
  ① 五臂的 cos / 参数量与 JSON 一致
  ② 正对照成立：oracle 的三条判据都显著强于涌现臂
  ③ 涌现臂三条判据都**不**显著（按写死的阈值）
  ④ 容量对齐下 MoE 明显更差
  ⑤ 路由熵 ≈ log B（即「均匀路由」这一解释与数据一致）
  ⑥ 报告里不得出现旧的错误读数（0.980 只能作为「已修掉的假象」出现）
"""
import glob
import json
import math
import os
import _paths  # noqa: E402
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DOC = _paths.phase1("T2b_块级路由.md")
EXC_SIG, P_SIG = 0.05, 0.05


def L(k):
    with open(os.path.join(ROOT, "logs", f"t2b_route_{k}.json"), encoding="utf-8") as f:
        return json.load(f)


def main():
    doc = open(DOC, encoding="utf-8").read()
    # round-2 产物（_dmp / _B<k 扫描）由 check_t2b2_numbers.py 负责，此处只校验 round-1
    ks = sorted(os.path.basename(p)[len("t2b_route_"):-len(".json")]
                for p in glob.glob(os.path.join(ROOT, "logs", "t2b_route_*.json"))
                if not os.path.basename(p).endswith("_dmp.json")
                and "_act" not in os.path.basename(p)
                and "_B" not in os.path.basename(p))
    D = {k: L(k) for k in ks}
    em = [k for k in ks if D[k]["config"]["arm"] == "moe"]
    orc = [k for k in ks if D[k]["config"]["arm"] == "oracle"]
    dn = [k for k in ks if D[k]["config"]["arm"] == "dense"]
    assert em and orc and len(dn) >= 2, f"臂不全：{ks}"

    def near(a, b, tol):
        return abs(a - b) < tol

    checks = []
    # ① 五臂
    for k in ks:
        r = D[k]
        checks.append((f"{k} cos 与 JSON 一致且在报告里",
                       f"{r['cos']['all']:.5f}" in doc))
    # ② 正对照
    e = max(em, key=lambda k: D[k]["route"]["mi"]["excess"])
    o = orc[0]
    RE, RO = D[e]["route"], D[o]["route"]
    checks += [
        ("oracle 的 I(R;P) excess > 0.4（>0.05 阈值 8 倍以上）",
         RO["mi"]["excess"] > 0.4 and RO["mi"]["p_value"] < P_SIG),
        ("oracle 的条件互信息两条都显著",
         all(RO[x]["excess"] > 0.3 and RO[x]["p_value"] < P_SIG
             for x in ("cmi_coarse", "cmi_fine"))),
        ("oracle 切换点命中率显著高于移位零分布",
         RO["switch"]["hit_rate"] > RO["switch"]["null_mean"]
         and RO["switch"]["p_value"] < P_SIG),
        ("涌现臂 I(R;P) excess < 阈值（无可检出信号）",
         abs(RE["mi"]["excess"]) < EXC_SIG),
        ("涌现臂 条件互信息 < 阈值",
         all(abs(RE[x]["excess"]) < EXC_SIG for x in ("cmi_coarse", "cmi_fine"))),
        ("涌现臂 切换点对齐不显著（p ≥ 0.05）",
         (RE["switch"]["p_value"] or 1) >= P_SIG),
        ("oracle 与涌现臂的互信息超出差 ≥ 20×",
         abs(RO["mi"]["excess"]) / max(abs(RE["mi"]["excess"]), 1e-9) >= 20),
        ("报告里写了「测量机器有鉴别力」",
         "测量机器有鉴别力" in doc),
    ]
    # ③ 标签冗余
    checks += [
        ("oracle 的 cos 只比涌现臂高 <0.02（标签冗余）",
         abs(D[o]["cos"]["all"] - D[e]["cos"]["all"]) < 0.02),
        ("报告里写了「标签对单步预测是冗余的」",
         "物理过程标签对单步预测是冗余的" in doc),
    ]
    # ④ 容量对齐
    dh = max(dn, key=lambda k: D[k]["n_params"])
    gap = D[dh]["cos"]["all"] - D[e]["cos"]["all"]
    checks += [
        ("容量对齐（|MoE−dense| / dense < 5%）",
         abs(D[e]["n_params"] - D[dh]["n_params"]) / D[dh]["n_params"] < 0.05),
        # 勘误（输入对齐修正）后净损失由 0.132 变为 0.045，方向不变
        ("容量对齐下 MoE 更差且差距 > 0.03（勘误后幅度）",
         gap > 0.03),
        ("报告里指出了同容量下更差", "同容量下加了路由反而更差" in doc),
    ]
    # ⑤ 均匀路由
    for k in em:
        ent = D[k]["route"]["entropy"]
        checks.append((f"{k} 路由熵 ≈ log B（差 <0.02）",
                       abs(ent - math.log(D[k]["config"]["B"])) < 0.02))
    checks.append(("报告里指出「砍掉负载均衡没有导致塌缩」",
                   "去掉负载均衡没有导致塌缩" in doc))
    # ⑥ 旧读数
    occ = [m.start() for m in re.finditer(r"0\.980", doc)]
    checks.append(("0.980 只作为「已修掉的假象」出现",
                   all(any(k in doc[max(0, i - 120):i + 120]
                           for k in ("假象", "平凡通过", "首版"))
                       for i in occ)))
    checks.append(("各臂 elapsed_s 均为合理训练时长（< 1h，无挂起污染）",
                   all(D[k]["elapsed_s"] < 3600 for k in ks)))
    bad = [n for n, ok in checks if not ok]
    print("=" * 92)
    print("  T2b 数字与文档一致性校验")
    print("=" * 92)
    for n, ok in checks:
        print(f"  [{'✓' if ok else '✗'}] {n}")
    print()
    print(f"  {len(checks)-len(bad)}/{len(checks)} 通过"
          + ("  ✅" if not bad else f"  ❌ 失败：{bad}"))
    print(f"  容量对齐差距 = {gap:+.5f}（dense {D[dh]['cos']['all']:.5f} @ "
          f"{D[dh]['n_params']:,} vs MoE {D[e]['cos']['all']:.5f} @ "
          f"{D[e]['n_params']:,}）")
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
