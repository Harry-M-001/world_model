"""
T2 · 多步 rollout 与崩溃帧标注
=====================================================================
用 T2 的 VAE + 潜空间动力学做自回归 rollout，并标注崩溃帧。

三条必须说清楚的口径问题（否则「崩溃帧数」这个数没有意义）：

1. **崩溃必须相对「VAE 自身的重建误差」来判，不能拿绝对阈值。**
   把真值帧编码再解码本身就有误差（VAE 的误差下限）。rollout 的误差
   只有在明显超过这个下限时才叫「动力学崩了」。所以这里同时画两条曲线：
   预测帧误差 与 VAE 自重建误差。
   像素口径判据：`BCE_t > 5 × median(VAE 自重建 BCE)`，无魔数绝对阈值。
2. **潜空间口径用与 T2 判据相同的 0.9**：`cos(ẑ_t, z_t) < 0.9` 即视为崩。
3. **有真值的步数只有 18 步**（20 帧序列、前 2 帧作上下文）。所以报告写成
   `T_crash > 18（训练视界内未崩）`，而不是编一个数出来。另外做一次
   60 步无真值自由 rollout，只看潜向量范数是否发散（定性）。

顺带给出**经验误差增长率**：对 log‖ẑ_t − z_t‖ 做线性拟合取斜率。
它只是 λ₁ 的量级代理——严格估计是 T3 的任务，这里不越界。

用法：
    python rollout.py [--ctx 2] [--n 64] [--horizon 18] [--free 60]
"""
import argparse
import json
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vae import (CKPT, FIGS, LOGS, LATENT, encode_sequences, load_vae,  # noqa: E402
                 to_img)
from dyn import load_dyn  # noqa: E402
from mvmnist import MovingMNIST, T_FRAMES  # noqa: E402
from guards import G  # noqa: E402

CTX_THRESHOLD = 0.9        # 潜空间崩溃判据（与 T2 单步判据同阈值）
PIXEL_FACTOR = 5.0         # 像素崩溃判据：超过 VAE 自重建误差的 5 倍


def rollout_latents(dyn, mean, std, z_ctx, steps, ctx):
    """自回归预测。z_ctx: (N,ctx,L) 真值上下文；返回 (N,steps,L)。"""
    cur = z_ctx
    out = []
    for _ in range(steps):
        inp = (cur[:, -ctx:] - mean) / std
        p = dyn(inp) * std + mean
        out.append(p)
        cur = torch.cat([cur, p.unsqueeze(1)], dim=1)
    return torch.stack(out, dim=1)


@torch.no_grad()
def decode_pixels(vae, z):
    """(N,T,L) -> (N,T,H,W) 概率图"""
    N, T, L = z.shape
    logits = vae.decode(z.reshape(-1, L))
    return torch.sigmoid(logits).view(N, T, 1, 64, 64)[:, :, 0]


@torch.no_grad()
def run(ctx=2, n_seq=64, horizon=18, free=60, device="cuda"):
    vae = load_vae(device)
    dyn, mean, std = load_dyn(ctx, device)
    mean, std = mean.to(device), std.to(device)

    z_gt = encode_sequences(vae, n_seq, 999, train=False, device=device).to(device)
    T = z_gt.shape[1]
    steps = T - ctx
    assert horizon <= steps, f"horizon 最多 {steps}（真值只有 {T} 帧）"

    pred = rollout_latents(dyn, mean, std, z_gt[:, :ctx], steps, ctx)
    z_true = z_gt[:, ctx:]

    # 逐帧指标
    cos = F.cosine_similarity(pred, z_true, dim=-1)               # (N,steps)
    l2 = (pred - z_true).norm(dim=-1)                              # (N,steps)

    # 像素指标：预测帧 vs 真值帧；以及 VAE 自重建帧 vs 真值帧（误差下限）
    ds = MovingMNIST(n_seq, seed=999, train=False)                 # 只建一次
    seq = torch.stack([ds[i] for i in range(n_seq)])
    x = to_img(seq).to(device)[:, ctx:, 0]                         # (N,steps,H,W)
    px_pred = decode_pixels(vae, pred)
    px_base = decode_pixels(vae, z_true)
    bce = lambda p, t: F.binary_cross_entropy(p.clamp(1e-6, 1 - 1e-6), t,
                                              reduction="none").flatten(1).mean(-1)
    bce_pred = bce(px_pred.reshape(-1, 64, 64), x.reshape(-1, 64, 64)).view(n_seq, steps)
    bce_base = bce(px_base.reshape(-1, 64, 64), x.reshape(-1, 64, 64)).view(n_seq, steps)

    # ---- 崩溃帧标注 ----
    cos_m = cos.mean(0)                                            # (steps,)
    bce_m = bce_pred.mean(0)
    floor = float(bce_base.mean())
    thr = PIXEL_FACTOR * floor
    t_lat = next((i + 1 for i in range(steps) if cos_m[i] < CTX_THRESHOLD), None)
    t_pix = next((i + 1 for i in range(steps) if bce_m[i] > thr), None)

    # G6c：绝对门槛与崩溃阈值不得共用同一个常数。
    # 初版单步判据用 cos≥0.9、崩溃也用 cos<0.9 判 —— 单步一不达标，
    # T_crash 必然 = 1，那是定义上的必然而不是实验发现。
    # G6b：像素口径的「退化基线」就是 VAE 自重建地板自身（=1×阈值单位），
    # 因为阈值是相对量（5×地板），所以它天然有判别力 —— 也顺带证明了
    # 「用相对判据」这个设计选择是对的。
    G.criteria_separation(("单步判据", CTX_THRESHOLD),
                          ("T_crash 像素口径", PIXEL_FACTOR, "relative"))
    G.counterfactual("像素崩溃阈值（单位 = ×VAE 自重建地板）",
                     threshold=PIXEL_FACTOR, degenerate=1.0, direction="min")

    # 每序列的崩溃帧分布（看是不是普遍现象）
    per_seq_lat = [int((cos[i] < CTX_THRESHOLD).nonzero()[0]) + 1
                   if (cos[i] < CTX_THRESHOLD).any() else None for i in range(n_seq)]

    # 经验误差增长率：log‖err‖ 对 t 线性拟合（只用在未饱和段）
    e = l2.mean(0).cpu().numpy()
    k = min(steps, max(3, int(np.argmax(e > e[-1] * 0.5)) if (e > e[-1] * 0.5).any() else steps))
    k = max(3, min(k, steps))
    tt = np.arange(k, dtype=np.float64)
    A = np.vstack([tt, np.ones_like(tt)]).T
    slope, intercept = np.linalg.lstsq(A, np.log(e[:k]), rcond=None)[0]
    resid = np.log(e[:k]) - (A @ np.array([slope, intercept]))
    ss_tot = ((np.log(e[:k]) - np.log(e[:k]).mean()) ** 2).sum()
    r2 = 1 - (resid ** 2).sum() / max(ss_tot, 1e-12)

    # ---- 长程自由 rollout（无真值，只看是否发散）----
    free_norm = None
    if free and free > steps:
        extra = free - steps
        cur = torch.cat([z_gt[:, :ctx], pred], dim=1)
        outs = []
        for _ in range(extra):
            p = dyn((cur[:, -ctx:] - mean) / std) * std + mean
            outs.append(p)
            cur = torch.cat([cur, p.unsqueeze(1)], dim=1)
        allz = torch.cat([z_gt[:, :ctx], pred, torch.stack(outs, 1)], dim=1)
        free_norm = allz.norm(dim=-1).mean(0).cpu().tolist()
        free_norm_gt = z_gt.norm(dim=-1).mean(0).cpu().tolist()

    # 尺度无关的量：误差倍增步数（log2 / 增长率）
    double_steps = float(np.log(2.0) / slope) if slope > 1e-6 else None

    res = dict(ctx=ctx, n_seq=n_seq, steps=steps, horizon=horizon,
               latent_cos=cos_m.cpu().tolist(),
               latent_l2=l2.mean(0).cpu().tolist(),
               pixel_bce=bce_m.cpu().tolist(),
               pixel_bce_vae_floor=bce_base.mean(0).cpu().tolist(),
               vae_floor_mean=floor, pixel_threshold=thr,
               t_crash_latent=t_lat, t_crash_pixel=t_pix,
               per_seq_t_crash=per_seq_lat,
               growth_rate=float(slope), growth_r2=float(r2), growth_fit_steps=int(k),
               error_double_steps=double_steps,
               free_norm=free_norm, free_norm_gt=free_norm_gt)
    return res, dict(x=x.cpu(), px_pred=px_pred.cpu(), z_gt=z_gt.cpu(), pred=pred.cpu(),
                     seq_uint8=seq)


# ------------------------------------------------------------------ 出图
def figures(res, vis, prefix="t2"):
    from figstyle import (setup_matplotlib, dark_axes, legend, BG, FG, MUTED,
                          ACC, ACC2, WARN, DANGER)
    plt = setup_matplotlib()          # 关键：不加挂中文字体，中文标签全变方框
    os.makedirs(FIGS, exist_ok=True)
    bg, fg, muted, acc, acc2, warn, danger = BG, FG, MUTED, ACC, ACC2, WARN, DANGER

    # ---- 图 1：误差曲线 ----
    st = np.arange(1, res["steps"] + 1)
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.6), facecolor=bg)
    for a in ax:
        dark_axes(a)
        a.set_xlabel("rollout step（预测步数）", color=muted)

    ax[0].plot(st, res["latent_cos"], "-o", ms=3.4, color=acc, label="cos(z_pred, z_true)")
    ax[0].axhline(CTX_THRESHOLD, ls="--", lw=1.2, color=warn,
                  label=f"崩溃阈值 cos={CTX_THRESHOLD}")
    if res["t_crash_latent"]:
        ax[0].axvline(res["t_crash_latent"], ls=":", color=danger,
                      label=f"T_crash = {res['t_crash_latent']}")
    ax[0].set_ylabel("潜向量余弦相似度", color=muted)
    ax[0].set_title("潜空间误差", color=fg, fontsize=12)
    legend(ax[0])

    ax[1].plot(st, res["pixel_bce"], "-o", ms=3.4, color=acc, label="rollout 预测帧")
    ax[1].plot(st, res["pixel_bce_vae_floor"], "-s", ms=3.4, color=acc2,
               label="VAE 自重建（误差下限）")
    ax[1].axhline(res["pixel_threshold"], ls="--", lw=1.2, color=warn,
                  label=f"崩溃阈值 = {PIXEL_FACTOR:g}× 下限")
    if res["t_crash_pixel"]:
        ax[1].axvline(res["t_crash_pixel"], ls=":", color=danger,
                      label=f"T_crash = {res['t_crash_pixel']}")
    ax[1].set_yscale("log")
    ax[1].set_ylabel("像素 BCE (nats/px, log)", color=muted)
    ax[1].set_title("像素空间误差", color=fg, fontsize=12)
    legend(ax[1])
    fig.suptitle(f"T2 rollout 误差随步数  |  误差增长率 lambda = {res['growth_rate']:.3f}"
                 f" /步 (R²={res['growth_r2']:.3f}, 拟合前 {res['growth_fit_steps']} 步)",
                 color=fg, fontsize=12)
    p1 = os.path.join(FIGS, f"{prefix}_error_curve.png")
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig(p1, dpi=300, facecolor=bg)
    plt.close(fig)

    # ---- 图 2：真值 vs rollout 帧 ----
    nrow, cols = 4, [2, 4, 6, 8, 10, 12, 14, 16]     # 帧下标（含上下文第 0/1 帧）
    x, px = vis["x"].numpy(), vis["px_pred"].numpy()  # (N,steps,H,W) 下标 = 帧 - ctx
    fig, axes = plt.subplots(8, len(cols), figsize=(len(cols) * 1.28, 11.0), facecolor=bg)
    for r in range(8):
        s = r % 4
        is_pred = r >= 4
        for c, fidx in enumerate(cols):
            a = axes[r, c]
            a.set_facecolor(bg)
            a.set_xticks([])
            a.set_yticks([])
            for sp in a.spines.values():
                sp.set_visible(False)
            if fidx < 2:                                   # 上下文帧只有真值
                # seq_uint8 是 0–255，必须除以 255 归一到 vmin/vmax=0–1，
                # 否则整格被剪切为纯黑。
                img = vis["seq_uint8"][s, fidx].numpy().astype(float) / 255.0
                a.text(.5, 1.14, "", transform=a.transAxes)
            else:
                j = fidx - 2
                # 注意 x / px 都是 (N,steps,H,W)，x[s,j] 已经是 (H,W)，
                # 再切 [0] 会只剩第一行 —— 出图会变成一条细线。
                # 统一约定：值越大 = 墨迹越多 → gray_r 下越黑。
                # 预测不做 1-img 反相（反相会使墨迹变白，与真值行相反）。
                img = (px[s, j] if is_pred else x[s, j]).astype(float)
            a.imshow(img, cmap="gray_r", vmin=0, vmax=1, interpolation="nearest")
            if c == 0:
                a.set_ylabel(("预测\n" if is_pred else "真值\n") + f"seq{s}",
                             color=(danger if is_pred else acc2), fontsize=9, rotation=0,
                             ha="right", va="center", labelpad=16)
            if r == 0:
                a.set_title(f"t={fidx}", color=muted, fontsize=9)
    fig.suptitle("上 4 行 = 真值帧 ；下 4 行 = rollout 预测（自回归，无真值输入）\n"
                 "列 0–1 为上下文（只有真值）", color=fg, fontsize=11)
    p2 = os.path.join(FIGS, f"{prefix}_rollout.png")
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    fig.savefig(p2, dpi=300, facecolor=bg)
    plt.close(fig)

    # ---- 图 3：长程自由 rollout 的潜向量范数 ----
    p3 = None
    if res.get("free_norm"):
        fn, gt = res["free_norm"], res["free_norm_gt"]
        fig, a = plt.subplots(figsize=(7.2, 3.6), facecolor=bg)
        dark_axes(a)
        a.plot(range(len(fn)), fn, color=danger, label="自由 rollout ‖z_pred‖")
        a.plot(range(len(gt)), gt, color=acc2, label="真值 ‖z_true‖（只有前 20 步）")
        a.axvline(res["steps"] + 2, ls=":", color=warn, label="真值视界结束")
        a.set_xlabel("步数", color=muted)
        a.set_ylabel("平均潜向量范数", color=muted)
        a.set_title("长程自由 rollout：潜向量范数是否发散", color=fg, fontsize=12)
        legend(a)
        p3 = os.path.join(FIGS, f"{prefix}_free_rollout.png")
        fig.tight_layout()
        fig.savefig(p3, dpi=300, facecolor=bg)
        plt.close(fig)
    return p1, p2, p3


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ctx", type=int, default=2)
    ap.add_argument("--n", type=int, default=64)
    ap.add_argument("--horizon", type=int, default=18)
    ap.add_argument("--free", type=int, default=60)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    a = ap.parse_args()
    os.makedirs(LOGS, exist_ok=True)
    res, vis = run(a.ctx, a.n, a.horizon, a.free, a.device)
    p1, p2, p3 = figures(res, vis)

    steps = res["steps"]
    print("=" * 74)
    print("  T2 · 多步 rollout 与崩溃帧标注")
    print("=" * 74)
    print(f"  序列 {res['n_seq']} 条 · 上下文 {res['ctx']} 帧 · 有真值的预测步数 {steps}")
    print(f"  VAE 自重建误差下限（像素 BCE）{res['vae_floor_mean']:.4f} "
          f"→ 像素崩溃阈值 {res['pixel_threshold']:.4f}（{PIXEL_FACTOR:g}×）")
    print("-" * 74)
    print(f"  {'step':>4} {'潜 cos':>9} {'潜 L2':>9} {'像素 BCE':>10} {'VAE 下限':>10}")
    for i in range(steps):
        mark = ""
        if res["t_crash_latent"] and i + 1 == res["t_crash_latent"]:
            mark += "  <- 潜空间崩"
        if res["t_crash_pixel"] and i + 1 == res["t_crash_pixel"]:
            mark += "  <- 像素崩"
        print(f"  {i+1:>4} {res['latent_cos'][i]:>9.5f} {res['latent_l2'][i]:>9.4f} "
              f"{res['pixel_bce'][i]:>10.5f} {res['pixel_bce_vae_floor'][i]:>10.5f}{mark}")
    print("-" * 74)
    tl, tp = res["t_crash_latent"], res["t_crash_pixel"]
    print(f"  T_crash（潜空间口径 cos<{CTX_THRESHOLD}）: "
          + (f"第 {tl} 步" if tl else f"> {steps}（真值视界内未触发）"))
    print(f"  T_crash（像素口径 >{PIXEL_FACTOR:g}×VAE 下限）: "
          + (f"第 {tp} 步" if tp else f"> {steps}（真值视界内未触发）"))
    ncrash = sum(1 for v in res["per_seq_t_crash"] if v)
    print(f"  逐序列：{ncrash}/{res['n_seq']} 条在 {steps} 步内出现潜空间崩溃")
    print(f"  经验误差增长率 λ̂ ≈ {res['growth_rate']:.4f} /步 "
          f"(log‖err‖~t 线性拟合前 {res['growth_fit_steps']} 步, R²={res['growth_r2']:.3f})")
    if res["error_double_steps"]:
        print(f"  误差倍增步数 ≈ {res['error_double_steps']:.2f} 步"
              f"（log2/λ̂，尺度无关，可跨模型比较）")
    if res["free_norm"]:
        f60 = res["free_norm"][-1]
        g20 = max(res["free_norm_gt"])
        print(f"  长程自由 rollout：60 步后 ‖ẑ‖ = {f60:.2f}，"
              f"真值 ‖z‖ 峰值 {g20:.2f} → " + ("发散" if f60 > 3 * g20 else "未发散"))
    print("-" * 74)
    print(f"  图: {p1}\n      {p2}" + (f"\n      {p3}" if p3 else ""))
    print("=" * 74)
    with open(os.path.join(LOGS, "t2_rollout.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
