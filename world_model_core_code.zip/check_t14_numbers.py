# -*- coding: utf-8 -*-
"""T14 数字一致性校验（形状修复后口径）：论文 tex 与 results.md 的数字必须能从 JSON 复算。

口径说明：
  · 448 条 rollout，207 条（46.2%）在 40 步内崩溃，其余删失；真值 [1,37]、26 档
  · 平凡基线：常数预测 T=6，命中率 83.1%
  · A1 两种 η：Δ/2 版 81.2%/−1.29；实测 η 版 73.4%/−4.04
  · A2a 57.0%/+0.39；A2b 24.6%/−0.81；A3 Laya 71.0%/39 误报/−5.22（离线重测）
  · MoE 探针修复后 2.96×（与 δ 无关），原 147× 读数撤回
"""
import json
import os
import re
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
TEX = os.path.join(ROOT, "paper", "main_chinaxiv_v3.tex")
RES = os.path.join(ROOT, "paper", "results.md")


def load(name):
    return json.load(open(os.path.join(ROOT, "logs", name), encoding="utf-8"))


def main():
    tex = open(TEX, encoding="utf-8").read()
    res = open(RES, encoding="utf-8").read()
    doc = tex + "\n" + res
    Dd = load("t14_warn_dense_h480_act.json")
    cfg, arms = Dd["config"], {a["arm"]: a for a in Dd["arms"]}
    moe_fixed = load("t14_moe_jump_probe_fixed.json")
    checks = []

    def C(name, ok):
        checks.append((name, bool(ok)))

    # ---- 日志复算：崩溃数、真值范围、平凡基线 ----
    crashes = [r["crash"] for r in Dd["rows"]]
    n_crash = sum(1 for c in crashes if c is not None)
    C("207/448 崩溃（日志复算）", n_crash == 207)
    cc_full = np.array([c for c in crashes if c is not None], float)
    tv = sorted(set(cc_full.tolist()))
    C("真值 [1,37]、26 档（日志复算）", tv[0] == 1 and tv[-1] == 37 and len(tv) == 26)
    best = max(range(1, 38), key=lambda k: (np.abs(cc_full - k) <= cfg["hit_w"]).mean())
    rate = (np.abs(cc_full - best) <= cfg["hit_w"]).mean()
    C("平凡基线 T=6、83.1%（日志复算）", best == 6 and abs(rate - 0.831) < 0.001)

    # ---- 论文文字 ----
    C("207 条/46.2% 在案", "207 条" in doc and "46.2" in doc)
    C("删失 53.8% 在案", "53.8" in doc)
    C("真值 [1,37]、26 档在案", "[1,37]" in doc and "26 档" in doc)
    C("平凡基线 83.1% 在案", "83.1" in doc)
    C("孪生 λ 0.532±0.007 在案", "0.532" in doc and "0.007" in doc
      and abs(cfg["lam"] - 0.5323) < 0.001)

    # ---- 四臂 ----
    C("A1 Δ/2 81.2%/−1.29 与日志一致",
      abs(arms["A1解析"]["hit_rate"] - 0.812) < 0.001
      and abs(arms["A1解析"]["mean_err"] + 1.29) < 0.01 and "81.2" in doc)
    C("A2a 57.0%/+0.39 与日志一致",
      abs(arms["A2a范数"]["hit_rate"] - 0.570) < 0.001
      and abs(arms["A2a范数"]["mean_err"] - 0.39) < 0.01 and "57.0" in doc)
    C("A2b 24.6%/−0.81 与日志一致",
      abs(arms["A2b二阶差分"]["hit_rate"] - 0.246) < 0.001
      and abs(arms["A2b二阶差分"]["mean_err"] + 0.81) < 0.01 and "24.6" in doc)
    C("实测 η 版 73.4%/−4.04 在案", "73.4" in doc and "4.04" in doc)
    C("A3 Laya 71.0%/39 误报/−5.22 与日志一致",
      Dd.get("laya_available") is True
      and abs(arms["A3Laya"]["hit_rate"] - 0.710) < 0.001
      and arms["A3Laya"]["false_alarm"] == 39
      and abs(arms["A3Laya"]["mean_err"] + 5.22) < 0.02
      and "71.0" in doc and "5.22" in doc)

    # ---- 撤回与勘误 ----
    C("原结论撤回在案", "一条 if 语句就够了”撤回" in doc or "原“一条 if 语句就够了”撤回" in doc)
    C("形状错误原因（cat/stack）在案", "torch.cat" in doc and "torch.stack" in doc)

    # ---- MoE 探针修复 ----
    C("MoE 修复后 2.96× 与日志一致",
      all(abs(v - 2.96) < 0.01 for v in moe_fixed.values()) and "2.96" in doc)
    C("147 倍跳变已撤回（仅出现在勘误语境）",
      doc.count("147") == 0 or "147 倍跳变" in doc.replace("147×", "147 倍"))
    C("未观测到跳变在案", "未观测到跳变" in doc)

    # ---- 卫生 ----
    C("tex 无残留占位符（TODO/TBD/XXX）", not re.search(r"TODO|TBD|FIXME|XXX", tex))
    C("无旧 λ 0.955 残留", "0.955" not in doc and "0.9552" not in doc)

    n_ok = sum(1 for _, ok in checks if ok)
    for name, ok in checks:
        print(f"  [{'✓' if ok else '✗'}] {name}")
    print(f"\n{n_ok}/{len(checks)} 通过")
    return 0 if n_ok == len(checks) else 1


if __name__ == "__main__":
    sys.exit(main())
