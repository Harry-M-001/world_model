"""校验 paper/introduction.md 与 T5 报告中的关键数值是否与 logs/*.json 一致。"""
import json
import math
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def L(n):
    p = os.path.join(ROOT, "logs", n)
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}


intro = open(os.path.join(ROOT, "paper", "introduction.md"), encoding="utf-8").read()
rc, rc2, t3, t3c, t5 = (L("recheck_tcrash.json"), L("recheck_tcrash2.json"),
                        L("t3_lyap.json"), L("t3c_koopman.json"), L("t5_alloc.json"))
alls = L("all_fits_recheck.json")
ro = L("t2_rollout.json")

dt = rc.get("D_truth", {})
stab = rc2.get("stab", {})
sat = rc2.get("sat", {})
A = rc.get("A_floor", {})

# b* 由 sat 的 δ_∞ 越过 1 的位置估出
def bstar(arm):
    rows = sat.get(arm, {}).get("rows", [])
    above = [r["bits"] for r in rows if r["delta_inf_med"] is not None and r["delta_inf_med"] >= 1.0]
    below = [r["bits"] for r in rows if r["delta_inf_med"] is not None and r["delta_inf_med"] < 1.0]
    return (max(above), min(below)) if above and below else (None, None)


sl_single = np_mean = None


def mean_std(arm, key="lam_main"):
    v = [r[key] for r in stab.get(arm, [])]
    if not v:
        return None, None, None, None
    m = sum(v) / len(v)
    sd = (sum((x - m) ** 2 for x in v) / len(v)) ** 0.5
    return m, sd, min(v), max(v)


ms = mean_std("multistep")
sg = mean_std("single")
bs_s = bstar("single")
bs_m = bstar("multistep")

# multistep 越阈率 b=10 与 b=18
sat_ms = {r["bits"]: r for r in sat.get("multistep", {}).get("rows", [])}
rate10 = sat_ms.get(10, {}).get("n", 0) / 32 * 100
rate18 = sat_ms.get(18, {}).get("n", 0) / 32 * 100

# 斜率区间
slopes = []
for name, g in alls.get("results", {}).items():
    for k in ("all", "no_floor", "F_C"):
        v = g.get(k)
        if isinstance(v, dict) and v.get("slope"):
            slopes.append(v["slope"])
# 需要 7.34（新数据 F+C）—— 从 recheck 的 long_window 也算一遍
lw = rc.get("B_arms", {})
msrows = lw.get("multistep", {}).get("rows", [])
def fit(pts):
    x = [p[0] for p in pts]; y = [p[1] for p in pts]
    n = len(x); mx = sum(x) / n; my = sum(y) / n
    sxy = sum((a - mx) * (b - my) for a, b in pts); sxx = sum((a - mx) ** 2 for a in x)
    return sxy / sxx


fc = [(r["bits"], r["med_d1"]) for r in msrows
      if r["med_d1"] is not None and r["delta"] / 2 <= 1 and
      r["censored_d1"] / max(r["n_d1"] + r["censored_d1"], 1) <= 0.10]
sl_fc = fit(fc) if len(fc) >= 3 else None

checks = [
    ("真值折算 0.04541", abs(dt.get("lam1_step", 0) - 0.04541) < 5e-5),
    ("真值连续 0.9082±0.0065", abs(dt.get("lam1_cont_mean", 0) - 0.9082) < 5e-4
     and abs(dt.get("lam1_cont_std", 0) - 0.0065) < 5e-4),
    ("和检验 ≤1e-4", dt.get("sum_check_max_err", 1) <= 1.1e-4),
    ("floor 42/42", A.get("agree") == "42/42"),
    ("MM λ₁ −0.0468±0.003", abs(t3["reconcile"]["qr"] + 0.0468) < 5e-5
     and abs(t3["qr"]["lam1_std"] - 0.003) < 5e-4),
    ("λ̂ +0.3254", abs(ro.get("growth_rate", 0) - 0.3254) < 1e-4),
    ("multistep λ₁ −0.0029±0.0038", ms[0] is not None and abs(ms[0] + 0.0029) < 5e-4
     and abs(ms[1] - 0.0038) < 5e-4),
    ("single λ₁ −0.45±0.90 范围[−2.26,0.0001]", sg[0] is not None and abs(sg[0] + 0.45) < 0.02
     and abs(sg[1] - 0.90) < 0.02 and abs(sg[2] + 2.26) < 0.02 and abs(sg[3] - 0.0001) < 1e-4),
    ("b* single≈17", bs_s[0] == 16 and bs_s[1] == 18),
    ("b* multistep≈11", bs_m[0] == 10 and bs_m[1] == 12),
    ("multistep 越阈 90%→12%", abs(rate10 - 90.6) < 1 and abs(rate18 - 12.5) < 1),
    ("斜率 F+C 新数据 ≈7.34", sl_fc is not None and abs(sl_fc - 7.34) < 0.05),
    ("斜率 13.88 / 20.80（统一复核）+ 24.56（旧窗口 b≥8）",
     all(any(abs(s - v) < 0.02 for s in slopes) for v in (13.88, 20.80))
     and abs(rc["A2_refit"]["multistep"]["仅 b≥8"]["slope"] - 24.56) < 0.02),
    ("外推 −94.5", abs(rc.get("A2_refit", {}).get("_extrapolation", {}).get("slope", 0) - 30.0) < 0.1),
    ("Koopman 解析一致 3.5e-9", abs(t3c["arms"][1].get("qr_vs_log", 1) - 3.5e-9) < 1e-9),
    ("纯线性 cos 0.71", abs(t3c["arms"][1]["val_cos"] - 0.70668) < 0.001),
    ("T5 dyn@b4 vs enc@b4 = 14.3% / 1.1%",
     abs((t5["baseline"]["obs_cos"] - t5["phase_id"]["dyn"][1]["obs_cos"])
         / t5["baseline"]["obs_cos"] * 100 - 14.3) < 0.1
     and abs((t5["baseline"]["obs_cos"] - t5["phase_id"]["enc"][1]["obs_cos"])
             / t5["baseline"]["obs_cos"] * 100 - 1.1) < 0.1),
    ("T5 预算最优 (6,10) 损失 0.02%",
     min(t5["phase_budget"], key=lambda r: r["loss_pct"])["bits_enc"] == 6
     and abs(min(t5["phase_budget"], key=lambda r: r["loss_pct"])["loss_pct"] - 0.02) < 0.005),
    ("T5 (12,4) 灾难 14.33%",
     abs(max(t5["phase_budget"], key=lambda r: r["loss_pct"])["loss_pct"] - 14.33) < 0.01),
]
bad = [n for n, ok in checks if not ok]
print(f"引言关键数值核对 {len(checks)} 项：", "全部通过 ✅" if not bad else f"失败 {bad}")
print()
print(f"  参考：b* single = ({bs_s[0]}, {bs_s[1]})  multistep = ({bs_m[0]}, {bs_m[1]})")
print(f"  multistep 越阈率 b=10 {rate10:.1f}%  b=18 {rate18:.1f}%")
print(f"  F+C 新数据斜率 {sl_fc:.2f}" if sl_fc else "  F+C 斜率不足 3 点")
print(f"  历史斜率集合 min {min(slopes):.2f} max {max(slopes):.2f}")

# 顺带核对引言里出现的字面数字是否都在清单里（防手抄新数字）
nums = set(re.findall(r"\b\d+\.\d{2,5}\b", intro))
known = {"0.04541", "0.0038", "0.003", "0.0029", "0.45", "0.90", "2.26", "0.0001",
         "0.0468", "0.3254", "1.15", "1.71", "7.34", "24.56", "94.5", "14.3", "1.1",
         "14.33", "3.5", "0.71", "0.02", "2.17", "0.4", "20000", "0.99",
         # 形状修复后新增
         "2.96", "0.532", "0.233", "1.125", "0.74", "1.36", "1.43", "0.68", "0.32",
         "0.083", "0.021", "4.04", "1.29", "0.39", "0.81", "0.26", "0.0053", "0.00034"}
extra = sorted(n for n in nums if n not in known)
print("  引言中未被清单覆盖的数字：", extra if extra else "（无）")
