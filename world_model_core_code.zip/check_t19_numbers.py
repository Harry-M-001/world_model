# -*- coding: utf-8 -*-
"""T19 报告数字校验：报告数字必须能从 JSON 复算。"""
import json
import os
import _paths  # noqa: E402
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DOC = _paths.phase1("T19_Pareto扫描.md")


def main():
    D = json.load(open(os.path.join(ROOT, "logs", "t19_pareto.json"),
                       encoding="utf-8"))
    doc = open(DOC, encoding="utf-8").read()
    checks = []

    def C(name, ok):
        checks.append((name, bool(ok)))

    res = D["results"]
    C("12 配置全在表中", len(res) == 12 and
      all(f"{r['tag']} k={r['k']}" in doc for r in res))
    C("随机基线读数一致", f"{D['random_success']*100:.1f}%" in doc)
    best = max(res, key=lambda r: r["success"])
    C("最优配置读数一致", f"{best['success']*100:.1f}%" in doc)
    h480k1 = next(r for r in res if r["tag"] == "dense_h480_act" and r["k"] == 1)
    C("h480-k1 4.2% 在案", f"{h480k1['success']*100:.1f}%" in doc
      and h480k1["success"] < D["random_success"])
    C("否证一结论在案", "这个轴在本任务上不起作用" in doc)
    C("否证二（随机高于全部规划）在案", "高于全部 12 个规划配置" in doc)
    C("选择偏差机制在案", "选择偏差" in doc)
    C("弱版本（小模型够用）在案", "h480 全被支配" in doc)
    C("Pareto 前沿在案", "h192-k8（20.8% @ 7.2e7）" in doc)
    C("统计功效标注", "Fisher p ≈ 0.34" in doc and "p ≈ 0.006" in doc)
    C("与 T14 同族结论在案", "先建对照（随机基线），再谈智能组件的价值" in doc)
    C("边界标注（单任务/单实现）", "举证责任在提出者一侧" in doc)
    C("无残留占位符", not re.findall(r"\{[a-z_]+\}", doc))
    C("粗体成对", doc.count("**") % 2 == 0)

    n_ok = sum(1 for _, ok in checks if ok)
    for name, ok in checks:
        print(f"  [{'✓' if ok else '✗'}] {name}")
    print(f"\n{n_ok}/{len(checks)} 通过")
    return 0 if n_ok == len(checks) else 1


if __name__ == "__main__":
    sys.exit(main())
