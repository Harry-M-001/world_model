"""
T15 · 动作条件化基线

目标：把「无动作条件的渲染器」变成「能被动作驱动的世界模型」—— 这是世界模型的**第一条判据**。

设计约束（先机制后现象）
--------------------------------------
* **不引入新的物理现象**：仍是「匀速运动 + 等距反射」，只把速度改由**动作指令**驱动。
* 动作接口：a_t ∈ {−1,0,+1}²（每轴加速度指令），**全局作用于两个数字**（场景级控制）
      v_{t+1} = clip(v_t + a_t·a_max, −v_max, +v_max)
      x_{t+1} = x_t + v_{t+1}          （碰壁则反射，与原生成器完全一致）

* **真值 λ₁ 仍为 0（可解析验证）**：未饱和时 (x,v) ↦ (x+v', v') 的雅可比为
      J = [[1, ∂v'/∂v], [0, ∂v'/∂v]] = [[1,1],[0,1]]，特征值 {1,1} → λ=0；
      饱和（clip 生效）时 ∂v'/∂v = 0 → 特征值 {1,0}，λ₁ = 0 仍成立。
  → **动作条件化不改变真值 λ₁，只是把状态轨迹变成由动作驱动**
    ⇒ T4/T5/T7 的误差递推 δ_{t+1} = e^λ·δ_t + η 在动作条件下无需修改即成立。

四个判据（全部可机检）
----------------------
 ① 动作敏感性：同一状态下换动作，预测应显著改变。**对照：无条件模型（看不到动作）敏感性 ≈ 0**
 ② 动作可分性：从「预测的变化量」能否反推动作 —— 需显著高于随机基线 1/9
 ③ 反事实一致性（第三条判据的雏形）：同初值 + 不同动作序列 → 轨迹分歧，且方向正确
 ④ 量化敏感性（接回主线）：动作条件模型的 QR λ₁（条件于动作序列）是否仍 ≈ 0

产物 logs/t15_action.json
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from vae import LATENT, CKPT, load_vae          # noqa: E402
from t4b_arms import qr_lam1                    # noqa: E402
from guards import G                            # noqa: E402

DEV = "cuda" if torch.cuda.is_available() else "cpu"
H = W = 64
DIGIT = 28
T_FRAMES, N_DIGIT = 20, 2
CTX, EPOCHS, BATCH = 2, 600, 2048
V_MAX, A_MAX = 3, 1
N_TRAIN, N_VAL = 4000, 256
SPEEDS = (1, 2, 3)
OUT = os.path.join(ROOT, "logs", "t15_action.json")


# ------------------------------------------------------------------ 生成器
def make_seq_act(digits, rng, n_frames=T_FRAMES, n_digit=N_DIGIT,
                 v_max=V_MAX, a_max=A_MAX):
    """动作条件生成器。返回 (frames (T,64,64) uint8, actions (T,2) int8)。

    与 make_seq_gray 的唯一差别：速度不是常数，而是由动作指令逐步驱动。
    """
    frames = np.zeros((n_frames, H, W), dtype=np.uint8)
    actions = np.zeros((n_frames, 2), dtype=np.int8)
    lim, limy = W - DIGIT, H - DIGIT
    order = rng.permutation(len(digits))[:n_digit]
    st = {}
    for k in order:
        st[k] = dict(d=digits[k],
                     xf=float(rng.integers(0, lim + 1)),
                     yf=float(rng.integers(0, limy + 1)),
                     vx=float(int(rng.choice(SPEEDS)) * int(rng.choice((-1, 1)))),
                     vy=float(int(rng.choice(SPEEDS)) * int(rng.choice((-1, 1)))))
    for t in range(n_frames):
        for k in order:                                   # 先渲染当前帧
            s = st[k]
            xi = int(min(max(round(s["xf"]), 0), lim))
            yi = int(min(max(round(s["yf"]), 0), limy))
            np.maximum(frames[t, yi:yi + DIGIT, xi:xi + DIGIT], s["d"], out=
                       frames[t, yi:yi + DIGIT, xi:xi + DIGIT])
        a = rng.integers(-a_max, a_max + 1, size=2)       # 全局动作
        actions[t] = a
        for k in order:                                   # 再用动作推进
            s = st[k]
            s["vx"] = float(np.clip(s["vx"] + a[0], -v_max, v_max))
            s["vy"] = float(np.clip(s["vy"] + a[1], -v_max, v_max))
            s["xf"] += s["vx"]
            s["yf"] += s["vy"]
            if s["xf"] < 0 or s["xf"] > lim:
                s["vx"] = -s["vx"]
                s["xf"] = min(max(s["xf"], 0.0), float(lim))
            if s["yf"] < 0 or s["yf"] > limy:
                s["vy"] = -s["vy"]
                s["yf"] = min(max(s["yf"], 0.0), float(limy))
    return frames, actions


def build_dataset(n, seed, train):
    """返回 (frames (n,T,64,64) uint8, actions (n,T,2) int8)"""
    from variant2 import GRAY
    digits = GRAY[train]
    F_, A_ = [], []
    for i in range(n):
        rng = np.random.default_rng((seed * 1_000_003 + i) % (2 ** 32))
        f, a = make_seq_act(digits, rng)
        F_.append(f)
        A_.append(a)
    return np.stack(F_), np.stack(A_)


# ------------------------------------------------------------------ 模型
class ActDynamics(nn.Module):
    """ẑ_{t+1} = 匀速外推 + 动作线性项 + 网络残差。

    动作显式进入**线性项**（A @ a），因为真值里速度的变化 Δv = a 会直接反映到
    状态的二阶差分上；网络只需学碰壁这类非线性残差。零初始化保持与原 dyn 同构。
    """

    def __init__(self, latent=LATENT, ctx=CTX, hidden=512, n_act=2):
        super().__init__()
        self.ctx, self.latent, self.n_act = ctx, latent, n_act
        self.A = nn.Parameter(torch.zeros(latent, n_act))
        self.net = nn.Sequential(
            nn.Linear(latent * ctx + n_act, hidden), nn.SiLU(),
            nn.Linear(hidden, hidden), nn.SiLU(),
            nn.Linear(hidden, latent))
        nn.init.zeros_(self.net[-1].weight)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, zc, a):
        zt, prev = zc[:, -1], zc[:, -2]
        base = zt + (zt - prev) + a @ self.A.T
        return base + self.net(torch.cat([zc.flatten(1), a], 1))


def encode_all(vae, frames):
    """frames (n,T,64,64) uint8 -> z (n,T,LATENT) float32"""
    n, T = frames.shape[0], frames.shape[1]
    out = []
    with torch.no_grad():
        x = torch.from_numpy(frames).float().div_(255.0).reshape(-1, H, W)
        for i in range(0, x.shape[0], 512):
            out.append(vae.encode_det(x[i:i + 512].unsqueeze(1).to(DEV)).cpu())
    return torch.cat(out).view(n, T, LATENT)


def train_act(ztr, atr, mean, std, epochs=EPOCHS, seed=0, verbose=True):
    torch.manual_seed(seed)
    n, T = ztr.shape[0], ztr.shape[1]
    ii, tt = torch.meshgrid(torch.arange(n), torch.arange(CTX, T - 1), indexing="ij")
    ii, tt = ii.reshape(-1).to(DEV), tt.reshape(-1).to(DEV)
    m = ActDynamics().to(DEV)
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=1e-4)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    n_idx = ii.shape[0]
    t0 = time.time()
    ii_c, tt_c = ii.cpu(), tt.cpu()
    for ep in range(epochs):
        perm = torch.randperm(n_idx)[:min(n_idx, 105 * BATCH)]
        for i0 in range(0, perm.numel(), BATCH):
            sel = perm[i0:i0 + BATCH]
            bi, bt = ii_c[sel], tt_c[sel]                          # 索引留 CPU
            ca = ((ztr[bi, bt - 1].to(DEV) - mean) / std).unsqueeze(1)
            cb = ((ztr[bi, bt].to(DEV) - mean) / std).unsqueeze(1)
            zc = torch.cat([ca, cb], dim=1)                       # (B,2,L)
            a = atr[bi, bt].float().to(DEV)                       # (B,2)
            tgt = ztr[bi, bt + 1].to(DEV)
            pred = m(zc, a) * std + mean
            loss = F.mse_loss(pred, tgt)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(m.parameters(), 5.0)
            opt.step()
        sch.step()
    if verbose:
        print(f"    训练完成 {time.time()-t0:.0f}s")
    return m


# ------------------------------------------------------------------ 评估
def single_step(m, zva, ava, mean, std, take=32):
    n, T = zva.shape[0], zva.shape[1]
    ii, tt = torch.meshgrid(torch.arange(n), torch.arange(CTX, T - 1), indexing="ij")
    ii, tt = ii.reshape(-1)[:take * 64], tt.reshape(-1)[:take * 64]   # 索引留 CPU
    ca = ((zva[ii, tt - 1].to(DEV) - mean) / std).unsqueeze(1)
    cb = ((zva[ii, tt].to(DEV) - mean) / std).unsqueeze(1)
    zc = torch.cat([ca, cb], dim=1)
    a = ava[ii, tt].float().to(DEV)
    with torch.no_grad():
        pred = m(zc, a) * std + mean
        tgt = zva[ii, tt + 1].to(DEV)
    return float(F.cosine_similarity(pred, tgt, dim=-1).mean())


def act_sensitivity(m, zva, ava, mean, std, n=2048):
    """判据①：固定状态，遍历 9 个动作 → 预测的分散度（相对自身尺度）。"""
    n, T = zva.shape[0], zva.shape[1]
    rng = np.random.default_rng(0)
    ii = torch.as_tensor(rng.integers(0, n, 512))
    tt = torch.as_tensor(rng.integers(CTX, T - 2, 512))
    ca = ((zva[ii, tt - 1].to(DEV) - mean) / std).unsqueeze(1)
    cb = ((zva[ii, tt].to(DEV) - mean) / std).unsqueeze(1)
    zc = torch.cat([ca, cb], dim=1)
    Acts = torch.tensor([[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 0],
                         [0, 1], [1, -1], [1, 0], [1, 1]], dtype=torch.float32, device=DEV)
    preds = []
    with torch.no_grad():
        for a in Acts:
            aa = a.expand(zc.shape[0], 2)
            preds.append((m(zc, aa) * std + mean))
    P = torch.stack(preds)                       # (9, B, L)
    spread = P.std(dim=0).norm(dim=-1)           # (B,) 跨动作的分散度
    scale = P.mean(dim=0).norm(dim=-1)           # (B,)
    rel = (spread / scale.clamp_min(1e-6)).mean()
    # 同时给「沿动作轴方向」的位移：动作 a 与预测投影的相关系数
    d = P[8] - P[0]                              # 动作 (+1,+1) vs (-1,-1)
    return dict(rel_spread=float(rel), mean_spread=float(spread.mean()),
                scale=float(scale.mean()),
                norm_a11_minus_am1m1=float(d.norm(dim=-1).mean()))


def act_classify(m, zva, ava, mean, std, n=2048):
    """判据②：从「预测的变化量」反推动作，最近邻分类，随机基线 1/9。"""
    n_, T = zva.shape[0], zva.shape[1]
    rng = np.random.default_rng(1)
    ii = torch.as_tensor(rng.integers(0, n_, 1024))
    tt = torch.as_tensor(rng.integers(CTX, T - 2, 1024))
    ca = ((zva[ii, tt - 1].to(DEV) - mean) / std).unsqueeze(1)
    cb = ((zva[ii, tt].to(DEV) - mean) / std).unsqueeze(1)
    zc = torch.cat([ca, cb], dim=1)
    Acts = [(x, y) for x in (-1, 0, 1) for y in (-1, 0, 1)]
    with torch.no_grad():
        a0 = torch.zeros(zc.shape[0], 2, device=DEV)
        base = (m(zc, a0) * std + mean)
        diffs = {}
        for k, (x, y) in enumerate(Acts):
            a = torch.tensor([x, y], dtype=torch.float32, device=DEV).expand(zc.shape[0], 2)
            diffs[k] = ((m(zc, a) * std + mean) - base).cpu()
    # 用真动作的索引做「最近邻」：给定观测到的 diff，找最接近的模板
    true_k = torch.as_tensor([Acts.index((int(ava[ii[j], tt[j], 0]),
                                          int(ava[ii[j], tt[j], 1]))) for j in range(ii.numel())])
    # （ii/tt 已在 CPU，ava 也在 CPU，索引合法）
    # obs[j] = 「第 j 个样本在它的真动作下的预测变化」——必须逐样本取，
    # 早前写成 diffs[int(k)] 取的是整个 batch，形状 (B,B,L)，导致准确率退化为随机
    obs = torch.stack([diffs[int(true_k[j])][j] for j in range(true_k.numel())])
    D = torch.stack([(obs - diffs[k]).norm(dim=-1) for k in range(9)], dim=1)  # (B,9)
    pred_k = D.argmin(dim=1)
    acc = float((pred_k == true_k).float().mean())
    # 对照：用无条件位移（即 base 与均值之差）来分类 —— 说明「不看动作也能猜」的程度
    return dict(acc=acc, chance=1 / 9, n=int(ii.numel()))


def counterfactual(m, zva, ava, mean, std, steps=12, n=64):
    """判据③：同一初值，三条动作序列 → 轨迹分歧，且方向正确。"""
    seqs = {"all_plus": (1, 1), "all_minus": (-1, -1), "all_zero": (0, 0)}
    out = {}
    for name, (ax, ay) in seqs.items():
        with torch.no_grad():
            ca = ((zva[:n, 0].to(DEV) - mean) / std).unsqueeze(1)
            cb = ((zva[:n, 1].to(DEV) - mean) / std).unsqueeze(1)
            zc = torch.cat([ca, cb], dim=1)
            traj = []
            a = torch.tensor([ax, ay], dtype=torch.float32, device=DEV).expand(n, 2)
            for _ in range(steps):
                p = m(zc, a)
                traj.append(p * std + mean)
                zc = torch.cat([zc[:, 1:], p.unsqueeze(1)], dim=1)
            P = torch.stack(traj)                      # (steps, n, L)
        out[name] = P
    # 轨迹终点的差异（潜空间距离）
    dp = (out["all_plus"][-1] - out["all_zero"][-1]).norm(dim=-1).mean()
    dm = (out["all_minus"][-1] - out["all_zero"][-1]).norm(dim=-1).mean()
    div = (out["all_plus"][-1] - out["all_minus"][-1]).norm(dim=-1).mean()
    return dict(plus_vs_zero=float(dp), minus_vs_zero=float(dm),
                plus_vs_minus=float(div),
                direction_ok=bool(dp > dm))


def lam1_conditional(m, zva, ava, mean, std, take=32):
    """判据④：条件 λ₁。把 (z, z_prev, a) 视为增广状态，对 z 求 QR 谱。

    非自治系统的 λ₁ 按给定动作序列定义：λ₁ = lim (1/T)Σ log‖∂f/∂z‖。
    """
    from lyap import qr_spectrum_map
    W1 = m.net[0].weight.detach().cpu().numpy().astype(np.float64)
    b1 = m.net[0].bias.detach().cpu().numpy().astype(np.float64)
    W2 = m.net[2].weight.detach().cpu().numpy().astype(np.float64)
    b2 = m.net[2].bias.detach().cpu().numpy().astype(np.float64)
    W3 = m.net[4].weight.detach().cpu().numpy().astype(np.float64)
    b3 = m.net[4].bias.detach().cpu().numpy().astype(np.float64)
    A = m.A.detach().cpu().numpy().astype(np.float64)
    sm = std.detach().cpu().numpy().astype(np.float64)
    mn = mean.detach().cpu().numpy().astype(np.float64)
    L = LATENT

    def f(u):
        """u: (2L+2,) = [a(比), b(比), a_t(2)]，全部在归一化空间。"""
        aa, bb, act = u[:L], u[L:2 * L], u[2 * L:]
        h1 = W1 @ np.concatenate([aa, bb, act]) + b1
        g1 = h1 / (1 + np.exp(-np.clip(h1, -60, 60)))
        h2 = W2 @ g1 + b2
        g2 = h2 / (1 + np.exp(-np.clip(h2, -60, 60)))
        out = bb + (bb - aa) + A @ act + W3 @ g2 + b3
        return np.concatenate([bb, np.clip(out, -8, 8), act])

    def jac(u):
        aa, bb, act = u[:L], u[L:2 * L], u[2 * L:]
        h1 = W1 @ np.concatenate([aa, bb, act]) + b1
        s1 = 1 / (1 + np.exp(-np.clip(h1, -60, 60)))
        g1 = h1 * s1
        h2 = W2 @ g1 + b2
        s2 = 1 / (1 + np.exp(-np.clip(h2, -60, 60)))
        d1 = s1 + h1 * s1 * (1 - s1)
        d2 = s2 + h2 * s2 * (1 - s2)
        dd = W3 @ (d2[:, None] * (W2 @ (d1[:, None] * W1)))       # (L, 2L+2)
        n = 2 * L + 2
        J = np.zeros((n, n))
        I = np.eye(L)
        J[:L, L:2 * L] = I                                        # 新的 a = 旧的 b
        J[L:2 * L, :L] = -I + dd[:, :L]
        J[L:2 * L, L:2 * L] = 2 * I + dd[:, L:2 * L]
        J[L:2 * L, 2 * L:] = A + dd[:, 2 * L:]
        J[2 * L:, 2 * L:] = np.eye(2)                             # 动作块是 2×2（固定动作序列）
        return J

    lam = qr_spectrum_map(f, jac, x0=np.zeros(2 * L + 2), n_steps=6000, discard=1500)
    return float(lam[0]), [float(x) for x in lam]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=EPOCHS)
    ap.add_argument("--skip-cache", action="store_true")
    ap.add_argument("--retrain", action="store_true", help="忽略已训 ckpt，重新训练")
    a = ap.parse_args()
    torch.manual_seed(0)
    t0 = time.time()

    cache = os.path.join(CKPT, "t15_act_data.pt")
    if os.path.exists(cache) and not a.skip_cache:
        d = torch.load(cache, map_location="cpu", weights_only=False)
        ztr, atr, zva, ava = d["ztr"], d["atr"], d["zva"], d["ava"]
        print(f"  载入缓存 {os.path.basename(cache)}：train {tuple(ztr.shape)} val {tuple(zva.shape)}")
    else:
        vae = load_vae()
        vae.load_state_dict(torch.load(os.path.join(CKPT, "vae_gray_s3.pt"),
                                       map_location=DEV, weights_only=True)["state"])
        vae.eval()
        print(f"  生成动作条件数据：train {N_TRAIN} + val {N_VAL} 条")
        ftr, atr_np = build_dataset(N_TRAIN, 0, True)
        fva, ava_np = build_dataset(N_VAL, 999, False)
        G.input_stats(torch.from_numpy(ftr[:4]).float(), "动作数据帧（抽查）")
        print(f"    动作分布：{np.bincount((atr_np[:, :, 0] + 1).ravel(), minlength=3).tolist()} "
              f"（x 轴 −1/0/+1 计数）")
        ztr = encode_all(vae, ftr)
        zva = encode_all(vae, fva)
        atr = torch.from_numpy(atr_np.astype(np.float32))
        ava = torch.from_numpy(ava_np.astype(np.float32))
        torch.save(dict(ztr=ztr, atr=atr, zva=zva, ava=ava), cache)
        print(f"    潜向量已编码并缓存 -> {os.path.basename(cache)}")

    mean = ztr.mean(dim=(0, 1)).to(DEV)
    std = ztr.std(dim=(0, 1)).clamp_min(1e-6).to(DEV)
    print(f"  潜空间 mean/std 就绪（latent={LATENT}）")

    print("\n" + "=" * 92)
    print("  训练动作条件动力学")
    print("=" * 92)
    ck = os.path.join(CKPT, "t15_act_dyn.pt")
    if os.path.exists(ck) and not a.retrain:
        sd = torch.load(ck, map_location=DEV, weights_only=False)
        m = ActDynamics().to(DEV)
        m.load_state_dict(sd["state"])
        print(f"    载入已训 ckpt {os.path.basename(ck)}（--retrain 可强制重训）")
    else:
        m = train_act(ztr[:N_TRAIN], atr[:N_TRAIN], mean, std, epochs=a.epochs)
        torch.save(dict(state=m.state_dict(), latent=LATENT, ctx=CTX), ck)
        print(f"    已保存 {os.path.basename(ck)}")
    cos = single_step(m, zva, ava, mean, std)
    print(f"    单步潜余弦（带动作）= {cos:.5f}")

    # 对照：把动作置零的单步 cos（等价于无条件模型的预测）
    zc0 = None
    cos_cond0 = None
    n, T = zva.shape[0], zva.shape[1]
    ii, tt = torch.meshgrid(torch.arange(n), torch.arange(CTX, T - 1), indexing="ij")
    ii, tt = ii.reshape(-1)[:2048], tt.reshape(-1)[:2048]
    ca = ((zva[ii, tt - 1].to(DEV) - mean) / std).unsqueeze(1)
    cb = ((zva[ii, tt].to(DEV) - mean) / std).unsqueeze(1)
    zc0 = torch.cat([ca, cb], dim=1)
    with torch.no_grad():
        p0 = m(zc0, torch.zeros(zc0.shape[0], 2, device=DEV)) * std + mean
    cos0 = float(F.cosine_similarity(p0, zva[ii, tt + 1].to(DEV), dim=-1).mean())
    print(f"    单步潜余弦（动作强制置零，作对照）= {cos0:.5f}")

    print("\n" + "=" * 92)
    print("  四个判据")
    print("=" * 92)
    s = act_sensitivity(m, zva, ava, mean, std)
    print(f"  ① 动作敏感性：跨 9 个动作的预测分散度 {s['rel_spread']:.5f} "
          f"（相对自身尺度）；‖f(a=+1,+1) − f(a=−1,−1)‖ = {s['norm_a11_minus_am1m1']:.4f}")
    c = act_classify(m, zva, ava, mean, std)
    print(f"  ② 动作可分性：从预测变化反推动作，准确率 {c['acc']*100:.1f}% "
          f"（随机基线 {c['chance']*100:.1f}%）")
    cf = counterfactual(m, zva, ava, mean, std)
    print(f"  ③ 反事实：终位移 ‖plus−zero‖ {cf['plus_vs_zero']:.4f} vs "
          f"‖minus−zero‖ {cf['minus_vs_zero']:.4f}；‖plus−minus‖ {cf['plus_vs_minus']:.4f}"
          f" → 方向{'正确' if cf['direction_ok'] else '**异常**'}")
    lam1, spec = lam1_conditional(m, zva, ava, mean, std)
    print(f"  ④ 条件 λ₁（QR，增广状态含动作）= {lam1:+.5f}   （真值应为 0）")

    OUTD = {"config": dict(epochs=a.epochs, ctx=CTX, latent=LATENT, n_train=N_TRAIN,
                           n_val=N_VAL, a_max=A_MAX, v_max=V_MAX, speeds=list(SPEEDS)),
            "cos_single_step": cos, "cos_act_zeroed": cos0,
            "crit1_sensitivity": s, "crit2_classify": c,
            "crit3_counterfactual": cf, "crit4_lam1": lam1, "spectrum": spec,
            "elapsed_s": round(time.time() - t0, 1),
            "_note": ("T15 动作条件化基线。真值 λ₁ 仍为 0（动作不改变 (x,v)↦(x+v',v') 的特征值），"
                      "故 T4/T5/T7 的误差递推在动作条件下逐字成立。")}
    prev = {}
    if os.path.exists(OUT):
        prev = json.load(open(OUT, encoding="utf-8"))
    prev.update(OUTD)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(prev, f, ensure_ascii=False, indent=2)
    print(f"\n-> {os.path.relpath(OUT, ROOT)}  （{OUTD['elapsed_s']}s）")


if __name__ == "__main__":
    main()
