"""论文四节的一致性校验：
  ① 关键数字与 logs/*.json 一致
  ② 无过时表述残留（「同向」、「斜率反推的 λ₁_eff … 0.74×」等已在 §1 撤回的说法）
  ③ 结构完整（章节齐全、无重复编号）
"""
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PP = os.path.join(ROOT, "paper")


def L(n):
    p = os.path.join(ROOT, "logs", n)
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}


R = {}
for f in ("methods.md", "negative_results.md", "results.md", "introduction.md"):
    R[f] = open(os.path.join(PP, f), encoding="utf-8").read()
ALL = "\n".join(R.values())

t15 = L("t15_action.json")
t15t = L("t15_truth.json")
t15c = L("t15_cf.json")
t16 = L("t16_plan.json")
b16 = {r["bits"]: r for r in t16["B_bits_scan"]}
A16 = t16["A_full_precision"]

checks = [
    # ---- 过时表述不得残留
    ("无「与本文纲领 T5 …同向」残留（T5 实测方向相反）",
     "与本文纲领 T5" not in R["results.md"] and "位宽分配律」同向" not in R["results.md"]),
    ("撤回记录完整（三处原结论已显式标注撤回，而非静默删除）",
     "因此以下三处原结论撤回" in R["results.md"]),
    ("无「斜率反推的 λ₁_eff 与真值同量级」残留（§1 已撤回）",
     "斜率反推的 λ₁_eff" not in R["results.md"]),
    ("无「对数律线性」当正面结论（只应出现在被否证的语境）",
     "T_crash 对位宽近似线性" not in R["results.md"]),
    ("§4.1 明确写出「方向相反」", "方向相反" in R["results.md"]),
    ("§5.2 用临界位宽而非对数律直读", "不能用对数律直读" in R["results.md"]),
    # ---- T15 数字
    ("T15 单步 cos 0.90572", abs(t15["cos_single_step"] - 0.90572) < 1e-5
     and "0.90572" in ALL),
    ("T15 置零对照 0.88543", "0.88543" in ALL),
    ("T15 条件 λ₁ −0.0438", abs(t15["crit4_lam1"] + 0.0438) < 1e-3 and "−0.0438" in ALL),
    ("T15 无动作 λ₁ −0.0468", "−0.0468" in ALL),
    ("T15 动作可分性 100.0%", "100.0%" in ALL),
    ("T15 反事实余弦 −0.9952", abs(t15c["cos_plus_minus"] + 0.9952) < 1e-3 and "−0.9952" in ALL),
    ("T15 真值 QR 全 0", all(abs(r["lam"][0]) < 1e-9 for r in t15t["qr_rows"])
     and "+0.00000" in ALL),
    ("T15 分散度 23.7%", "23.7%" in ALL),
    # ---- T16 数字
    ("T16 规划 68.4%", abs(A16["plan_succ"] - 0.684) < 1e-3 and "68.4%" in ALL),
    ("T16 随机 15.2%", abs(A16["rand_succ"] - 0.152) < 1e-3 and "15.2%" in ALL),
    ("T16 b=4 cos 0.79233", abs(b16[4]["single_cos"] - 0.79233) < 1e-5 and "0.79233" in ALL),
    ("T16 b=32 规划 70.7%", abs(b16[32]["plan_succ"] - 0.707) < 1e-3 and "70.7%" in ALL),
    ("T16 b=6 +2.0pp / b=8 −0.4pp", "+2.0pp" in ALL and "−0.4pp" in ALL),
    ("T16 95%CI ±6.1pp", "±6.1pp" in ALL),
    ("T16 空洞真值已记录", "空洞真值" in ALL or "all([]) == True" in ALL),
    # ---- 结构
    ("results.md 八组主结果齐全",
     all(k in R["results.md"] for k in ("主结果一", "主结果二", "主结果三", "主结果四", "主结果五：不连续动力学下，决定", "主结果六：块级路由", "主结果七：崩坏预警对照", "主结果八：规划的价值边界"))),
    ("results.md §10 结论存在", "## 10 结论" in R["results.md"]),
    ("引言含第 5 条贡献", "动作与决策（主结果 §4）" in R["introduction.md"]),
    # ---- T14（主结果七）
    ("T14 形状修复：207 崩溃/真值[1,37]/平凡基线 83.1%",
     all(k in R["results.md"] for k in ("207 条", "[1,37]", "83.1%"))),
    ("T14 四臂（81.2/71.0/57.0/24.6）与实测 η 版 73.4",
     all(k in R["results.md"] for k in ("81.2", "71.0", "57.0", "24.6", "73.4"))),
    ("T14 原结论撤回在案", "一条 if 语句就够了”撤回" in R["results.md"]),
    ("T14 A3 离线重测在案（71.0%/−5.22）",
     "71.0%" in R["results.md"] and "5.22" in R["results.md"]),
    ("T14 MoE 探针修复（2.96×、未观测到跳变）",
     "2.96" in R["results.md"] and "未观测到跳变" in R["results.md"]),
    ("T19 随机基线高于全部规划配置", "33.3%" in R["results.md"] and "高于全部 12 个规划配置" in R["results.md"]),
    ("T19 k 不敏感 + h480-k1 4.2%", "4.2%" in R["results.md"] and "几乎无影响" in R["results.md"]),
    ("T19 元结论（刷得勤救不了选得偏）", "「刷得勤」救不了「选得偏」" in R["results.md"]),
    ("负面结果含 §15 规划价值边界", "## 15 规划的选择偏差" in R["negative_results.md"]),
    ("负面结果含 §14 崩坏预警附加臂", "## 14 A2b 的阈值校准失败" in R["negative_results.md"]),
    ("负面结果含 §10", "## 10 " in R["negative_results.md"]),
    ("方法含 §2.1/2.2", "### 2.1 动作条件化" in R["methods.md"] and "### 2.2 规划" in R["methods.md"]),
    # ---- T18b（主结果五）
    ("T18b 撤回与机制：+2.0707 / 零扩张事件 / 原结论撤回",
     "+2.0707" in R["results.md"] and "零扩张事件" in R["results.md"]
     and "原结论撤回" in R["results.md"]),
    ("T18b 两条平凡通道（含「已离开数据流形」）",
     "平凡通道" in R["results.md"] and "它已离开数据流形" in R["results.md"]),
    ("T18b 勘误：n_digit=2 与保留比例 41.0%",
     "n_digit = 2" in R["results.md"] and "41.0%" in R["results.md"]),
    # ---- T2b（主结果六）
    ("T2b 五臂数值（0.72569 / 0.59385 / 0.59983）",
     all(x in R["results.md"] for x in ("0.72569", "0.59385", "0.59983"))),
    ("T2b 正对照：互信息超出 22×、切换点 p=0.000",
     "22×" in R["results.md"] and "p = 0.000" in R["results.md"]),
    ("T2b 标签冗余（oracle 只高 +0.0014）",
     "+0.0014" in R["results.md"] and "过程标签对单步预测是冗余的" in R["results.md"]),
    ("T2b 同容量净损失 −0.132",
     "−0.132" in R["results.md"]),
    ("T2b 正对照节标题存在（§4 之前）",
     "正对照：oracle 臂验证了测量机器" in R["results.md"]),
]
bad = [n for n, ok in checks if not ok]
print(f"论文四节一致性校验 {len(checks)} 项：", "全部通过 ✅" if not bad else f"失败 {bad}")
print()
for f, s in R.items():
    h2 = len(re.findall(r"^## ", s, re.M))
    print(f"  {f:<22} {len(s):>6} 字符  {h2} 个二级节")
print()
print("  残留检查：")
for k in ("同向", "斜率反推的 λ₁_eff", "T_crash 对位宽近似线性", "0.74×"):
    print(f"    {k!r}: {ALL.count(k)}")
