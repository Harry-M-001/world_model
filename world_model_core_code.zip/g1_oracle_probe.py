# -*- coding: utf-8 -*-
"""G1① · 规划上界探针（oracle 评分 + 解析控制器 + 随机对照）

问题（G1 规格）：T19 实测随机基线 33.3% 高于全部 12 个规划配置（最高 20.8%）。
是「评分/模型是瓶颈」还是「天花板本来就低」？

──────────────── 预注册判读（跑之前写死，源自 G1 规格）────────────────
  · oracle 评分成功率 ≥ 70% ⇒ 偏差确实在评分/模型上，去偏规划器值得做（进 G1②）；
  · oracle ≈ 40%（≈ 随机基线）⇒ 天花板低，别投大成本（干净负面结果）；
  · 中间 ⇒ 部分可行，需加大样本量与候选质量再判；
  · 解析控制器 = 环境天花板对照（真值反馈 + 手工控制，不受候选池限制）。
样本量：24 回合（与 T19 完全同回合，保证可比）；二项 SE ≈ 9.6pp ⇒ 本探针只作方向判断，
正式对照（G1②）需 ≥80 回合/配置。

三个臂（除打分源/控制器外一切不变；候选集 RNG 流与原 12 配置逐位一致）：
  A oracle-评分 × k∈{1,2,4,8}：候选采样与原版相同（rng 9000+e），打分改为
    「真值动力学 rollout 8 步 → render → encode → 质心到目标距离」；执行最优 k 步。
  B 解析控制器：真值状态反馈的手工控制（目标 = 另一数字质心的镜像点），环境天花板。
  C 随机对照：rng 5000+e 随机动作 40 步（与原 T19 随机基线同一实现，作同一性校验）。
附加诊断（k=1）：对同一批候选同时算模型评分（h192）与 oracle 评分，
  报 Spearman 秩相关（中位）与「模型最优候选的真实距离 vs oracle 最优候选的真实距离」。
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

from t19_pareto import (L_EP, H_PLAN, KS, SIZES, render, step_true,   # noqa: E402
                        V_MAX_T)
from t14_warn import load_act_model, act_feats                    # noqa: E402
from multiphys import rand_state, ACT_DV, H, W, LIM    # noqa: E402
from collide import DIGIT                              # noqa: E402
from variant2 import GRAY                              # noqa: E402
from vae import load_vae, CKPT                         # noqa: E402

DEV = "cuda" if torch.cuda.is_available() else "cpu"
OUT = os.path.join(ROOT, "logs", "g1_oracle_probe.json")
N_EP = 24
N_CAND = 32
THRESH_EXPECT = 7.135732650756836          # 原 T19 实测值（同一性校验）
YY, XX = torch.meshgrid(torch.arange(H).float(), torch.arange(W).float(), indexing="ij")
V_MAX_T = 3.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-ep", type=int, default=N_EP)
    a = ap.parse_args()
    t0 = time.time()
    print("=" * 100)
    print(f"  G1① · 规划上界探针（{a.n_ep} 回合，候选 {N_CAND}，视界 {H_PLAN}，回合 {L_EP} 步）")
    print("=" * 100)

    vae = load_vae()
    vae.load_state_dict(torch.load(os.path.join(CKPT, "vae_gray_s3.pt"),
                                   map_location=DEV, weights_only=True)["state"])
    vae.eval()
    digits_pool = GRAY[True]

    def encode(frame):
        x = torch.from_numpy(frame).float().div_(255.0).view(1, 1, H, W).to(DEV)
        with torch.no_grad():
            return vae.encode_det(x)[0]

    def centroid(z_raw):
        with torch.no_grad():
            img = torch.sigmoid(vae.decode(z_raw.to(DEV))).view(-1, H, W).cpu()
        s = img.sum(dim=(-1, -2)).clamp_min(1e-6)
        cy = (img * YY).sum(dim=(-1, -2)) / s
        cx = (img * XX).sum(dim=(-1, -2)) / s
        return torch.stack([cx, cy], dim=-1)

    # ---- 回合构造（与 t19_pareto.main 逐位一致）----
    goals, starts = [], []
    for e in range(a.n_ep):
        rng = np.random.default_rng(1900 + e)
        st0 = rand_state(rng, 2)
        order = rng.permutation(len(digits_pool))[:2]
        digs = [digits_pool[i] for i in order]
        acts = np.zeros((L_EP, 3))
        for t in range(L_EP):
            di = int(rng.integers(0, 2))
            ux = uy = 0
            while ux == 0 and uy == 0:
                ux, uy = int(rng.integers(-1, 2)), int(rng.integers(-1, 2))
            acts[t] = (di, ux, uy)
        st = st0.copy()
        for t in range(L_EP):
            st = step_true(st, acts[t])
        frame_end = render(st, digs)
        z_end = encode(frame_end)
        goals.append(centroid(z_end).cpu()[0])
        starts.append(dict(st=st0, digs=digs, frame1=render(st0, digs)))
    starts_c = [centroid(encode(sd["frame1"])).cpu()[0] for sd in starts]
    goals_t = torch.stack(goals)
    starts_t = torch.stack(starts_c)
    dist0 = (starts_t - goals_t).norm(dim=-1)
    thresh = float(dist0.median()) * 0.5
    ident = abs(thresh - THRESH_EXPECT) < 1e-6
    print(f"  起始→目标距离中位 {dist0.median():.4f}；成功阈值 {thresh:.10f}"
          f" ⇒ 与原 T19 同一性 {'✓' if ident else ('✗ 不一致——回合构造有差异！' if a.n_ep == N_EP else f'（n_ep={a.n_ep}≠24，中位数本就不同，跳过同一性断言）')}")
    if a.n_ep == N_EP:
        assert ident, "回合构造与原 T19 不一致，中止"

    res = dict(config=dict(n_ep=a.n_ep, n_cand=N_CAND, H_plan=H_PLAN, L_ep=L_EP,
                           ks=list(KS), thresh=thresh, eps_rel="1e-6·‖x‖"),
               identity=dict(thresh=thresh, match=ident))

    # ---------------- C 随机对照（同一性校验）----------------
    print("\n[C] 随机对照（rng 5000+e，应复现原 T19 的 33.3%）")
    rs = []
    for e in range(a.n_ep):
        sd = starts[e]
        st = sd["st"].copy()
        digs = sd["digs"]
        rng = np.random.default_rng(5000 + e)
        for t in range(L_EP):
            di = int(rng.integers(0, 2))
            ux = uy = 0
            while ux == 0 and uy == 0:
                ux, uy = int(rng.integers(-1, 2)), int(rng.integers(-1, 2))
            st = step_true(st, (di, ux, uy))
        z_obs = encode(render(st, digs))
        fd = float((centroid(z_obs).cpu()[0] - goals[e]).norm())
        rs.append(fd < thresh)
    r_succ = float(np.mean(rs))
    random_match = abs(r_succ - 0.3333333333333333) < 1e-9
    print(f"  随机成功率 {sum(rs)}/{a.n_ep} = {r_succ*100:.1f}%"
          f"（原 T19: 33.3%；逐位一致 {random_match}）")
    res["random_check"] = dict(success=r_succ, match=bool(random_match))
    ok = random_match

    # ---------------- A oracle-评分 × k ----------------
    print("\n[A] oracle 评分（真值动力学 rollout → 真值质心距）")
    oracle = []
    for k in KS:
        n_replan = L_EP // k
        succ, dists = [], []
        for e in range(a.n_ep):
            sd = starts[e]
            st = sd["st"].copy()
            digs = sd["digs"]
            goal = goals[e]
            rng = np.random.default_rng(9000 + e)
            for rp in range(n_replan):
                cands = np.zeros((N_CAND, H_PLAN, 3))
                for c in range(N_CAND):
                    for h in range(H_PLAN):
                        di = int(rng.integers(0, 2))
                        ux = uy = 0
                        while ux == 0 and uy == 0:
                            ux, uy = (int(rng.integers(-1, 2)),
                                      int(rng.integers(-1, 2)))
                        cands[c, h] = (di, ux, uy)
                # ★ oracle 评分：真值动力学 rollout → render → encode → 质心距
                ds = np.zeros(N_CAND)
                for c in range(N_CAND):
                    sc = st.copy()
                    for h in range(H_PLAN):
                        sc = step_true(sc, cands[c, h])
                    z_end = encode(render(sc, digs))
                    ds[c] = float((centroid(z_end).cpu()[0] - goal).norm())
                best = int(ds.argmin())
                for h in range(k):
                    st = step_true(st, cands[best, h])
                z_obs = encode(render(st, digs))
                dists.append(float((centroid(z_obs).cpu()[0] - goal).norm()))
            succ.append(dists[-1] < thresh)
        sr = float(np.mean(succ))
        md = float(np.mean(dists))
        oracle.append(dict(k=k, success=sr, mean_dist=md, n_ep=a.n_ep))
        print(f"  k={k}: 成功 {sum(succ)}/{a.n_ep} = {sr*100:.1f}%  末距均值 {md:.2f}")
    res["oracle"] = oracle
    best_or = max(o["success"] for o in oracle)

    # ---------------- A+ 模型评分交叉诊断（k=1，h192）----------------
    print("\n[A+] 模型评分 vs oracle 评分（同一批候选，k=1，h192）")
    tag = SIZES[1][0]
    m, mean, std = load_act_model(tag)                 # 精确复用 t14_warn 的加载
    k = 1
    n_replan = L_EP // k
    rho_all, d_model_best, d_oracle_best = [], [], []
    succ_m, succ_o = [], []
    for e in range(a.n_ep):
        sd = starts[e]
        st = sd["st"].copy()
        digs = sd["digs"]
        goal = goals[e]
        z_prev = encode(sd["frame1"]).cpu()
        z_cur = z_prev.clone()
        rng = np.random.default_rng(9000 + e)
        for rp in range(n_replan):
            zc = torch.cat([((z_prev.to(DEV) - mean) / std).unsqueeze(0),
                            ((z_cur.to(DEV) - mean) / std).unsqueeze(0)],
                           dim=0).unsqueeze(0)
            cands = np.zeros((N_CAND, H_PLAN, 3))
            for c in range(N_CAND):
                for h in range(H_PLAN):
                    di = int(rng.integers(0, 2))
                    ux = uy = 0
                    while ux == 0 and uy == 0:
                        ux, uy = (int(rng.integers(-1, 2)),
                                  int(rng.integers(-1, 2)))
                    cands[c, h] = (di, ux, uy)
            # oracle 分（真值动力学 rollout → 真值质心距）
            d_o = np.zeros(N_CAND)
            for c in range(N_CAND):
                sc = st.copy()
                for h in range(H_PLAN):
                    sc = step_true(sc, cands[c, h])
                z_end = encode(render(sc, digs))
                d_o[c] = float((centroid(z_end).cpu()[0] - goal).norm())
            # 模型分（同一批候选；act_feats 与 t19_pareto 逐位一致）
            af = act_feats(torch.tensor(cands.reshape(-1, 3),
                                        dtype=torch.float32)).to(DEV)
            zc_rep = zc.expand(N_CAND, -1, -1)
            with torch.no_grad():
                for h in range(H_PLAN):
                    ah = af[h * N_CAND:(h + 1) * N_CAND]
                    pm, _ = m(zc_rep, None, ah)
                    zc_rep = torch.cat([zc_rep[:, 1:], pm.unsqueeze(1)], dim=1)
            z_last = zc_rep[:, -1] * std + mean
            cc = []
            for c in range(0, N_CAND, 16):
                cc.append(centroid(z_last[c:c + 16]).cpu())
            cc = torch.cat(cc, dim=0)
            d_m = (cc - goal.unsqueeze(0)).norm(dim=-1).cpu().numpy()
            # Spearman 秩相关（手写，避免额外依赖）
            ra = np.argsort(np.argsort(d_m)).astype(float)
            rb = np.argsort(np.argsort(d_o)).astype(float)
            ra = ra - ra.mean(); rb = rb - rb.mean()
            denom = math.sqrt((ra ** 2).sum() * (rb ** 2).sum())
            rho_all.append(float((ra * rb).sum() / denom) if denom > 0 else 0.0)
            bm, bo = int(d_m.argmin()), int(d_o.argmin())
            d_model_best.append(float(d_o[bm]))    # 模型选中候选的「真实」距离
            d_oracle_best.append(float(d_o[bo]))
            # 各自执行最优 k=1 步，用真观测判定
            st_m = step_true(st.copy(), cands[bm, 0])
            zm = encode(render(st_m, digs))
            succ_m.append(float((centroid(zm).cpu()[0] - goal).norm()) < thresh)
            st = step_true(st, cands[bo, 0])
            z_obs = encode(render(st, digs))
            succ_o.append(float((centroid(z_obs).cpu()[0] - goal).norm()) < thresh)
            z_prev, z_cur = z_cur, z_obs.cpu()
    rho_med = float(np.median(rho_all))
    print(f"  Spearman(模型分, 真值分) 中位 = {rho_med:+.3f}"
          f"（高 ⇒ 模型评分基本可信；≈0 或负 ⇒ 评分与真实脱钩）")
    print(f"  模型最优候选的真实末距均值 {np.mean(d_model_best):.2f}"
          f" vs oracle 最优 {np.mean(d_oracle_best):.2f}")
    print(f"  同批候选、各选最优执行 k=1：模型选择 {np.mean(succ_m)*100:.1f}%"
          f" vs oracle 选择 {np.mean(succ_o)*100:.1f}%")
    res["cross_check_k1"] = dict(tag=tag, rho_median=rho_med,
                                 d_model_best=float(np.mean(d_model_best)),
                                 d_oracle_best=float(np.mean(d_oracle_best)),
                                 success_model_choice=float(np.mean(succ_m)),
                                 success_oracle_choice=float(np.mean(succ_o)))

    # ---------------- A++ 模型评分 × 视界扫描（检验 Q1.2 的 h* 预言）----------------
    # 预言：模型只在前 3–6 步优于拷贝基线（Q1.2 h*）⇒ H_PLAN=8 的候选评分是噪声（ρ≈0），
    #       而 H_PLAN ≤ 3 的评分应有信息 ⇒ 规划成功率应随视界缩短而回升。
    print("\n[A++] 模型评分规划器 × 视界扫描（k=1，h192；检验 Q1.2 的 h* 预言）")
    tag = SIZES[1][0]
    m, mean, std = load_act_model(tag)
    hz_res = []
    for H_PLAN_M in (1, 2, 3, 8):
        succ_h = []
        for e in range(a.n_ep):
            sd = starts[e]
            st = sd["st"].copy()
            digs = sd["digs"]
            goal = goals[e]
            z_prev = encode(sd["frame1"]).cpu()
            z_cur = z_prev.clone()
            rng = np.random.default_rng(9000 + e)
            for rp in range(L_EP):                    # k=1：每步重规划
                zc = torch.cat([((z_prev.to(DEV) - mean) / std).unsqueeze(0),
                                ((z_cur.to(DEV) - mean) / std).unsqueeze(0)],
                               dim=0).unsqueeze(0)
                cands = np.zeros((N_CAND, H_PLAN_M, 3))
                for c in range(N_CAND):
                    for h in range(H_PLAN_M):
                        di = int(rng.integers(0, 2))
                        ux = uy = 0
                        while ux == 0 and uy == 0:
                            ux, uy = (int(rng.integers(-1, 2)),
                                      int(rng.integers(-1, 2)))
                        cands[c, h] = (di, ux, uy)
                af = act_feats(torch.tensor(cands.reshape(-1, 3),
                                            dtype=torch.float32)).to(DEV)
                zc_rep = zc.expand(N_CAND, -1, -1)
                with torch.no_grad():
                    for h in range(H_PLAN_M):
                        ah = af[h * N_CAND:(h + 1) * N_CAND]
                        pm, _ = m(zc_rep, None, ah)
                        zc_rep = torch.cat([zc_rep[:, 1:], pm.unsqueeze(1)], dim=1)
                z_last = zc_rep[:, -1] * std + mean
                cc = []
                for c in range(0, N_CAND, 16):
                    cc.append(centroid(z_last[c:c + 16]).cpu())
                cc = torch.cat(cc, dim=0)
                d_m = (cc - goal.unsqueeze(0)).norm(dim=-1).cpu().numpy()
                best = int(d_m.argmin())
                st = step_true(st, cands[best, 0])
                z_obs = encode(render(st, digs))
                z_prev, z_cur = z_cur, z_obs.cpu()
            fd = float((centroid(z_cur.to(DEV)).cpu()[0] - goal).norm())
            succ_h.append(fd < thresh)
        sr_h = float(np.mean(succ_h))
        hz_res.append(dict(H_plan=H_PLAN_M, success=sr_h, n_ep=a.n_ep))
        print(f"  H_PLAN={H_PLAN_M}: 成功率 {sum(succ_h)}/{a.n_ep} = {sr_h*100:.1f}%")
    res["model_horizon_sweep"] = hz_res
    hz8 = next(x for x in hz_res if x["H_plan"] == 8)["success"]
    hz3 = next(x for x in hz_res if x["H_plan"] == 3)["success"]
    relation = "视界越短越准，h* 预言成立" if hz3 > hz8 else "预言未成立（H=3 不优于 H=8）"
    print(f"  ⇒ {relation}（H=3 {hz3*100:.1f}% vs H=8 {hz8*100:.1f}%）")
    res["hstar_verdict"] = relation

    # ---------------- B 解析控制器（环境天花板）----------------
    print("\n[B] 解析控制器（真值反馈；目标 = 另一数字质心的镜像点）")
    succ_a, dists_a = [], []
    for e in range(a.n_ep):
        sd = starts[e]
        st = sd["st"].copy()
        digs = sd["digs"]
        goal = goals[e].cpu().numpy()
        for t in range(L_EP):
            pos = st[:, :2] + DIGIT / 2.0            # 数字中心
            other = 1 if np.linalg.norm(pos[0] - goal) < np.linalg.norm(pos[1] - goal) else 0
            d_sel = 1 - other
            target_d = 2.0 * goal - pos[other]       # 使复合质心落在 goal
            err = target_d - pos[d_sel]
            v_des = np.clip(err * 0.5, -V_MAX_T, V_MAX_T)
            vx, vy = st[d_sel, 2], st[d_sel, 3]
            px_ = 1 if v_des[0] > vx + 0.29 else (-1 if v_des[0] < vx - 0.29 else 0)
            py_ = 1 if v_des[1] > vy + 0.29 else (-1 if v_des[1] < vy - 0.29 else 0)
            st = step_true(st, (d_sel, px_, py_))
        z_obs = encode(render(st, digs))
        fd = float((centroid(z_obs).cpu()[0] - goals[e]).norm())
        dists_a.append(fd)
        succ_a.append(fd < thresh)
    sr_a = float(np.mean(succ_a))
    print(f"  解析控制器成功率 {sum(succ_a)}/{a.n_ep} = {sr_a*100:.1f}%  末距均值 {np.mean(dists_a):.2f}")
    res["analytic"] = dict(success=sr_a, mean_dist=float(np.mean(dists_a)),
                           n_ep=a.n_ep)

    # ---------------- 预注册判读 ----------------
    print("\n" + "=" * 100)
    print("  预注册判读（G1 规格）")
    print("=" * 100)
    best_k = max(oracle, key=lambda o: o["success"])
    print(f"  oracle 最优档：k={best_k['k']} 成功率 {best_or*100:.1f}%｜"
          f"随机对照 {r_succ*100:.1f}%｜解析控制器（环境天花板）{sr_a*100:.1f}%")
    if best_or >= 0.70:
        verdict = ("偏差确实在评分/模型上 ⇒ 去偏规划器（G1②）值得做："
                   "同一批候选、只换评分源即达 %.0f%%" % (best_or * 100))
    elif best_or <= 0.45:
        verdict = ("天花板低 ⇒ 即使真值评分也 ≈ 随机，规划类任务不投大成本（干净负面结果）")
    else:
        verdict = ("中间地带：oracle 优于随机但未达 70%% ⇒ 部分可行，"
                   "先加大候选质量/样本量再判（本探针 24 回合 SE≈9.6pp）")
    print(f"  → {verdict}")
    res["verdict"] = verdict
    res["elapsed_s"] = round(time.time() - t0, 1)
    json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"\n  产物 → {OUT}（{res['elapsed_s']}s）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
