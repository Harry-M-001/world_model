"""
T19 · 小模型×高刷新与大模型×低刷新的 Pareto 扫描

待检验主张（可证伪）：固定算力预算下，
  小模型×高刷新频率可能优于大模型×低刷新（重规划频率可部分替代模型精度）。

设计：
- **真环境**：multiphys uniform 物理真值（状态级 [x,y,vx,vy]，2 数字，反射边界），
  与模型完全分离 —— 观测 = 渲染帧 → VAE 编码 → 潜向量（刷新时才读）。
- **任务**：场景质心控制 —— 把整帧墨迹质心推到目标位置（目标 = 预演序列末帧质心，
  保证可达，T16 同口径；成功阈值 = 起始距离中位 × 0.5）。
- **动作**：每步 (digit, ux, uy)（与 T2b act 模型同接口），脉冲 ±0.6。
- **刷新频率**：每 k 步重规划一次（k ∈ {1,2,4,8}）；两次刷新之间开环执行
  （模型自滚），刷新时用真观测替换上下文末帧（部分纠偏）。
- **模型轴**：dense_h96 / dense_h192 / dense_h480（同一 act 数据训练，参数量 3 档）。
- **预算记账**：每次前向计 1 次；FLOPs 代理 = params × 前向次数。Pareto 图：
  成功率 vs FLOPs，12 个配置（3 尺寸 × 4 刷新）。

预注册判读：若固定 FLOPs 下小模型×高刷新的点支配大模型×低刷新的点，
  上述主张成立；否则即为否证或弱化，两种结果均报告。
产物 logs/t19_pareto.json
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from t14_warn import load_act_model, act_feats, DEV   # noqa: E402
from vae import load_vae, CKPT                        # noqa: E402
from multiphys import (rand_state, step_state, ACT_DV,  # noqa: E402
                       H, W, LIM)
from collide import DIGIT                             # noqa: E402
from variant2 import GRAY                             # noqa: E402

L_EP = 40                    # 回合步数
H_PLAN = 8                   # 规划视界（≥ max k）
N_CAND = 32
KS = (1, 2, 4, 8)
SIZES = (("dense_h96_act", 96), ("dense_h192_act", 192), ("dense_h480_act", 480))
N_EP = 24
YY, XX = torch.meshgrid(torch.arange(H).float(), torch.arange(W).float(), indexing="ij")


def render(st, digits):
    """状态 (n,4) → 帧 (H,W) uint8（与 multiphys.make_seq 同一渲染约定）。"""
    frame = np.zeros((H, W), dtype=np.uint8)
    for i in range(st.shape[0]):
        xi = int(min(max(round(st[i, 0]), 0), LIM))
        yi = int(min(max(round(st[i, 1]), 0), LIM))
        np.maximum(frame[yi:yi + DIGIT, xi:xi + DIGIT], digits[i],
                   out=frame[yi:yi + DIGIT, xi:xi + DIGIT])
    return frame


V_MAX_T = 3.0     # 任务环境速度上限（T15 口径：v ← clip(v + 脉冲, ±v_max)；
                  # uniform 分支本身无 clip，不 clip 则速度线性暴涨、任务不可控）

def step_true(st, act, digits_rng=None):
    """真环境一步：act = [digit, ux, uy]（浮点），脉冲 → uniform 演化 → 限速。"""
    st = np.array(st, copy=True)
    di = int(act[0])
    st[di, 2] += ACT_DV * float(act[1])
    st[di, 3] += ACT_DV * float(act[2])
    st, _ = step_state(st, "uniform", boundary="reflect")
    st[:, 2] = np.clip(st[:, 2], -V_MAX_T, V_MAX_T)
    st[:, 3] = np.clip(st[:, 3], -V_MAX_T, V_MAX_T)
    return st


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-ep", type=int, default=N_EP)
    ap.add_argument("--n-cand", type=int, default=N_CAND)
    a = ap.parse_args()
    t0 = time.time()
    print("=" * 100)
    print(f"  T19 · Pareto 扫描（3 尺寸 × k∈{KS}，{a.n_ep} 回合/配置，"
          f"候选 {a.n_cand}，视界 {H_PLAN}，回合 {L_EP} 步）")
    print("=" * 100)

    vae = load_vae()
    vae.load_state_dict(torch.load(os.path.join(CKPT, "vae_gray_s3.pt"),
                                   map_location=DEV, weights_only=True)["state"])
    vae.eval()

    digits_pool = GRAY[True]
    rng0 = np.random.default_rng(19)

    def encode(frame):
        x = torch.from_numpy(frame).float().div_(255.0).view(1, 1, H, W).to(DEV)
        with torch.no_grad():
            return vae.encode_det(x)[0]

    def centroid(z_raw):
        with torch.no_grad():
            img = torch.sigmoid(vae.decode(z_raw.to(DEV))).view(-1, H, W).cpu()
        s = img.sum(dim=(-1, -2)).clamp_min(1e-6)
        cy = (img * YY).sum(dim=(-1, -2)) / s
        cx = (img * XX).sum(dim=(-1, -2)) / s
        return torch.stack([cx, cy], dim=-1)   # 批量计算：保持批次维，不取 [0]

    # ---- 目标集：预演保证可达（T16 口径）----
    goals = []
    starts = []
    for e in range(a.n_ep):
        rng = np.random.default_rng(1900 + e)
        st0 = rand_state(rng, 2)
        order = rng.permutation(len(digits_pool))[:2]
        digs = [digits_pool[i] for i in order]
        acts = np.zeros((L_EP, 3))
        for t in range(L_EP):
            di = int(rng.integers(0, 2))
            ux = uy = 0
            while ux == 0 and uy == 0:
                ux, uy = int(rng.integers(-1, 2)), int(rng.integers(-1, 2))
            acts[t] = (di, ux, uy)
        st = st0.copy()
        for t in range(L_EP):
            st = step_true(st, acts[t])
        frame_end = render(st, digs)
        z_end = encode(frame_end)
        goals.append(centroid(z_end).cpu()[0])
        starts.append(dict(st=st0, digs=digs, frame1=render(st0, digs)))
        # 起始质心（第 0 帧观测）
    starts_c = []
    for sd in starts:
        starts_c.append(centroid(encode(sd["frame1"])).cpu()[0])
    goals_t = torch.stack(goals)
    starts_t = torch.stack(starts_c)
    dist0 = (starts_t - goals_t).norm(dim=-1)
    thresh = float(dist0.median()) * 0.5
    print(f"  起始→目标距离：中位 {dist0.median():.1f}  成功阈值 ‖Δc‖ < {thresh:.1f}")

    results = []
    for tag, hidden in SIZES:
        m, mean, std = load_act_model(tag)
        n_par = sum(p.numel() for p in m.parameters())
        for k in KS:
            n_replan = L_EP // k
            succ, dists, fw = [], [], 0
            for e in range(a.n_ep):
                sd = starts[e]
                st = sd["st"].copy()
                digs = sd["digs"]
                z_prev = encode(sd["frame1"])
                z_cur = z_prev
                goal = goals[e]
                rng = np.random.default_rng(9000 + e)
                dist_curve = []
                for rp in range(n_replan):
                    # 规划：从 (z_prev, z_cur) 出发搜 n_cand 条动作序列
                    zc = torch.cat([((z_prev.to(DEV) - mean) / std).unsqueeze(0),
                                    ((z_cur.to(DEV) - mean) / std).unsqueeze(0)],
                                   dim=0).unsqueeze(0)
                    cands = np.zeros((a.n_cand, H_PLAN, 3))
                    for c in range(a.n_cand):
                        for h in range(H_PLAN):
                            di = int(rng.integers(0, 2))
                            ux = uy = 0
                            while ux == 0 and uy == 0:
                                ux, uy = (int(rng.integers(-1, 2)),
                                          int(rng.integers(-1, 2)))
                            cands[c, h] = (di, ux, uy)
                    af = act_feats(torch.tensor(cands.reshape(-1, 3),
                                                dtype=torch.float32)).to(DEV)
                    zc_rep = zc.expand(a.n_cand, -1, -1)
                    for h in range(H_PLAN):
                        ah = af[h * a.n_cand:(h + 1) * a.n_cand]
                        with torch.no_grad():
                            p, _ = m(zc_rep, None, ah)
                        zc_rep = torch.cat([zc_rep[:, 1:], p.unsqueeze(1)], dim=1)
                        fw += 1
                    # 评分：末帧质心到目标的距离
                    z_last = zc_rep[:, -1] * std + mean
                    cc = []
                    for c in range(0, a.n_cand, 16):
                        cc.append(centroid(z_last[c:c + 16]).cpu())
                    cc = torch.cat(cc, dim=0)
                    import os as _os
                    if _os.environ.get('T19_DEBUG'):
                        print('DBG zc', tuple(zc.shape), 'z_last', tuple(z_last.shape),
                              'cc', tuple(cc.shape), 'goal', tuple(goal.shape),
                              'z_prev', tuple(z_prev.shape), 'z_cur', tuple(z_cur.shape))
                    d = (cc - goal.unsqueeze(0)).norm(dim=-1)
                    best = int(d.argmin())
                    # 执行前 k 步
                    for h in range(k):
                        st = step_true(st, cands[best, h])
                    # 刷新：渲染 + 编码真观测，替换上下文末帧
                    z_obs = encode(render(st, digs))
                    z_prev = z_cur            # 上一次观测
                    z_cur = z_obs.cpu()
                    # 质心监控
                    dist_curve.append(float((centroid(z_cur).cpu()[0] - goal).norm()))
                final_d = float((centroid(z_cur).cpu()[0] - goal).norm())
                dists.append(final_d)
                succ.append(final_d < thresh)
            budget = n_par * fw
            sr = float(np.mean(succ))
            results.append(dict(tag=tag, hidden=hidden, k=k, params=n_par,
                                forwards=fw, flops=budget, success=sr,
                                mean_dist=float(np.mean(dists)),
                                n_ep=a.n_ep))
            print(f"  {tag:16s} k={k}  成功 {sum(succ)}/{a.n_ep}（{sr*100:.1f}%）  "
                  f"前向 {fw:,}  FLOPs代理 {budget:.2e}")

    # ---- 随机基线（无规划）：同回合、随机动作直接走 40 步 ----
    print("\n  随机基线（无规划）")
    rs, rfw = [], 0
    for e in range(a.n_ep):
        sd = starts[e]
        st = sd["st"].copy()
        digs = sd["digs"]
        rng = np.random.default_rng(5000 + e)
        for t in range(L_EP):
            di = int(rng.integers(0, 2))
            ux = uy = 0
            while ux == 0 and uy == 0:
                ux, uy = int(rng.integers(-1, 2)), int(rng.integers(-1, 2))
            st = step_true(st, (di, ux, uy))
        z_obs = encode(render(st, digs))
        fd = float((centroid(z_obs).cpu()[0] - goals[e]).norm())
        rs.append(fd < thresh)
    r_succ = float(np.mean(rs))
    print(f"  随机动作成功率 {sum(rs)}/{a.n_ep}（{r_succ*100:.1f}%）")

    # ---- Pareto 支配分析 ----
    print("\n" + "-" * 100)
    print("  Pareto 支配（成功率 vs FLOPs代理；支配 = 成功率更高且 FLOPs 更低）")
    print("-" * 100)
    dom = {}
    for r in results:
        dominated_by = [q for q in results
                        if q is not r and q["success"] >= r["success"]
                        and q["flops"] < r["flops"] * 0.98]
        dom[f"{r['tag']}-k{r['k']}"] = len(dominated_by)
        flag = " ←被支配" if dominated_by else ""
        print(f"  {r['tag']:16s} k={r['k']}  成功 {r['success']*100:5.1f}%  "
              f"FLOPs {r['flops']:.2e}{flag}")

    # ---- 预注册判读：同 FLOPs 档内，小模型×高刷新 vs 大模型×低刷新 ----
    print("\n  预注册判读：按 FLOPs 分档，比较「小模型×高刷新」vs「大模型×低刷新」")
    srt = sorted(results, key=lambda r: r["flops"])
    for i in range(len(srt) - 1):
        lo, hi = srt[i], srt[i + 1]
        if abs(lo["flops"] - hi["flops"]) / hi["flops"] < 0.5:
            win = "小×高刷" if lo["success"] >= hi["success"] else "大×低刷"
            print(f"  FLOPs≈{lo['flops']:.2e}: {lo['tag']}-k{lo['k']} "
                  f"({lo['success']*100:.0f}%) vs {hi['tag']}-k{hi['k']} "
                  f"({hi['success']*100:.0f}%) → {win} 更优")

    out = os.path.join(ROOT, "logs", "t19_pareto.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(dict(config=dict(n_ep=a.n_ep, n_cand=a.n_cand, H_plan=H_PLAN,
                                   L_ep=L_EP, ks=list(KS), sizes=[s for s, _ in SIZES],
                                   thresh=thresh),
                       random_success=r_succ,
                       results=results, dominance=dom),
                  f, ensure_ascii=False, indent=2)
    print(f"\n  → {out}（{time.time()-t0:.0f}s）")


if __name__ == "__main__":
    main()
