"""
T18 Part 0 · 碰撞环境的真值 λ₁（前置诊断）

**这是 T18 能否成立的前置判据**：如果碰撞环境测不出显著为正的 λ₁，
那么「高 λ₁ + 不连续」这个实验前提就不成立，后面全部不必做。

方法：Benettin（双轨迹 + 阈值触发重归一化）
    λ₁ = (1/T) Σ_k log(d_k / δ₀)
  对不连续系统（碰撞时刻跳变）也有效 —— 碰撞时间扰动本身是 λ₁ 的主要来源之一，
  这是硬球系统的标准图景。

须处理的混杂因素：**反射边界本身是不连续源**
  轨迹 A 撞墙反弹、轨迹 B 差一点点没撞 → 分离瞬间跳变 → 测出一个**假的** λ₁。
  首版实测：无碰撞的单数字（解析 λ₁ = 0）在反射边界下给出 +0.0055。
  做法：λ₁ 测量一律用 **periodic（环绕）边界**，生成数据仍用 reflect（与原版一致）。

交叉验证（任何一条不符都要停下来查）：
  ① **无碰撞对照**（n=1，环绕）：λ₁ 必须 ≈ 0 —— 机器在已知系统上的标定
  ② **δ₀ 无关性**：δ₀ = 1e-9 与 1e-10 必须一致
  ③ **动作无关性**：a≡0 与固定随机动作序列必须一致
     （∂f/∂s 不含 a —— 碰撞判定条件里没有 a）
  ④ 判据用**标准误**而非硬阈值（λ₁ 的跨初值分布是重尾的）

产物 logs/t18_truth.json
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True)

from collide import step_state, rand_state   # noqa: E402

OUT = os.path.join(ROOT, "logs", "t18_truth.json")


def benettin(n_digit, e=1.0, acts=None, n_steps=20000, delta0=1e-9,
             d_max=0.5, warm=2000, seed=0, boundary="periodic"):
    """单条轨迹的 Benettin 估计。acts=None → a≡0，否则为 (T,2) 动作表（周期使用）。"""
    rng = np.random.default_rng(seed)
    st = rand_state(rng, n_digit)
    for _ in range(warm):
        st, _ = step_state(st, np.zeros(2), e=e, boundary=boundary)
    st2 = st.copy()
    st2[0, 0] += delta0                       # 只扰动第一个数字的 x
    acc, nren, ncol = 0.0, 0, 0
    for t in range(n_steps):
        a = np.zeros(2) if acts is None else acts[t % len(acts)]
        st, c1 = step_state(st, a, e=e, boundary=boundary)
        st2, c2 = step_state(st2, a, e=e, boundary=boundary)
        ncol += c1
        d = float(np.linalg.norm((st2 - st).ravel()))
        if d > d_max:
            acc += math.log(d / delta0)
            nren += 1
            st2 = st + (st2 - st) * (delta0 / d)
    return acc / n_steps, nren, ncol / n_steps


def run_cfg(name, n_digit, e=1.0, acts=None, n_ic=24, n_steps=20000,
            delta0=1e-9, seed0=0, boundary="periodic"):
    lams, ren, cols = [], [], []
    for i in range(n_ic):
        lam, nr, nc = benettin(n_digit, e=e, acts=acts, n_steps=n_steps,
                               delta0=delta0, seed=seed0 + i, boundary=boundary)
        lams.append(lam)
        ren.append(nr)
        cols.append(nc)
    L = np.array(lams)
    se = float(L.std(ddof=1) / math.sqrt(len(L)))
    return dict(name=name, n_digit=n_digit, e=e, delta0=delta0, boundary=boundary,
                n_ic=n_ic, n_steps=n_steps,
                lam_med=float(np.median(L)), lam_mean=float(L.mean()),
                lam_std=float(L.std(ddof=1)), lam_se=se,
                lam_min=float(L.min()), lam_max=float(L.max()),
                lams=[float(x) for x in L],
                renorm_per_step=float(np.mean(ren) / n_steps),
                collisions_per_step=float(np.mean(cols)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=20000)
    ap.add_argument("--ic", type=int, default=24)
    a = ap.parse_args()
    t0 = time.time()
    print("=" * 100)
    print("  T18 Part 0 · 碰撞环境的真值 λ₁（前置判据：测不出正 λ₁ 则 T18 不成立）")
    print("=" * 100)
    print(f"  每配置 {a.ic} 个初值 × {a.steps} 步（Benettin：双轨迹 + 阈值触发重归一化）")
    print("  λ₁ 测量一律用 periodic（环绕）边界 —— 反射边界自身是不连续源，会污染测量")

    rng = np.random.default_rng(7)
    acts = rng.integers(-1, 2, size=(64, 2)).astype(np.float64)

    cfgs = [
        ("① n=1 环绕（无碰撞对照，解析 0）", 1, 1.0, None, 1e-9, "periodic"),
        ("② n=1 反射（对照：边界伪影）", 1, 1.0, None, 1e-9, "reflect"),
        ("③ n=3 反射 a≡0（与生成数据同边界）", 3, 1.0, None, 1e-9, "reflect"),
        ("④ n=3 环绕 a≡0（★ 主配置）", 3, 1.0, None, 1e-9, "periodic"),
        ("⑤ n=3 环绕 随机动作（机制诊断）", 3, 1.0, acts, 1e-9, "periodic"),
        ("⑥ n=2 环绕 a≡0", 2, 1.0, None, 1e-9, "periodic"),
        ("⑦ n=3 环绕 e=0.5 a≡0（非弹性）", 3, 0.5, None, 1e-9, "periodic"),
        ("⑧ n=3 环绕 δ₀=1e-10（δ₀ 无关性）", 3, 1.0, None, 1e-10, "periodic"),
    ]
    res = []
    print()
    print(f"  {'配置':<38} {'λ₁ 中位':>10} {'λ₁ 均值±SE':>17} {'范围':>19} "
          f"{'碰撞/步':>8}")
    for name, nd, e, ac, d0, bd in cfgs:
        r = run_cfg(name, nd, e=e, acts=ac, n_ic=a.ic, n_steps=a.steps,
                    delta0=d0, boundary=bd)
        res.append(r)
        print(f"  {name:<38} {r['lam_med']:>+10.5f} "
              f"{r['lam_mean']:>+9.5f}±{r['lam_se']:<6.5f} "
              f"[{r['lam_min']:+.4f},{r['lam_max']:+.4f}]".rjust(19)
              + f"{r['collisions_per_step']:>8.3f}")

    d = {r["name"]: r for r in res}
    c0 = d["① n=1 环绕（无碰撞对照，解析 0）"]
    c1 = d["② n=1 反射（对照：边界伪影）"]
    main_r = d["④ n=3 环绕 a≡0（★ 主配置）"]
    act_r = d["⑤ n=3 环绕 随机动作（机制诊断）"]
    d0_r = d["⑧ n=3 环绕 δ₀=1e-10（δ₀ 无关性）"]

    def close(x, y, k=3.0):
        se = math.hypot(x["lam_se"], y["lam_se"])
        return abs(x["lam_mean"] - y["lam_mean"]) < k * max(se, 1e-6)

    v1 = abs(c0["lam_med"]) < 0.01
    v2 = None   # 动作会改变碰撞频率 → 不再作为 pass/fail 判据（见 t18_diag.py）
    v3 = close(main_r, d0_r)
    pos = main_r["lam_mean"] > 3 * main_r["lam_se"] and main_r["lam_mean"] > 0.02

    print("\n" + "=" * 100)
    print("  交叉验证")
    print("=" * 100)
    print(f"  ① 无碰撞对照（环绕）：λ₁ = {c0['lam_med']:+.5f}  "
          + ("✓ 与解析值 0 一致 → 测量机器可靠" if v1 else "✗ 机器在已知系统上失效"))
    print(f"  ② 边界伪影：反射边界下无碰撞系统的 λ₁ = {c1['lam_med']:+.5f} "
          f"（vs 环绕 {c0['lam_med']:+.5f}）→ 反射边界贡献了 "
          f"{c1['lam_mean']-c0['lam_mean']:+.5f} 的**假扩张**")
    print(f"  ③ 动作的影响（机制，非判据）：a≡0 {main_r['lam_mean']:+.5f} vs 随机动作 "
          f"{act_r['lam_mean']:+.5f}  (Δ {abs(main_r['lam_mean']-act_r['lam_mean']):.5f})  "
          f"碰撞率 {main_r['collisions_per_step']:.3f} → {act_r['collisions_per_step']:.3f}  "
          f"← 共享动作 + clip 使速度趋同，碰撞消失（见 t18_diag.py）")
    print(f"  ② δ₀ 无关性：1e-9 {main_r['lam_mean']:+.5f} vs 1e-10 "
          f"{d0_r['lam_mean']:+.5f}  (Δ {abs(main_r['lam_mean']-d0_r['lam_mean']):.5f})  "
          + ("✓" if v3 else "✗"))
    print(f"\n  ★ 前置判据（碰撞环境 λ₁ 显著为正）：{main_r['lam_mean']:+.5f}"
          f" ± {main_r['lam_se']:.5f}  "
          + ("**成立**" if pos else "**不成立 → T18 前提失效**"))
    print(f"  ★ 与洛伦兹对照：+0.0453/步（连续光滑） vs "
          f"{main_r['lam_mean']:+.5f}/帧（不连续接触） → "
          f"比值 {main_r['lam_mean']/0.0453:.2f}×")

    Q = dict(config=dict(n_ic=a.ic, n_steps=a.steps), rows=res,
             checks=dict(ctrl_zero=v1, act_invariance=v2, delta_invariance=v3,
                         positive=pos),
             border_artifact=dict(reflect=c1["lam_mean"], periodic=c0["lam_mean"]),
             elapsed_s=round(time.time() - t0, 1))
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(Q, f, ensure_ascii=False)
    print(f"\n  → {OUT}  ({Q['elapsed_s']}s)")


if __name__ == "__main__":
    main()
