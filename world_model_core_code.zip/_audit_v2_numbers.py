# -*- coding: utf-8 -*-
"""Extract decimal/percentage numbers from rewritten tex and verify
each has a source in the original md files (or whitelisted from t5 JSON)."""
import re, glob, json, os

import sys
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)          # 仓库根（脚本在 code/ 下）
TEX = sys.argv[1] if len(sys.argv) > 1 else os.path.join("paper", "main_chinaxiv_v3.tex")
tex = open(os.path.join(ROOT, TEX) if not os.path.isabs(TEX) else TEX,
           encoding="utf-8").read()
body = tex.split(r"\begin{document}", 1)[1]

# source corpus
corpus = ""
for f in ["paper/full_paper.md", "paper/introduction.md", "paper/methods.md",
          "paper/results.md", "paper/negative_results.md"]:
    corpus += open(os.path.join(ROOT, f), encoding="utf-8").read()
# t5 log for newly added allocation tables
t5 = json.load(open(os.path.join(ROOT, "logs/t5_alloc.json"), encoding="utf-8"))
t5nums = set()
def collect(x):
    if isinstance(x, dict):
        for v in x.values(): collect(v)
    elif isinstance(x, list):
        for v in x: collect(v)
    elif isinstance(x, (int, float)):
        t5nums.add(round(float(x), 4))
collect(t5)

def norm(s):
    return s.replace(r"\,", "").replace(",", "").replace(" ", "")

corpus_n = norm(corpus)

# strip latex commands that add noise, keep math/text content
clean = body
clean = re.sub(r"\\(label|ref|cite|texttt|textbf|mathrm|mathbf|footnote)\{[^}]*\}", "", clean)
clean = clean.replace(r"\times", "x").replace(r"\to", "->").replace(r"\approx", "~")
clean = clean.replace(r"\pm", "+-").replace(r"\le", "<=").replace(r"\ge", ">=")
clean = clean.replace(r"\lambda", "lambda").replace(r"\delta", "delta").replace(r"\rho", "rho")
clean = clean.replace(r"\eta", "eta").replace(r"\varepsilon", "eps")
clean = re.sub(r"\\[a-zA-Z]+\*?", " ", clean)
clean = clean.replace("{", "").replace("}", "").replace("$", "")

pat = re.compile(r"(?<![\w.])(\d+\.\d{2,})(?:\s*\\\\?%)?|(\d+\.\d)(?:\s*\\\\?%)?|(\d{1,3})\s*\\\\?%")
found = {}
for m in pat.finditer(clean):
    raw = m.group(0).replace("\\%", "%").strip()
    if m.group(1): num = m.group(1); ispct = raw.endswith("%")
    elif m.group(2): num = m.group(2); ispct = raw.endswith("%")
    else: num = m.group(3); ispct = True
    found.setdefault((num, ispct), 0)
    found[(num, ispct)] += 1

def in_corpus(num):
    n = norm(num)
    if n in corpus_n: return True
    # rounding equivalence: try 2,3,4 decimal truncations
    f = float(n)
    for d in (2, 3, 4, 5):
        if f"{f:.{d}f}".rstrip("0").rstrip(".") in corpus_n: return True
    # percentage point form
    if f"{float(n):.2f}".rstrip("0").rstrip(".") in corpus_n: return True
    return False

# 白名单：排版字号（pt），不是研究数字
FONT_PT = {"10.5", "9.5"}

def tol_for(num):
    """按**显示精度**给容差：论文里写了几位小数，就允许半个末位，
    再叠加 2% 相对容差（量化损失这类小百分数用得上）。
    原实现用固定 1.1e-3 绝对容差，把 0.07%（← logs 里 0.0652%）误判为「无来源」。"""
    dec = len(num.split(".")[1]) if "." in num else 0
    return max(0.5 * (10 ** -dec), 0.02 * abs(float(num)))

def in_t5(num):
    f = float(num)
    t = tol_for(num)
    return any(abs(f - v) <= max(t, 0.02 * abs(v)) for v in t5nums)

missing, from_t5, from_font = [], [], []
for (num, ispct), cnt in sorted(found.items()):
    if num in FONT_PT:
        from_font.append((num, cnt)); continue
    if in_corpus(num):
        continue
    if in_t5(num):
        from_t5.append((num, cnt)); continue
    missing.append((num, "pct" if ispct else "", cnt))

print("total distinct numbers checked:", len(found))
print(f"  from md corpus      : {len(found) - len(from_t5) - len(from_font) - len(missing)}")
print(f"  from logs/t5_alloc  : {len(from_t5)}  {from_t5}")
print(f"  typographic (pt)    : {len(from_font)}  {from_font}")
print("=== MISSING (no source found) ===")
for x in missing: print(x)
