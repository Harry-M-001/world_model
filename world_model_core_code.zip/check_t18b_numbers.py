"""
T18b 数字校验 —— 报告里每个关键数字必须与 JSON 一致，且**旧错误值只能以「已修正」的形式出现**。

判据（可机检，失败即非零退出）：
  ① 每条数值声称与 logs/*.json 逐项一致
  ② 报告中「31%」（旧的错误保留比例）不得作为现值出现；只能出现在修正叙述里
  ③ 报告中 +0.35020 只能出现在「旧误用」上下文
  ④ 主结论已撤回的标记必须存在
用法：python check_t18b_numbers.py
"""
import json
import os
import _paths  # noqa: E402
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

DOC = _paths.phase1("T18b_multistep对照.md")
T18 = _paths.phase1("T18_碰撞环境.md")


def L(n):
    with open(os.path.join(ROOT, "logs", n), encoding="utf-8") as f:
        return json.load(f)


def main():
    doc = open(DOC, encoding="utf-8").read()
    t18 = open(T18, encoding="utf-8").read()
    ms = {k: L(f"t18_multistep_{k}_ms5ep2000.json") for k in ("reflect", "periodic")}
    dg = L("t18_ms_diag.json")
    t2 = L("t18_truth_n2.json")
    t4 = L("t4b_own_lam.json")
    lam_d = L("t18_lambda_data.json")
    an = L("t18_multistep_analysis.json")

    def d(rec, b):
        return next(x for x in rec["rows"] if x["bits"] == b)["d_end_med"]

    n2p = next(x for x in t2["rows"] if x["n_digit"] == 2 and x["boundary"] == "periodic")
    n2r = next(x for x in t2["rows"] if x["n_digit"] == 2 and x["boundary"] == "reflect")
    n1p = next(x for x in t2["rows"] if x["n_digit"] == 1 and x["boundary"] == "periodic")

    def near(a, b, tol):
        return abs(a - b) < tol

    checks = [
        # ---- 主结果
        ("periodic single b* = None", ms["periodic"]["ref"]["b_star"] is None),
        ("periodic msK b* = 12", ms["periodic"]["ms"]["b_star"] == 12),
        ("reflect 两臂 b* 都 = 12",
         ms["reflect"]["ref"]["b_star"] == 12 and ms["reflect"]["ms"]["b_star"] == 12),
        ("periodic single δ_∞@32 = 1.11776", near(d(ms["periodic"]["ref"], 32), 1.11776, 1e-4)),
        ("periodic msK δ_∞@32 = 1.55251e-05",
         near(d(ms["periodic"]["ms"], 32), 1.55251e-05, 1e-9)),
        ("裁决两臂都是 H1",
         an["verdict"]["periodic"]["h1"] and an["verdict"]["reflect"]["h1"]),
        ("periodic ms 的 δ_∞ 在 b=8→12 之间断崖（>0.5 → <0.2）",
         d(ms["periodic"]["ms"], 8) > 0.5 and d(ms["periodic"]["ms"], 12) < 0.2),
        # ---- 机制诊断
        ("periodic single λ₁(自身) = +2.07068",
         near(dg["res"]["periodic_single"]["lam_own"], 2.07068, 1e-3)),
        ("另外三臂无扩张事件（lam_own is None）",
         all(dg["res"][k]["lam_own"] is None
             for k in ("reflect_single", "reflect_msK", "periodic_msK"))),
        ("periodic msK 范数塌缩到 0.278×",
         near(dg["res"]["periodic_msK"]["norm_end"] / dg["res"]["periodic_msK"]["norm_t0"],
              0.278, 5e-3)),
        ("真值潜范数 ~7.0（periodic 7.03）",
         near(dg["res"]["periodic_msK"]["truth_norm"], 7.03, 0.02)),
        # ---- 勘误一
        ("n=2 环绕真值 = +0.26367±0.02915",
         near(n2p["lam_mean"], 0.26367, 1e-4) and near(n2p["lam_se"], 0.02915, 1e-4)),
        ("n=2 反射真值 = +0.05248±0.00705",
         near(n2r["lam_mean"], 0.05248, 1e-4) and near(n2r["lam_se"], 0.00705, 1e-4)),
        ("n=1 环绕零对照精确 0", abs(n1p["lam_mean"]) < 1e-9),
        ("对拍 ⑥ 可复现（gap < 3SE）",
         t2["cross_check"]["ok"] and t2["cross_check"]["n2_periodic_vs_stored_gap"] < 0.2),
        ("数据 n_digit = 2（与真值同配置）", L("t18_collide.json")["periodic"]["config"]["n_digit"] == 2),
        ("修正后 periodic 保留比例 41.0%",
         near(lam_d["periodic"]["lam1_data"] / n2p["lam_mean"] * 100, 41.0, 0.5)
         and "41.0%" in doc),
        # ---- 交叉核查
        ("T4b single 轨迹范数比 = 1.000", near(t4["res"]["single"]["ratio_to_truth"], 1.000, 5e-3)),
        ("T4b multistep 轨迹范数比 = 1.143", near(t4["res"]["multistep"]["ratio_to_truth"], 1.143, 5e-3)),
        ("T4b multistep 无扩张事件", t4["res"]["multistep"]["lam_own"] is None),
        ("T4b 两臂判定均为「可信」", "✓ 可信" in doc and "需重审" not in doc),
        # ---- 文档一致性
        ("报告含「预注册判据」的 H1/H2 定义", "H1「训练方式假说」" in doc),
        ("报告声明主结论撤回且写明「单步训练的产物」",
         "撤回" in doc and "不连续动力学" in doc and "单步训练的产物" in doc),
        ("T18 主报告已加勘误横幅", "勘误与修订（2026-09-19 晚" in t18),
        ("T18 主报告横幅指向 T18b", "T18b_multistep对照.md" in t18),
        ("报告中旧的 0.35020 只出现在「旧值/误用/引用」上下文",
         all(any(k in doc[max(0, m.start() - 160):m.start() + 120]
                 for k in ("旧", "误用", "此前引用", "报告引用", "n=3"))
             for m in re.finditer(r"0\.35020", doc))),
        ("报告不含裸的「保留 31%」现值",
         "31%" not in doc or "由 31%" in doc or "31% 修正" in doc),
        ("报告记录了 G-ms1 逐位一致", "0.000e+00" in doc),
        ("报告记录了 mtime 守卫", "mtime" in doc and "2026-09-19 21:43" in doc),
    ]
    bad = [n for n, ok in checks if not ok]
    print("=" * 92)
    print("  T18b 数字与文档一致性校验")
    print("=" * 92)
    for n, ok in checks:
        print(f"  [{'✓' if ok else '✗'}] {n}")
    print()
    print(f"  {len(checks) - len(bad)}/{len(checks)} 通过"
          + ("  ✅" if not bad else f"  ❌ 失败：{bad}"))
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
